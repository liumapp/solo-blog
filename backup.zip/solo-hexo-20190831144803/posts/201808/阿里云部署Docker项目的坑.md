title: 阿里云部署Docker项目的坑
date: '2018-08-14 14:38:03'
updated: '2018-08-14 14:38:59'
tags: [Docker, Java, Maven, CentOS]
permalink: /articles/2018/08/14/1534256216773.html
---
> 在阿里云服务器CentOS7上部署一个典型的SpringBoot + Maven + Docker项目，一路下来的坑还真不少。

## 问题概览

从初始化服务器磁盘开始，到安装maven + jdk8 + docker + docker-compose等相关环境，再到项目部署，总是会遇到各种地址无法访问

举几个例子：

* Maven默认使用的中央仓库地址在阿里云服务器（华北地区）上无法访问，导致依赖无法正常加载；

* docker-composer的安装一般是从GitHub上拉release下来："https://github.com/docker/compose/releases/tag/1.16.1" ，可是阿里云服务器（华北地区）依然无法访问这个地址，导致docker-composer安装失败

* docker在进行镜像部署的时候，有时候需要从dockerhub上下载依赖镜像（很多时候是需要的），可是阿里云服务器（华北地区）仍然无法访问dockerhub，导致容器镜像安装失败

请注意，这里加了一个华北地区，因为经过测试，我发现香港地区的阿里云服务器是不存在上述这些问题的

## 解决办法

首先是环境安装的问题，我是利用自己的脚本： Github: [liumapp/install-docker-compose](https://github.com/liumapp/install-docker-compose) 来完成docker + docker-composer + jdk8 + maven环境的安装，安装过程中就会出现服务器无法访问docker-composer在GitHub上的release，从而导致docker-composer二进制文件的下载失败

我这里用的解决办法比较简单，切换到香港的阿里云ECS，再去拉docker-composer的release，完了再用ftp放到华北地区的ECS上...

第二个问题是Maven的依赖问题，这个问题之前我总结过 [Maven依赖下载失败的原因及解决方案](http://www.liumapp.com/articles/2018/03/02/1519962410735.html) ，改用阿里的Maven镜像仓库地址即可，具体配置文件位于/opt/maven/conf/settings.xml（如果您也使用我的脚本进行安装的话）

第三个问题是关于dockerhub地址无法被访问的问题，这个稍微麻烦点，因为要先去阿里云的后台，配置一个专属的加速器地址，再到/etc/docker/目录下，配置一个daemon.json文件，把下述内容加上去：

	{
	  "registry-mirrors" : [
		"https://lpikn7jh.mirror.aliyuncs.com"
	  ]
	}

上面的值是我个人的加速地址，看官不介意的话拿去用即可

当然，您最后不要忘记重启docker和它的守护进程：

	systemctl daemon-reload
	systemctl restart docker






