title: SpringBoot工具库UtilArchetype
date: '2017-12-21 15:26:21'
updated: '2017-12-21 15:26:21'
tags: [Java]
permalink: /articles/2017/12/19/1513666802263.html
---
> SpringBoot供其他项目使用的工具库初始代码，以封装为Archetype方便各位调用。

## 前言

先上UtilArchetype的源代码：

[spring-boot-util-module](https://github.com/liumapp/spring-boot-util-module)


## 安装

获取源代码后，进行项目目录依次执行

*   mvn archetype:create-from-project

*   cd target/generated-sources/archetype

*   mvn install

## 使用

在您希望生成项目的位置输入命令：

	mvn archetype:generate
	
在出来的列表中选择spring-boot-util-module对应的序号，随后输入新项目的groupId、artifactId以及version即可。

## pom

对于pom.xml中关键的内容的解释

	<?xml version="1.0" encoding="UTF-8"?>
	<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
	  <modelVersion>4.0.0</modelVersion>

	  <groupId>com.liumapp.module.util</groupId>
	  <artifactId>spring-boot-util-module</artifactId>
	  <version>v1.0.0</version>
	  <packaging>jar</packaging>

	  <properties>
		<project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
		<springboot.version>1.5.6.RELEASE</springboot.version>
		<java.version>1.8</java.version>
	  </properties>

	  <name>spring-boot-util-module</name>
	  <url>http://maven.apache.org</url>
	  <description>A lib module for SpringBoot , can not run alone</description>

	  <developers>
		<developer>
		  <name>liumapp</name>
		  <url>http://www.liumapp.com</url>
		  <email>liumapp.com@gmail.com</email>
		</developer>
	  </developers>

	  <dependencies>
		<dependency>
		  <groupId>org.springframework.boot</groupId>
		  <artifactId>spring-boot-starter</artifactId>
		  <version>${springboot.version}</version>
		</dependency>
		<dependency>
		  <groupId>org.springframework.boot</groupId>
		  <artifactId>spring-boot-starter-test</artifactId>
		  <version>${springboot.version}</version>
		  <scope>test</scope>
		</dependency>
	  </dependencies>

	</project>

是的，没有看错，以上就是pom的全部内容。

对比之前的CoreArchetype，可以发现它少了很多东西。

* 首先没有了SpringBoot必备的```<parent>```标签，因为对于一个工具库而言，我们并不需要它具备独立运行的能力，只要能够打包成Jar供其他程序引用即可。

* 其次没有SpringBoot拆包即用的依赖插件：```spring-boot-maven-plugin ```，道理还是一样的，对于一个工具库而言，不需要它能够独立运行。

很可能有人会问，这样配置的话我们如何对这个项目进行配置项的设置呢？

这个问题```spring-boot-starter```的@Configuration能够帮我们解决，具体的解决办法我会在之后的博文来进行叙述。
	





