title: Linux网络端口常用操作
date: '2017-09-06 17:13:40'
updated: '2017-09-06 17:13:40'
tags: [Linux, CentOS]
permalink: /articles/2017/09/06/1504684037226.html
---
> 一些经常被使用的命令集锦。持续更新ing

### 查看端口占用情况

比如我要检查9999端口被哪个进程占用了

#### Linux

netstat -nap | grep 9999

#### Mac OS

lsof -i:9999

### 检查端口是否允许外网访问

telnet {ip值} {端口}

比如我要检查我的服务器118.111.111.231的9999端口是否允许外网访问

telnet 118.111.111.231 9999 

