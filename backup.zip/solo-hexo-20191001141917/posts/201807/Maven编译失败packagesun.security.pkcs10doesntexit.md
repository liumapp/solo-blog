title: 'Maven编译失败: package sun.security.pkcs10 doesn''t exit'
date: '2018-07-28 11:54:47'
updated: '2018-07-28 11:54:47'
tags: [Java, Maven]
permalink: /articles/2018/07/28/1532778240331.html
---
> 在项目中使用到了sun.security.pkcs10这个包，项目是基于Maven构建的，所以在进行编译打包的过程中，出现Maven找不到依赖的错误

## 错误信息

[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 1.493 s
[INFO] Finished at: 2018-07-28T19:39:45+08:00
[INFO] Final Memory: 18M/311M
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.1:compile (default-compile) on project jks-core: Compilation failure: Compilation failure:
[ERROR] /usr/local/tomcat/project/jks-core/src/main/java/com/liumapp/jks/core/adapter/KeyStoreAdapter.java:[8,27] package sun.security.pkcs10 does not exist
[ERROR] /usr/local/tomcat/project/jks-core/src/main/java/com/liumapp/jks/core/certificate/CSR.java:[3,27] package sun.security.pkcs10 does not exist

## 解决办法

Maven在编译项目的时候，一些内部包，比如sun.security.pkcs10默认是被隐藏的，除非我们将"-XDignore.symbol.file"这个选项，添加在maven-compiler-plugin插件下：

	<plugin>
	  <groupId>org.apache.maven.plugins</groupId>
	  <artifactId>maven-compiler-plugin</artifactId>
	  <version>3.2</version>
	  <configuration>
		<fork>true</fork>
		<compilerArgument>-XDignore.symbol.file</compilerArgument>
	  </configuration>
	</plugin>
