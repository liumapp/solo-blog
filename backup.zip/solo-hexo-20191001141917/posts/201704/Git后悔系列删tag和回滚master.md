title: Git后悔系列——删tag和回滚master
date: '2017-04-27 17:09:26'
updated: '2017-04-27 17:09:26'
tags: [Github]
permalink: /articles/2017/04/27/1493284166287.html
---
### Git后悔系列——删tag和回滚master

>  代码push带git库里了，打好tag了，结果反悔了，怎么办？删tag，回滚线上的master呗。

话不多说，直接干。

#### 删除本地和线上的tag

假设希望被删除的tag为v1.1.0

删除本地tag：

  git tag -d v1.1.0
  
删除线上tag：

  git push origin :refs/tags/v1.1.0
  
#### 回滚线上的master

首先选择想要回滚的正确版本

  git log
  
  git reset --hard YourVersionNumber
  
  git push -f origin master
  
搞定