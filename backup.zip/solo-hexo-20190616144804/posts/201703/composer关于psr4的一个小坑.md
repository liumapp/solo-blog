title: composer关于psr-4的一个小坑
date: '2017-03-22 16:38:57'
updated: '2017-03-22 16:38:57'
tags: [composer, PHP]
permalink: /articles/2017/03/22/1490170969445.html
---
>  composer.json文件下的autoload属性有一项psr-4的键值对，这个psr-4的value直接关系到类自动加载的成果与否

### 问题情景

***

Git上新建一个项目，名为pay。

pay项目的意义是为后续项目提供支付宝、微信、银行卡等方式的支付功能，那么，自然有必要进行模块化的开发和部署，这里采用了composer进行管理。

Git上新建第二个项目，名为project。

project项目同样采用了composer进行管理，只是现在需要集成pay项目。

### pay项目的composer.json

***

	{
	  "name": "",
	  "type": "",
	  "description": "",
	  "minimum-stability": "",
	  "keywords": ["alipay", "weixin", "支付宝支付", "微信支付", "集成支付接口SDK"],
	  "license": "",
	  "authors": [
		{
		  "name": "",
		  "email": "",
		  "homepage": "",
		  "role": ""
	  }
	  ],
	  "require": {
		"php": ">=5.4.0"
	  },
	  "autoload": {
		"psr-4": {
		  "huluwa\\huluwa-pa\\": ""//请注意这一行
	  }
	  }
	}

上述代码中的倒数第四行,"huluwa\\huluwa-pa\\":""，是因为在实际开发过程中少打了一个y才出现的，这也是踩到这个坑的导火索。我们接下来看看，huluwa\\huluwa-pa，这个值，会对project产生什么影响。

### project项目的composer.json

***

	{
	  
	  "repositories": [
		{
			"name": "huluwa/pay",
			"type":"git",
			"url":"http://git.huluwa.cc/liumei/huluwa-pay.git"
		}
	  ],
	  "require": {
		"huluwa/pay":"dev-master"
	  },
	  
	}

很简单，直接引用pay项目的写法，接下来我们看看实际结果。

### 结果

***

执行：

	composer.phar update nothing 
	
成功引入pay项目到project项目中，然后我们观察到，project项目下的autoload_psr4.php及autoload_real.php对于我们huluwa/pay项目打得标签都是huluwa/huluwa-pa，这直接导致后期开发过程中yii无法找到pay项目下的类。

### 结论

***

composer.json文件的psr-4设置的值一定要和require属性下设置的值保持一致，不然无法自动加载成功。

