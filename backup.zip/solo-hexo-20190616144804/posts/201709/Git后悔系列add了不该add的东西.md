title: Git后悔系列－－add了不该add的东西
date: '2017-09-23 09:46:43'
updated: '2017-09-23 09:46:43'
tags: [GitLab, Github]
permalink: /articles/2017/09/23/1506131203350.html
---
> 众所周知，本地的target目录、各种ide产生的配置文件云云都是不需要上传到Git上的，不然只想要源码的人一拉，结果拉来一堆“翔”就不好了。

本来这个问题简单的用下.gitignore配置一下就可以解决的，但总会有一不小心的时候，比如我一不小心敲了

	git add .DS_Store
	
把.DS_Store这翔拉到我本地的git库里了，现在要把它退回去。

这个时候再去配置 .gitignore已经太迟了，因为它已经在缓存工作区了，只需要再执行一个commit，就能够保存起来。

但我们可以使用reset命令，把它强制退回去。

	git reset HEAD .DS_Store
	
敲完之后，就可以发现.DS_Store已经被退回去了。

接下来再配置.gitignore就能解决问题。
