title: acme.sh获取Let's encrypt证书
date: '2019-05-23 09:24:58'
updated: '2019-05-23 09:26:14'
tags: [ssl, CentOS]
permalink: /articles/2019/05/23/1558574698880.html
---
> Let's Encrypt是一款永久免费的SSL通配符证书，这篇文章介绍如何使用acme.sh来获取它

acme.sh项目地址: [acme.sh](https://github.com/Neilpang/acme.sh)

官方中文文档地址: [acme.sh/wiki](https://github.com/Neilpang/acme.sh/wiki/%E8%AF%B4%E6%98%8E~~~~)

## DNS解析验证

获取证书，需要验证站点确实是归本人所有，常用的验证方式一般是通过DNS解析一条TXT记录来完成

ACME提供两种方式，一种是不指定DNS运营厂商，我们自己去修改txt解析记录即可，另外一种是指定CloudFlare，也就是说您的域名DNS解析地址要由CloudFlare提供

经过实际测试，前者获取到的证书在浏览器上会被标识为不安全，而后者却会被标识为安全

### 不指定DNS运营产商

首先输入以下命令获取txt记录值：

````shell
~/.acme.sh/acme.sh --issue -d liumapp.com --dns --yes-I-know-dns-manual-mode-enough-go-ahead-please
````

没出意外，可以获取以下结果

````shell
[Wed May 22 16:28:54 CST 2019] Creating domain key
[Wed May 22 16:28:54 CST 2019] The domain key is here: /root/.acme.sh/liumapp.com/liumapp.com.key
[Wed May 22 16:28:54 CST 2019] Single domain='liumapp.com'
[Wed May 22 16:28:54 CST 2019] Getting domain auth token for each domain
[Wed May 22 16:28:56 CST 2019] Getting webroot for domain='liumapp.com'
[Wed May 22 16:28:56 CST 2019] Add the following TXT record:
[Wed May 22 16:28:56 CST 2019] Domain: '_acme-challenge.liumapp.com'
[Wed May 22 16:28:56 CST 2019] TXT value: 'tzh7--4EldLpZUJlSAkxF6sZ63q7lxJdvnE2a-8IGF4'
[Wed May 22 16:28:56 CST 2019] Please be aware that you prepend _acme-challenge. before your domain
[Wed May 22 16:28:56 CST 2019] so the resulting subdomain will be: _acme-challenge.liumapp.com
[Wed May 22 16:28:56 CST 2019] Please add the TXT records to the domains, and re-run with --renew.
[Wed May 22 16:28:56 CST 2019] Please add '--debug' or '--log' to check more details.
[Wed May 22 16:28:56 CST 2019] See: https://github.com/Neilpang/acme.sh/wiki/How-to-debug-acme.sh
````

然后设置自己域名DNS解析记录即可，解析完成后输入下列命令： 

````shell
/root/.acme.sh/acme.sh --renew -d liumapp.com -d www.liumapp.com --yes-I-know-dns-manual-mode-enough-go-ahead-please
````

不出意外就能发现我们的let's encrypt证书申请成功：

````
[Wed May 22 19:35:03 CST 2019] Renew: 'liumapp.com'
[Wed May 22 19:35:03 CST 2019] Single domain='liumapp.com'
[Wed May 22 19:35:03 CST 2019] Getting domain auth token for each domain
[Wed May 22 19:35:03 CST 2019] Verifying: liumapp.com
[Wed May 22 19:35:07 CST 2019] Success
[Wed May 22 19:35:07 CST 2019] Verify finished, start to sign.
[Wed May 22 19:35:08 CST 2019] Lets finalize the order, Le_OrderFinalize: https://acme-v02.api.letsencrypt.org/acme/finalize/57574781/464831689
[Wed May 22 19:35:10 CST 2019] Download cert, Le_LinkCert: https://acme-v02.api.letsencrypt.org/acme/cert/0356fc3fb0ba8c23ad634af914a823e9fa37
[Wed May 22 19:35:10 CST 2019] Cert success.
...
[Wed May 22 19:35:10 CST 2019] Your cert is in  /root/.acme.sh/liumapp.com/liumapp.com.cer 
[Wed May 22 19:35:10 CST 2019] Your cert key is in  /root/.acme.sh/liumapp.com/liumapp.com.key 
[Wed May 22 19:35:10 CST 2019] The intermediate CA cert is in  /root/.acme.sh/liumapp.com/ca.cer 
[Wed May 22 19:35:10 CST 2019] And the full chain certs is there:  /root/.acme.sh/liumapp.com/fullchain.cer
````

### 指定cloudflare

首先请去cloudflare官网： [https://dash.cloudflare.com](https://dash.cloudflare.com/)注册一个账号

注册成功后按照cloudflare界面提示走流程，基本就是绑定自己的域名，然后切换域名DNS解析服务地址

然后在命令行中输入以下命令

````shell
export CF_Email="liumapp.com@gmail.com"
export CF_Key="123456"
/root/.acme.sh/acme.sh --issue --dns dns_cf -d liumapp.com -d www.liumapp.com
````

Email跟Key的信息在注册成功后可以获取到

提示成功后即可获取到证书
