title: solo皮肤集成失败有哪些原因？
date: '2017-06-29 11:17:53'
updated: '2017-06-29 13:53:11'
tags: [Solo]
permalink: /articles/2017/06/29/1498706154791.html
---
今天尝试把官方自带的皮肤集成到博客里去，步骤：

在Github上下载皮肤，将对应的皮肤目录放到/src/main/webapp/skins目录下，截图如下：

![1.pic.jpg](http://oss.fangxinqian.cn/88b4c96490f74fd8b7a8e7c87377152e.jpg)

然后打包放到线上，可是进到皮肤管理的页面一看，还是原来默认的那两个

![2.pic.jpg](http://oss.fangxinqian.cn/9c51c0bf22244d6491d5093b0bfc4b38.jpg)

所以我想问下大家导致这个问题的原因可能有哪些？

最后发现解决办法确实是如D所言：

	toolers 和 skin-preview 这两个目录不是皮肤，删除了重启
	
但是这又牵引出了一个新的问题：

我之前帮别人装B3log的时候（跟我自己的博客部署在同一台服务器），他的皮肤目录下包含了toolers和skin-preview，而且在他的后台皮肤管理却仍然是正常的，只不过toolers和skin-preview被显示为undefined。截图如下：

![1.pic_hd.jpg](http://oss.fangxinqian.cn/c9272e80f5a24e93b51216e1fec83612.jpg)

虽然说这个问题没有什么实质的影响，但还是先抛出来，帮助B3log完善自身。