title: MacOS安装Docker
date: '2017-12-27 20:45:20'
updated: '2018-04-26 17:10:57'
tags: [Mac, Docker]
permalink: /articles/2017/12/27/1514347974172.html
---
> 有幸参与[Skeleton](https://github.com/Nepxion/Skeleton)项目，虽然我做的工作只是把bat脚本改写为shell脚本，以便支持项目在Mac/Linux环境下自动部署到Docker上的功能。一遍操作走下来，发现Docker是一个相当cool的项目。好了，收回题外话，这里把Mac安装Docker的过程及遇到的一些坑记录下来，方便后面的同学避开雷区。

## 前言

首先提供需要的原材料：

* [Docker官网](https://www.docker.com/)，您可能需要翻墙来访问

* MacOS 10.X系统。

## 下载Docker

直接进入Docker官网，下载DMG安装包，云云。

安装完之后启动，不出意外应该会报以下错误：

	Docker does not rely on Virtualbox but may not work properly on systems with VirtualBox versions prior to v4.3.30
	VirtualBox v4.3.28 is currently installed.
	Please upgrade or uninstall Virtualbox.

如果您的Docker没有报上述错误，那么请无视接下来的一段。

### 问题解决

我是参考docker官方的一段[issue](https://github.com/docker/for-mac/issues/4)来解决的：

* 首先检查一下本地环境的kextstat:
	输入命令
	  
	`kextstat | grep -i virtualbox`

	我本地的结果是：
	
	![1.pic_hd.jpg](http://oss.fangxinqian.cn/336edf6db04c416b81568e4191e569d7.jpg)

	如果有信息反馈，那么执行第二步。
	
* cd /Library/Application\ Support/VirtualBox/

	执行ls后，不出意外，应该长这个样子：
	
	![2.pic_hd.jpg](http://oss.fangxinqian.cn/d63946b554a44deaa58b850c7e4655b0.jpg)

	在该目录下执行：
	
	``` rm -rf *.kext ```
	
	清空kext文件后，我们再执行一遍
	
	`kextstat | grep -i virtualbox`
	
	这个时候，应该不会有任何信息显示出来，那么我们重启一遍电脑，再运行docker应该就不会报错了。
	
## 下载Kitematic

当Docker运行起来之后，我们还需要安装Kitematic才可以愉快的跟docker做朋友：

安装步骤很简单，在docker的icon点一下，在出来的下拉框里选择Kitematic就可以了，之后的安装步骤略。

## 测试

我这里使用的是[Skeleton](https://github.com/Nepxion/Skeleton)来测试的，因为这个项目有一键部署到docker上的脚本"install-docker.sh"，运行这个脚本后，docker上就能够看到我们新部署上的Skeleton项目，截图如下：

![4.pic_hd.jpg](http://oss.fangxinqian.cn/00ee8c2fc0454916aad7d73cab9aa5fa.jpg)


