title: 修改Github项目的语言分类
date: '2017-08-09 09:42:35'
updated: '2018-04-16 14:00:20'
tags: [Github]
permalink: /articles/2017/08/09/1502242821686.html
---
> 辛辛苦苦做的一个Java项目，发布到Github上，结果被Github标注为一个Html或者JavaScript项目，这得是一件多郁闷的事情

先上图，我的DNSBee项目是一个Java项目（管理DNS解析的Web项目），但因为包含的js文件比较多，所以被Github标注为一个JavaScript项目

  ![2.pic.jpg](http://oss.fangxinqian.cn/76e05050df9241edafe57c73849ff325.jpg)

现在我要把它的语言分类改为Java：

在项目目录中创建一个名为".gitattributes"的文件，添加以下代码：

	*.js linguist-language=Java
	
重新上传到Github上，然后就可以发现乖乖的变回Java了。

  ![3.pic.jpg](http://oss.fangxinqian.cn/2400f1c2c4804a64a6de9c47330ead7d.jpg)
  
### 分析

我不是很明白Github的语言识别机制，但是似乎跟项目中所有文件的后缀有关系，如果它把我们的项目标识为JavaScript，那肯定是因为我们项目中以js结尾的文件较多（这在web项目中非常常见），所以只需要通过linguist-language，让Github把js结尾的文件看作java文件就可以达到修改语言类别的目的。