title: MacIDEA通过devtools集成热部署
date: '2017-08-25 14:59:09'
updated: '2017-11-09 14:56:21'
tags: [Mac, IDEA, Java]
permalink: /articles/2017/08/25/1503644138971.html
---
> devtools相信大家都知道，热部署的配置也很简单，但是在Mac的IDEA上，却无论如何也达不到想要的效果，这是为什么呢？因为IDEA欠收拾呀。

### IDEA配置

好了，闲话不多少，直接上图来说明怎么解决问题。

首先我们要配置IDEA的compiler，允许项目自动编译：

![2.pic.jpg](http://oss.fangxinqian.cn/ba95fe70f2764bfbaa6871b9d27675dd.jpg)

勾选之后，打开Maintenance（这个面板的快捷键特别奇怪，请自行找到快捷键面板去设置），然后点击Registry。

如果您找不到Maintenance的话，请打开Preference，在KeyMap栏下搜索Maintenance即可。

![3.pic.jpg](http://oss.fangxinqian.cn/a668def274564d56bd17e936f3f04009.jpg)

在弹出来的面板下找到compiler.automake.allow.when.app.runnning，勾选。然后重启IDEA，我们再在项目中随便修改一个文件，就能够发现springboot自动重启了。

![1.pic.jpg](http://oss.fangxinqian.cn/f6dce69574e248e5b3cfce13fba7bf36.jpg)

### 项目配置

配置完了IDEA，接下来是在项目中进行配置，下面的例子假设看官是用的Maven。

首先我们需要在pom.xml中加入这样一段依赖：

	<dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-devtools</artifactId>
		<version>1.5.6.RELEASE</version>
		<optional>true</optional>
		<scope>runtime</scope>
	</dependency>
	
然后在application.yml配置文件中，加入下面一段代码：

	spring:
	  devtools: 
		 restart: 
		   exclude: static/**,public/**
		   enabled: true
		   
这样就结束了整个Devtools的配置。