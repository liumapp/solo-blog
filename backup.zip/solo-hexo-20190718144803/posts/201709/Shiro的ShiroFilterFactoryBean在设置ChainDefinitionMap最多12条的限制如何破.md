title: Shiro的ShiroFilterFactoryBean在设置ChainDefinitionMap最多12条的限制如何破？
date: '2017-09-15 10:12:32'
updated: '2017-09-15 10:12:32'
tags: [Java, Shiro]
permalink: /articles/2017/09/15/1505441552045.html
---
先上代码：

	ShiroFilterFactoryBean  shiroFilterFactoryBean = new  ShiroFilterFactoryBean();

	shiroFilterFactoryBean.setSecurityManager(securityManager);

	shiroFilterFactoryBean.setLoginUrl("/login/login");
	shiroFilterFactoryBean.setSuccessUrl("/index");
	shiroFilterFactoryBean.setUnauthorizedUrl("/403");

	Map<String, String> filterChainDefinitionMap = new  HashMap<String, String>();
	filterChainDefinitionMap.put("/favicon.ico", "anon");
	filterChainDefinitionMap.put("/css/**", "anon");
	filterChainDefinitionMap.put("/js/**", "anon");
	filterChainDefinitionMap.put("/lib/**", "anon");
	filterChainDefinitionMap.put("/mock/**", "anon");
	filterChainDefinitionMap.put("/images/**", "anon");
	filterChainDefinitionMap.put("/captcha/**", "anon");
	filterChainDefinitionMap.put("/login/**", "anon");
	filterChainDefinitionMap.put("/register/**", "anon");
	filterChainDefinitionMap.put("/plugin/**" , "anon");
	filterChainDefinitionMap.put("/logout", "logout");
	filterChainDefinitionMap.put("/**", "authc");
	shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
	return  shiroFilterFactoryBean;
	
在filterChainDefinitionMap下面最多可以配置12条验证规则，如果我再添加一条就会出问题，比如images下的图片也将会被要求验证才能访问。

现在请问下这种情况有没有什么办法可以解决？