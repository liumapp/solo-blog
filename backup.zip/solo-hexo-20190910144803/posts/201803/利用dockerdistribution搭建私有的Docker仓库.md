title: 利用docker/distribution搭建私有的Docker仓库
date: '2018-03-08 17:28:52'
updated: '2018-03-08 17:29:49'
tags: [Docker]
permalink: /articles/2018/03/08/1520499033763.html
---
> 利用Docker部署项目到线上是一件便利的事情，但是public的项目无疑会带来诸多不便，private帐号的费用又相对较高，所以利用自己已有的服务器资源来搭建一个Docker私服便是一件蛮有必要的事情。

## 前言

步骤很简单，准备一台CentOS7 64位的服务器，安装Docker，安装distribution（我们也称之为Registry2.0，Registry1.0版本的项目已经被官方弃用，ps:1.0用的python语言，2.0用的Go语言，某种程度上表现出Go语言的优秀...）。

然后再结合一下案例测试发布。

先上案例代码：[simple-docker-demo](https://github.com/liumapp/simple-docker-demo)

## 安装

登陆CentOS，执行以下命令:

	yum install docker

	systemctl start docker

	docker run hello-world
  
如果能够看到docker的hello信息，那么说明docker已经在运行了，接下来便是安装distribution，步骤很简单，一条命令搞定:

	docker run -d -p 5000:5000 --restart=always --name registry2 registry:2
  
然后这里请记录一下端口5000，因为以后就是用这个端口来推拉Docker镜像。

## 发布

接下来测试案例的发布到私服

接下来的操作分两种场景，第一种在我们的本地Mac，第二种是在CentOS服务器上的操作。

首先是在本地进行操作：

* 获取[simple-docker-demo](https://github.com/liumapp/simple-docker-demo)的代码

* 进入docker-webc目录

* 执行命令：

		docker build -t liumapp/docker-webc:v1.0.0 .
		
* 修改tag，请注意，这里的your server ip为CentOS服务器的IP地址：

		docker tag liumapp/docker-webc:v1.0.0 ${your server ip}:5000/liumapp/docker-webc:v1.0.0
		
* 配置Mac的docker，及配置daemon.js（Mac上可能需要在客户端的preferences下的daemon进行配置），添加：

		"insecure-registries" : [
		  "${your-server-ip}:5000"
		],

* push

		docker push ${your server ip}:5000/liumapp/docker-webc:v1.0.0
		
push成功之后能够看到以下信息：

![3.pic_hd.jpg](http://oss.fangxinqian.cn/df090fae04124ff8a7f494ce94165d6b.jpg)

我们可以复制这段sha字符串，然后在服务器上使用find命令查找，结果如下：

![4.pic_hd.jpg](http://oss.fangxinqian.cn/3e0f425ee2384453bb7c88605ade8463.jpg)

到此，Docker私服配置成功。

如果您觉得我的博客对您有帮助，欢迎关注我的Github帐号：[liumapp](https://github.com/liumapp)