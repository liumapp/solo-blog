title: ajax请求成功后的json字符串处理
date: '2017-05-11 10:09:48'
updated: '2017-05-11 10:09:48'
tags: [javascript, ajax]
permalink: /articles/2017/05/11/1494467908358.html
---
### ajax请求成功后的json字符串处理

>  通常而言，ajax的数据请求是双向的，意思就是服务端要处理前台的数据，同时前台也需要对服务端传递的数据进行处理，这里我注意了一下javascript对服务端传递过来的json字符串的处理。

#### 服务端返回的json

![1.pic.jpg](http://oss.fangxinqian.cn/64eb98d295d446b7939472b59a47f94c.jpg)

#### 错误的前台javascript代码

	$(function () {
		window.onload = function () {
			$.ajax({
				'url': $.lmParam.initDataUrl,
				'method': 'get',
				success : function (data) {
					  $(data).each (function (){
					  console.log(this);
					  });
				}

			});
	  }

	});
	
当然了，上面的代码是有错误的，前台的回应是无法识别后台传递的json

![2.pic.jpg](http://oss.fangxinqian.cn/927b653d881a40c9893cb308ec583328.jpg)

#### 正确的处理方式

通过eval函数处理后台返回的数据即可正常识别。

	$(function () {
		window.onload = function () {
			$.ajax({
				'url': $.lmParam.initDataUrl,
				'method': 'get',
				success : function (data) {
					data = eval(data);
					$(data).each (function (){
									  console.log(this);
					});
					}

				});
	  }

	});