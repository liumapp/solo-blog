title: 干货——Spring-Security-Mybatis-Demo
date: '2018-02-05 14:31:48'
updated: '2018-04-25 16:24:45'
tags: [Java]
permalink: /articles/2018/02/03/1517659378683.html
---
> SpringBoot下结合Mybatis，实现SpringSecurity的权限认证Demo，与传统RBAC不同之处在于：这里我们省略了A这个环节。同时又有别于其他的SpringSecurity项目，区别在于：同时考虑了企业用户和个人用户，企业用户可以分配子账户，并对子账户设置不同的角色，每个角色可执行的权限范围由注解来进行限制，同时，企业用户及其子账户通过邮箱进行登录，而个人账户则通过手机号码进行登录。

## 前言

按照惯例，先上项目源代码：

Github: [spring-security-mybatis-demo](https://github.com/liumapp/spring-security-mybatis-demo)

项目ER图如下所示：

![er.jpg](http://oss.fangxinqian.cn/a1ccc30720de4399acd78d1b75acc087.jpg)

看完ER图，相信各位应该能清楚一件事情：

跟传统的RBAC相比，这里没有A（Access）。

我们只对用户进行角色的区分，具体哪一个角色具备哪些权限，由注解来决定，如：

	@PreAuthorize("hasRole('ROLE')")

## 运行

首先，请给项目Demo一颗Star ^-^ （不然会有人在后面画圈圈诅咒你）

这个项目对用户做了区分：个人用户和企业版用户。

### 个人用户

授权路径： auth/personal

授权刷新路径：refresh/personal

授权登录名：User表下的手机号码

#### 个人用户授权

个人用户使用手机号码及密码在auth/personal下获取他们的授权token：

![personal_login.jpg](http://oss.fangxinqian.cn/df3e4773cdd14c999888a629bfbf82f3.jpg)

授权成功后，个人用户只会有一个角色，就是：PERSONAL。

这意味着其他角色的API该个人用户将无法访问。（报401错误，当然，您可以自行修改错误代码，比如返回登录页面）

同时也意味着，每一个用户，可以拥有多个角色，这将有助于我们对角色等级的划分进行区分。

比如，最高等级的BOSS用户，也将同时是一个MANAGER用户，同时也是一个EMPLOYEE用户。

这样设计的好处在于，我们在进行权限判断的时候，只需考虑最低等级的权限，高权限的用户直接可以调用。

#### 个人用户认证

个人用户获取他们的Token之后，在使用中，只需要向请求Header中，添加一个"Authorization"，其值应该设置为:"Bearer " + ${token}，请注意这里有一个空格的存在。

![personal_coming.jpg](http://oss.fangxinqian.cn/ababf5951c734661a88fbc35064b26e1.jpg)

### 企业版用户

企业用户使用邮箱及密码在auth/Company下获取他们的授权token：

对于企业用户而言，默认的SQL对角色设置了三个：BOSS、MANAGER、EMPLOYEE，对于离职员工而言，只需要在User表下的isenabled中设置为0即可。

当然，您也可以自行进行角色的扩展，数量不受限制。

#### 企业用户授权

这里以BOSS角色的帐号进行授权演示：

![get_boss_token.jpg](http://oss.fangxinqian.cn/bd6aa99dd4fc48f0b2d7beeb10fa70aa.jpg)

如果您是一名Manager用户，那么获取Token的过程就会是：

![manager_login.jpg](http://oss.fangxinqian.cn/5bed1a11118d4f79a29205e36b4ef1e2.jpg)

#### 企业用户认证

企业用户获取他们的Token之后，在使用中，只需要向请求Header中，添加一个"Authorization"，其值应该设置为:"Bearer " + ${token}，请注意这里有一个空格的存在。

这一点与个人用户的登录是一致的。

接下来的使用就比较简单了：

* BOSS用户调用他的专属API：

	![boss_coming.jpg](http://oss.fangxinqian.cn/91a90e236c13472692dc573005b53c6b.jpg)
	
* 经理调用他的专属API：（当然，BOSS也是可以调用的，因为在User_role表中，请注意看，我们的BOSS用户拥有其他所有角色的roleID）

	![manager_login.jpg](http://oss.fangxinqian.cn/5bed1a11118d4f79a29205e36b4ef1e2.jpg)
	
* 经理想调用BOSS的专属API：

	![manager_want_boss_greeting.jpg](http://oss.fangxinqian.cn/6a42150924c14586a912e02283e8bab5.jpg)


