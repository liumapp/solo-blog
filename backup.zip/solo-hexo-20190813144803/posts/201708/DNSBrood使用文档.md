title: DNSBrood使用文档
date: '2017-08-17 09:52:58'
updated: '2017-08-17 09:55:01'
tags: [DNS, Java, dnsJava]
permalink: /articles/2017/08/16/1502876150467.html
---

> DNSBrood是一个基于dnsJava的域名解析系统。

**项目源码:[DNSBrood](https://github.com/liumapp/DNSBrood)**

### 安装

* 在Github上star本项目

* 下载项目源码到本地任意目录（请确保您的操作系统为Linux/Unix）

* 在项目根目录下执行

		chmod -R 777 make.sh dnsbrood.sh
		
* 执行./make.sh

* 执行

		cd /usr/local/DNSBrood
		
* 启动命令

		dnsbrood.sh start
		
* 重启命令

		dnsbrood.sh restart
		
* 停止命令

		dnsbrood.sh stop
		
* 测试：（使用dig测试工具）

		dig @127.0.0.1 test.liumapp.com

	如果出现反馈信息：

		sh-3.2# dig @127.0.0.1 test.liumapp.com

		; <<>> DiG 9.8.3-P1 <<>> @127.0.0.1 test.liumapp.com
		; (1 server found)
		;; global options: +cmd
		;; Got answer:
		;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 2998
		;; flags: qr rd; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 0
		;; WARNING: recursion requested but not available

		;; QUESTION SECTION:
		;test.liumapp.com.		IN	A

		;; ANSWER SECTION:
		test.liumapp.com.	2000	IN	A	1.2.3.4

		;; Query time: 49 msec
		;; SERVER: 127.0.0.1#53(127.0.0.1)
		;; WHEN: Thu Aug 17 09:03:20 2017
		;; MSG SIZE  rcvd: 50

	那表明安装成功

### 使用

在使用DNSBrood上有两种方式，一种是直接修改config目录下的zones文件，另一种是通过DNSQueen项目，以字符串指令的形式来管理。

这篇文档纪录的使用方式为后者。

或者您可以通过DNSBee项目在web图形界面上进行DNS解析的管理。

在项目源码的test目录下，找到ZonesFileRefresherTest这个Junit测试单元，我们运行testAdd方法，即可在DNSBrood中添加一条test2.liumapp.com的解析纪录。同样的，改Junit测试单元还包含了update、delete、select、multyDelete等等测试方法，基本涵盖了我们常用的CURD操作。

添加解析示例：
运行代码：

	Queen  queen = new  Queen();
	try  {
		queen.connect();
		queen.say("add_zones_ip_LM09000:4.5.6.7 test2.liumapp.com");
		System.out.print(queen.hear());
	} catch  (IOException  e) {
		e.printStackTrace();
	}
	
成功返回值：

	SUCCESS, 1 patterns added.
	
测试：

	dig @127.0.0.1 test2.liumapp.com
	
返回：

	sh-3.2# dig @127.0.0.1 test2.liumapp.com

	; <<>> DiG 9.8.3-P1 <<>> @127.0.0.1 test2.liumapp.com

	; (1 server found)

	;; global options: +cmd

	;; Got answer:

	;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 45092

	;; flags: qr rd; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 0

	;; WARNING: recursion requested but not available

	;; QUESTION SECTION:

	;test2.liumapp.com.  IN  A

	;; ANSWER SECTION:

	test2.liumapp.com.  2000  IN  A  4.5.6.7

	;; Query time: 0 msec

	;; SERVER: 127.0.0.1#53(127.0.0.1)

	;; WHEN: Thu Aug 17 09:50:44 2017

	;; MSG SIZE rcvd: 51



