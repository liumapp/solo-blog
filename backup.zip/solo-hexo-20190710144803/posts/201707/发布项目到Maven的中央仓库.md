title: 发布项目到Maven的中央仓库
date: '2017-07-17 10:33:51'
updated: '2018-11-22 08:33:19'
tags: [Github, Maven]
permalink: /articles/2017/07/17/1500257349266.html
---
> 最近在研发一套DNS Server，项目比较大，有部分模块被拆分出来做为独立的板块研发。然后通过Maven进行管理，可问题来了，我自己写的maven项目在maven的中央仓库下载不到呀...怎么办，上传到maven的中央仓库呗。

### 前言

我之前写过一篇博文[通过Github与Packagist建立联动关系来解决Github上composer资源包的依赖问题](http://www.liumapp.com/articles/2017/04/19/1492569053223.html)，里面讲的是发布项目到Composer的中央仓库，Composer跟Maven是类似的两款产品，所以在刚开始的时候，我以为上传到Maven中央仓库的操作，同样可以通过简单几句命令和Github的几项配置就能够实现，但是后来发现大错特错。

### 准备

首先我们需要跟这两个网站打交道：

* https://issues.sonatype.org

* https://github.com

* https://oss.sonatype.org

Github大家应该都知道，我们首先把要发布的项目放到Github上，这应该也很容易理解，那么sonatype又是一个什么鬼呢？

光看sonatype估计一脸蒙蔽，因为我刚看到的时候也是二脸蒙蔽。但是去人家官网https://www.sonatype.com/上一看，大名鼎鼎的Nexus在人家的产品列表上摆着呢...

https://oss.sonatype.org顾名思义，就是sonatype专门的仓库地址了。

### 干活

好了，废话不多说了，我们在https://issues.sonatype.org先注册登录，然后进入后台。

不出意外应该长这个样子：

![1.pic_hd.jpg](http://oss.fangxinqian.cn/2238189ed06e4627b21a746cfed823c4.jpg)

最上面的导航栏左边数起最后一个有一个“Create”按钮，点它，然后按照下图进行填写：

![2.pic.jpg](http://oss.fangxinqian.cn/417ceefd73314f5a8f5fb70053912a0f.jpg)

然后点击"Create"

提交成功的话，我们可以在issues->Create Recently页面里面找到刚刚创建的issue（虽然我也不明白它为什么要全部称之为issue）。我这里的视图如下：

![3.pic_hd.jpg](http://oss.fangxinqian.cn/f6bb8f98e7a64917afeac3a78f3d1820.jpg)

### 等待

好，接下来就是等待sonatype的审核通过，然后审核通过后一般还要再过三天左右才能够在Maven的中央仓库去下载它，嗯就是这样。

我过了一天就收到了审核通过的通知：

![1.pic.jpg](http://oss.fangxinqian.cn/6f2430e505cc47eda3b21554b4e5064f.jpg)

上面的意思就是，我现在可以把项目包上传到他们的中央仓库并给其他人下载了。


### 上传

接下来我们要进入https://oss.sonatype.org这个网站，利用自己先前注册的账号登录即可。其首页如下：

![2.pic.jpg](http://oss.fangxinqian.cn/c6395f2211c142eeabdc9400f2d7bfdc.jpg)

然后我们点击"Staging upload"这个按钮。

在它的页面如下填写信息：

![3.pic.jpg](http://oss.fangxinqian.cn/665c8820bbd64f9ca4dbf5ddd7c8700a.jpg)

其实就是上传项目的pom文件跟jar包，然后写一下项目的介绍即可。

这里要注意一件事情：

项目的version不能够是SNAPSHOT，如果为SNAPSHOT那么会提示上传失败。

上传成功后，我们点击"Staging Repositories"，一切顺利的话就能够找到我们刚刚上传的项目

![4.pic_hd.jpg](http://oss.fangxinqian.cn/004a8d56bba1416a8e004447a65bcf08.jpg)

好，做到这一步我们就成功的把项目上传到Maven的私服了，但是这个时候还不能够在Maven的中央仓库搜索到我们的项目，还需要release它：

### release

![5.pic_hd.jpg](http://oss.fangxinqian.cn/9e1b0d7853d64a5da5044dd99d0208fc.jpg)

做完这一步，再过几个小时，我们应该就能够在Maven的中央仓库搜索到自己上传的项目了。

不过，在此之前，还要回到https://issues.sonatype.org上面，告诉那个管理员我们的第一次提交已经成功了，毕竟人家那么客气的说让我们通知他一下：

![6.pic.jpg](http://oss.fangxinqian.cn/2fbec6ce98874bbc90cbc97f1d3e16c7.jpg)

### 报错

可能因为时差的关系（我们白天而人家是黑夜），我等了一天才等到对方的答复，很不幸的是，报错了：

![1.pic.jpg](http://oss.fangxinqian.cn/6b904f3009c94cd4bd846d2984be2249.jpg)

经过检查，发现，上传到maven中央仓库的项目要求具备以下条件：

* pom文件要求具备：
	* description描述信息
	* licenses证书信息
	* developers开发人员信息
	* scm版本管理信息
	* distributionManagement分发构件的信息

* 项目本身要求具备：
	* javadoc文档信息
	* sources-jar包

### 修改pom

pom.xml中添加以下信息：

	<build>
	  <plugins>
		 ......
		<plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-javadoc-plugin</artifactId>
        <version>2.10.3</version>
        <executions>
          <execution>
            <id>attach-javadocs</id>
            <goals>
              <goal>jar</goal>
            </goals>
          </execution>
        </executions>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-source-plugin</artifactId>
        <executions>
          <execution>
            <id>attach-sources</id>
            <goals>
              <goal>jar-no-fork</goal>
            </goals>
          </execution>
        </executions>
      </plugin>
	  </plugins>
	</build>

	<licenses>
	  <license>
		<name>GNU General Public License v3.0</name>
		<url>http://www.gnu.org/licenses/agpl-3.0.html</url>
		<distribution>repo</distribution>
		<comments>A socket manager</comments>
	  </license>
	</licenses>

	<developers>
	  <developer>
		<name>liumapp</name>
		<url>http://www.liumapp.com</url>
		<email>liumapp.com@gmail.com</email>
	  </developer>
	</developers>

	<scm>
	  <connection>scm:git:https://github.com/liumapp/DNSQueen.git</connection>
	  <developerConnection>scm:git:https://github.com/liumapp/DNSQueen.git</developerConnection>
	  <url>https://github.com/liumapp/DNSQueen</url>
	  <tag>v${project.version}</tag>
	</scm>

	<distributionManagement>
	  <snapshotRepository>
		<id>ossrh</id>
		<url>https://oss.sonatype.org/content/repositories/snapshots</url>
	  </snapshotRepository>
	  <repository>
		<id>ossrh</id>
		<name>Maven Central Staging Repository</name>
		<url>https://oss.sonatype.org/service/local/staging/deploy/maven2/</url>
	  </repository>
	</distributionManagement>

重新编译项目。

### 重新上传

如图，将缺少的jar包上传：

![2.pic.jpg](http://oss.fangxinqian.cn/305d96767d1a4d7b864864ad4b9e6a73.jpg)

这次上传成功后，没有马上通知管理员，我自己先去看看有没有错误，结果一看，又有错误...

![3.pic.jpg](http://oss.fangxinqian.cn/c834b134405a44d491943d3f1f779ca4.jpg)

这个问题百思不得其解，我尝试从上传项目上入手，改用sonatype提供的maven插件来上传项目试试。

### 另一种上传方式

首先我们需要确保本地有gpg这个工具，然后再利用它来上传，这些步骤占用的文章篇幅比较长，所以我将它单独写了一篇博文出来：[gpg的安装使用](http://www.liumapp.com/articles/2017/07/20/1500521485758.html)

使用这个工具上传项目之后，Repositories下面没有再报任何错误。所以，sonatype上面的upload功能就是一个坑呀.....

然后再一次的通知管理员，等待...

成功的通知：

![6.pic.jpg](http://oss.fangxinqian.cn/a53c69256b664163a67cdd3270cadf93.jpg)

### 成功截图

![1.pic.jpg](http://oss.fangxinqian.cn/e6fbe8cfe2fa4530bd4f7faf1fa562f3.jpg)

### 更新版本

更新的方法很简单，写好新版本的代码后，打一个Github的tag，再把pom.xml的version变一下，再使用跟上传同样的命令：

	mvn deploy -Dmaven.test.skip=true  -e
	
就可以了。

![9.pic.jpg](http://oss.fangxinqian.cn/b4799cc196ce4880ad8e95a9dd0a6107.jpg)
