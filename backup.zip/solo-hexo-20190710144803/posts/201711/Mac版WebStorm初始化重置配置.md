title: Mac版WebStorm初始化/重置配置
date: '2017-11-01 11:52:16'
updated: '2017-11-01 11:52:16'
tags: [Mac, WebStorm]
permalink: /articles/2017/11/01/1509508105179.html
---
> 今天上午设置WebStorm的一个Live Template ， 设置完成后发现项目里面所有的文件语法高亮全部消失，莫名的感到不快，尝试了各种办法也无法恢复，那好吧，就将我的WebStorm初始化吧。请各位注意，这里说的并不是简单的Theme、font这些初始化，而是整个WebStorm所有的配置全部回到默认的状态，包括你的注册码信息（是的，全部初始化后，你的注册码也要重新填）。

### 前言

首先，吐槽一下坑爹的百度，浪费了我一个多小时的时间查找到了一堆没用的信息。

其次，感谢JetBrains官方详细的说明。

好了，废话不多说了。

### 重置

* 关闭WebStorm

* cd ~/Library/Preferences/ (请注意，这里的～表示进入你的账号根目录，不是root账号的根目录，而是安装了WebStorm的使用者账号根目录，比如你的Mac登陆账号为hahaha，那么这个账号根目录就是：/Users/hahaha)

* rm -rf WebStormXX 这个XX视你的WebStorm版本来定。

* 搞定，重新启动WebStorm，会发现所有的配置全部还原了。

### 激活

当然了，WebStorm会重新回到试用期的状态，所以这里我贴一个可以使用的激活地址：

	http://idea.iteblog.com/key.php