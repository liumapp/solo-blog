title: DNSBrood开发日志——UDP模块的DNSQueen无响应问题
date: '2017-07-26 09:22:59'
updated: '2017-07-26 09:22:59'
tags: [Java, dnsJava, DNS]
permalink: /articles/2017/07/26/1501032027293.html
---
> 这个问题只发生了一次，暂时还没有找到原因和解决方案，先留一个坑

### 问题描述

第二天一早检查系统，发现负责UDP模块的DNSQueen项目无响应，日志上也没有发现任何异常报出...

且使用

	lsof -i:40310 
	
得到程序的pid后使用kill命令无法杀死。

在使用

	kill -9 pid
	
后才可以杀死进程。

重启程序后恢复正常。

### 解决方案

暂时没有找到，留一个坑。