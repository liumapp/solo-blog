title: CentOS7默认使用Firewall作为防火墙及其常用命令
date: '2017-04-24 16:12:34'
updated: '2017-06-20 16:23:13'
tags: [Linux, CentOS, Firewall]
permalink: /articles/2017/04/24/1493020965357.html
---
>  一时心血来潮，把一台服务器的CentOS升级到了7版本，结果发现ftp服务无法进行远程链接，通过排查错误，最终发现，CentOS7默认的防火墙不再是iptables，而是firewall。

### 开通常用端口

对于开启ftp服务而言，我们最需要的就是20和21端口（20端口涉及到ftp-data），话不多说，直接上代码：

	firewall-cmd --add-port=20/tcp --permanent

	firewall-cmd --add-port=20/udp --permanent

	firewall-cmd --add-port=21/tcp --permanent

	firewall-cmd --add-port=21/udp --permanent

	systemctl restart firewalld.service
	
开启20和21端口的介绍没有问题，那最后一个systemctl是个什么鬼？没错，CentOS下面默认也不使用service和sysConfig，而是通过systemctl来实现软件的start,stop,restart等常用的操作，简单点说，就相当于把service和sysConfig两个命令合并到一个systemctl里面。

### 基本命令

启动： systemctl start firewalld

查看状态： systemctl status firewalld 

停止： systemctl disable firewalld

禁用： systemctl stop firewalld