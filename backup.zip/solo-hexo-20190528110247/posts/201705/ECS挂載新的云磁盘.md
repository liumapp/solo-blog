title: ECS挂載新的云磁盘
date: '2017-05-23 14:27:03'
updated: '2017-05-23 14:27:03'
tags: [Linux, ECS, 阿里云]
permalink: /articles/2017/05/23/1495519927741.html
---
### ECS挂載新的云磁盘

> 阿里云ECS服务器空间不够用，直接扩容系统盘成本比较高，所以这里选择了直接挂载一块新的云磁盘

### 购买云磁盘

这一步不多说了，直接傻瓜式操作：

![7.pic.jpg](http://oss.fangxinqian.cn/605ff0d6a9fb415d8ba4e4d2351473ad.jpg)

### 格式化和挂载

这个需要我们登陆系统，用以下指令去完成

首先我们来检查下，新的磁盘在没在。

如图执行命令  

	fdisk -l

![8.pic.jpg](http://oss.fangxinqian.cn/5f85f47c77eb42bc9bda740a091acca1.jpg)

可以看到，新的磁盘已经在这里了。

下面我们对磁盘进行分区

	fdisk /dev/xvdb
	
![9.pic.jpg](http://oss.fangxinqian.cn/f21d576c53624c769b49ed1858438d0c.jpg)

分区后我们在运行命令来检查一下

	fdisk -l
	
![10.pic.jpg](http://oss.fangxinqian.cn/d78c5c1ba79e4421b28a1532ed46071f.jpg)

看到/dev/xvdb1就表明新的分区已经建立好了。

接下来就是对新的分区进行格式化

	mkfs.ext3 /dev/xvdb1
	
格式化的时间取决于磁盘大小

![11.pic.jpg](http://oss.fangxinqian.cn/a429ff9f56824d608f74aa494e4160ea.jpg)

我40G磁盘大概20秒的样子

我们再把分区信息写到/etc/fstab里面。

	 echo /dev/xvdb1 /mnt ext3 defaults 0 0 >> /etc/fstab

![12.pic.jpg](http://oss.fangxinqian.cn/562d95d4fae74048ae1cd0a0870a350a.jpg)

最后我们把新的分区挂载到系统上

	mount /dev/xvdb1 /mnt
	
![13.pic.jpg](http://oss.fangxinqian.cn/aa0e3d8433564e04a7b697197dbe08a9.jpg)

可以看到，新的磁盘已经挂载成功啦，可以使用啦。