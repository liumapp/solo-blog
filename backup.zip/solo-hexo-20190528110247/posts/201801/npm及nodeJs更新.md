title: npm及nodeJs更新
date: '2018-01-17 09:34:11'
updated: '2018-01-17 09:34:11'
tags: [nodeJs]
permalink: /articles/2018/01/17/1516152851218.html
---
> 是我落后了吗，今天拉的vue项目居然说我node版本太低....

## 直接上跟新命令

### 更新npm

	npm update -g
	
#### 检查

	npm -v

### 更新node

	npm install -g n 

	n latest
	
#### 检查

	node -v
	
## 再贴一下错误信息

	To use this template, you must update following to modules:

	  node: 7.8.0 should be >= 8.1.4
	  npm: 4.2.0 should be >= 5.3.0


	npm ERR! Darwin 15.6.0
	npm ERR! argv "/usr/local/Cellar/node/5.8.0/bin/node" "/usr/local/bin/npm" "run" "dev"
	npm ERR! node v7.8.0
	npm ERR! npm  v4.2.0
	npm ERR! code ELIFECYCLE
	npm ERR! errno 1
	npm ERR! plantuml-editor@1.0.0 dev: `node build/dev-server.js`
	npm ERR! Exit status 1
	npm ERR! 
	npm ERR! Failed at the plantuml-editor@1.0.0 dev script 'node build/dev-server.js'.
	npm ERR! Make sure you have the latest version of node.js and npm installed.
	npm ERR! If you do, this is most likely a problem with the plantuml-editor package,
	npm ERR! not with npm itself.
	npm ERR! Tell the author that this fails on your system:
	npm ERR!     node build/dev-server.js
	npm ERR! You can get information on how to open an issue for this project with:
	npm ERR!     npm bugs plantuml-editor
	npm ERR! Or if that isn't available, you can get their info via:
	npm ERR!     npm owner ls plantuml-editor
	npm ERR! There is likely additional logging output above.

	npm ERR! Please include the following file with any support request:
	npm ERR!     /var/root/.npm/_logs/2018-01-17T01_19_37_601Z-debug.log
