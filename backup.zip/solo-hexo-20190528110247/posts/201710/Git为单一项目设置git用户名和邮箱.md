title: Git为单一项目设置git用户名和邮箱
date: '2017-10-25 20:23:45'
updated: '2017-10-25 20:23:45'
tags: [GitLab, Github]
permalink: /articles/2017/10/25/1508933894966.html
---
> 自己有自己的开源项目，工作有工作的闭源项目，两者往往通过不同的Git帐号进行commit操作，那如何为不同的项目设置不同的Git帐号呢？

我们一般的操作都是:

	git config --global user.name
	git config --global user.email

这两步来设置Git帐号名与邮箱，但是针对特定项目，比如：

我Git的global用户名是liumapp，但在B项目下想使用lm这个用户名来进行提交。

这种情况下，我们需要进行下列操作：

* cd .git

* vim config

* 添加下列代码：

		[user]
			name=lm
			email=lm@liumapp.com
			
* :wq保存文件将立即生效，执行commit即可发现提交的用户为lm。

