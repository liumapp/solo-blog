title: Mac上使用IDEA部署Solo
date: '2017-02-28 21:58:47'
updated: '2017-03-01 10:47:11'
tags: [Mac, IDEA, Solo, Maven]
permalink: /articles/2017/02/28/1488287718829.html
---
**原创，转载请申明出处。**

IDEA版本：2016.3.4
Solo版本：1.9.0
Maven版本：3.0.5
jdk版本：1.7

1.   安装IDEA，[IDEA官网](http://www.jetbrains.com/idea/)下载正版。
2.   配置jdk1.7版本，此处请注意，之所以使用1.7版本的jdk，是因为solo项目下的pom.xml文件指定了要使用1.7版本的jdk：<source>1.7<source>，那么再根据jdk版本选择适配的maven版本即可，这里使用3.0.5，亲测可用。
3.   配置Maven3.0.5，下载并解压Maven之后，我的Maven解压在/usr/local/maven目录下，在Mac命令行下依次输入以下命令：
		<code class='java hljs'>
		sudo su //以root身份运行
		enter your password here //输入你的密码
		cd ~ 
		vim .bash_profile //配置环境变量
		让.bash_profile文件至少存在以下内容：
		   export PATH=$PATH:/usr/local/tomcat/bin/
		   export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home
		   export CLASS_PATH=/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/lib/
		   export PATH=$PATH:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/bin/
		   export M2_HOME=/usr/local/maven
		   export PATH=$PATH:/usr/local/maven/bin
	    保存.bash_profile ， vim下保存并退出的命令为:wq
		source .bash_profile
		mvn -v //如果这则指令输入后打印出了maven的版本信息，那么恭喜你配置成功了。
		</code>
4.   在IDEA上新建project，一直使用eclipse的童鞋请注意，IDEA的project就是eclipse的workspace，IDEA的module才是eclipse的project。这里，我在系统目录/usr/local/tomcat下新建一个名为project的project。
5.   project下建一个目录，命名为solo，并将[Github:solo](https://github.com/b3log/solo)项目源码下载过来。
6.   新建project之后，在IDEA依次执行: file -> new -> module from existing sources -> maven 然后选择project目录下的solo，接下来默认next即可。
7.   使用命令行回到/usr/local/tomcat/project/solo目录，执行mvn install 。执行完后回到IDEA，配置好tomcat server 即可运行，此处要注意，如果变更了默认web端口，那么需要相应修改src/main/resources/latke.properties文件的serverPort值。

