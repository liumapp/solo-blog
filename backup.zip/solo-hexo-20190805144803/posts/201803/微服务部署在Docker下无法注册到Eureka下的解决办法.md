title: 微服务部署在Docker下无法注册到Eureka下的解决办法
date: '2018-03-08 09:36:45'
updated: '2018-03-10 14:35:07'
tags: [Docker, Java]
permalink: /articles/2018/03/08/1520472997932.html
---
> 多个微服务部署到Docker下之后，往往会出现一个问题，那就是原本能够正常被服务提供者注册的Eureka突然没办法接受到它们的注册信息。

## 前言

一般而言，我们的微服务集群中必不可少的一个模块就是服务注册中心Eureka。

我们对它地址的配置一般都是:

	eureka.client.serviceUrl.defaultZone=http://localhost:1234/eureka/
	
在IDEA或者主机上编译部署后项目也能够正常运行，可是一旦放入Docker中，很奇怪的事情就发生了：其他的服务没办法注册到Eureka上。

好了不说其他的了，先上项目源代码：[simple-docker-demo](https://github.com/liumapp/simple-docker-demo)

打开这个项目，看Readme找到最后一栏的“use Docker Compose for multy project”，然后按照步骤执行即可。

## 解决办法

其实问题产生的原因很简单，因为bridge是Docker默认的网络模式，换句话说，我一个host上的各个container从docker获取的IP都是不一样的（在主机编译部署后大家都是localhost，但是在docker里面情况就不一样了）。

所以再使用http://localhost:1234/eureka/这个值肯定是找不到Eureka的地址。

怎么办呢，可以利用docker的主机名来解决。

我们只需要为Eureka所在的container配置一个主机名即可，比如我们配置为eureka-server

那么再将其他的微服务的配置进行如下修改：

	eureka.client.serviceUrl.defaultZone=http://eureka-server:1234/eureka/
	
就可以解决问题。