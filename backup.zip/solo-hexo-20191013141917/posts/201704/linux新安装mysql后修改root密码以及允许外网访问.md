title: linux新安装mysql后修改root密码以及允许外网访问
date: '2017-04-26 09:54:05'
updated: '2017-04-26 09:54:05'
tags: [Linux, Mysql]
permalink: /articles/2017/04/26/1493171642066.html
---
### linux新安装mysql后修改root密码以及允许外网访问

直接上代码

	mysql -u root -p

	enter your password 

	use mysql;

	update user set password=password('yournewpassword') where user='root';

	flush privileges;

	grant all on *.* to root@"%" identified by "yourpassword";

	flush privileges;