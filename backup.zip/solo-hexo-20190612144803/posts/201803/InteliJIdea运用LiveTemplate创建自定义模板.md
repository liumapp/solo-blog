title: InteliJIdea运用LiveTemplate创建自定义模板
date: '2018-03-16 09:09:19'
updated: '2018-03-16 09:09:19'
tags: [IDEA]
permalink: /articles/2018/03/16/1521162175217.html
---
> Idea的liveTemplate是一个很好用的工具，写一篇简短的文章记录它的使用

一张图就能够大致看明白怎么去使用它

![1.pic_hd.jpg](http://oss.fangxinqian.cn/4960d6cc4c4a4ee29d9d337b2394e26d.jpg)

* 首先我们可以自定义一个Group
* 然后创建该Group下的item
* 填写触发条件，图中所示的触发条件便是先输入"/**"然后按tab键
* 触发条件产生后，内容便会自动填充到我们的文件里面（文件类型自定义，见图中的最下方那一行小字）

