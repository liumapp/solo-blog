title: MacOS配置Docker阿里云加速器
date: '2018-01-20 22:45:55'
updated: '2018-01-20 22:45:55'
tags: [Docker, Mac]
permalink: /articles/2018/01/20/1516459095592.html
---
> 不知道是家里网不好，还是怎么回事，总之这阵子访问 Docker Hub 非常不稳定...好了，废话不多说，这篇博文记录了在Mac下，对Docker配置阿里云加速器的过程。

## 操作步骤

* 登陆阿里云后台，并访问该页面：

		https://cr.console.aliyun.com/#/accelerator

* 根据阿里云提供的文档来操作，我这边的操作步骤如下：

	* 拷贝阿里云提供的专属加速器地址，我的地址是：

			https://lpikn7jh.mirror.aliyuncs.com
			
	* 右键点击桌面顶栏的 docker 图标，选择 Preferences ，在 Daemon 标签（Docker 17.03 之前版本为 Advanced 标签）下的 Registry mirrors 列表中将 https://lpikn7jh.mirror.aliyuncs.com 加到"registry-mirrors"的数组里，点击 Apply & Restart按钮，等待Docker重启并应用配置的镜像加速器。
	
		相关截图如下所示
		
		

		  ![2.pic.jpg](http://oss.fangxinqian.cn/2e0f3d2a011d4e878552a32c33d9c22d.jpg)
		  
		  以及

		  ![3.pic.jpg](http://oss.fangxinqian.cn/dc64e855f3764dee8ee4e77a30e4d435.jpg)
		  

* Docker重启生效后即可正常使用了。