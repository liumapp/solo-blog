title: Hello,Whmcs and Webnic
date: '2017-05-20 16:02:36'
updated: '2017-05-20 16:02:36'
tags: [Webnic, whmcs]
permalink: /articles/2017/05/20/1495251722456.html
---
### Hello,Whmcs and Webnic

> 对于每一家想做域名销售系统的公司而言，第一件事情便是成为域名注册商或者域名注册商下的经销商，第二件事情才是研发系统，但就国外的情况而言，Whmcs系统是最受欢迎的。所以我们在成为Webnic的经销商之后，选择了Whmcs系统进行定制化开发。

### Whmcs系统安装

* 前往whmcs官网下载最新版本，安装之前需要先有ioncube。我这里选用的是whmcs v7.1.2版本，对PHP的版本要求在5.6以上。

* 安装之后访问http://yourdomain/whmcs/install/install.php，按照提示输入授权码。这里推荐使用正版，毕竟是商业性质的。

* 安装结束后，删除install目录，以及将configure.php.new重命名为configure.php，并赋予写权限。

* 前台地址：http://yourdomain/whmcs，后台地址：http://yourdomain/whmcs/admin

### Whmcs系统配置

* 高版本下的whmcs系统在第一次进入的时候，系统会有引导层引导我们进行配置，如果您使用的版本较低，那么就需要手动配置了。

* 首先是语言，官方提供的语言包里面，没有后台的中文包，所以需要我们手动引入。具体引入方法请参考我的Github项目[liumapp/whmcs-v7.1.2-chinese-language](https://github.com/liumapp/whmcs-v7.1.2-chinese-language.git)

* 系统设置=>常规设置=>一般，在这个页面上必须要进行配置的是域名和系统网址，不然很多扩展的API无法获取到站点URL。

* 系统设置=>常规设置=>域名，这里主要是配置默认的NameServer 1 和 NameServer 2 。

* 系统设置=>付款=>货币设置，系统默认会有一个美元的列，我们对它修改为人民币就可以了。

* 系统设置=>付款=>支付接口，添加支付宝支付，引入方法我之后进行更新，包括如何引入银联支付以及使用composer进行插件的管理。

* 系统设置=>产品设置=>域名注册商，激活 Webnic的选项，填写相关参数。

* 系统设置=>产品设置=>域名价格，配置你要销售的域名种类和价格，然后最好使用Webnic进行自动注册。

* 完成配置，在前台购买域名，购买之后后台审核通过即可使用。

* 这里有一个小插曲，whmcs对于Webnic的域名解析功能是有问题的，所以这一块功能我们是自己研发的，相关流程我会在之后的博文中进行记录。


