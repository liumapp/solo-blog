title: 处理Mysql常见问题之：“Unknown system variab le 'tx_isolation'”
date: '2019-03-20 14:09:46'
updated: '2019-03-20 14:14:05'
tags: [Mysql]
permalink: /articles/2019/03/20/1553062186647.html
---
> 今天在使用mybatis-generator-plugin的过程中，遇到一个异常：Unknown system variable 'tx_isolation'

仔细谷歌了一下，发现这是由于mysql版本更新的问题造成的，我们以前一直习惯于使用mysql5.x版本，但是更新到mysql8.x之后，tx_isolation这个字段被移除掉了，所以产生这个问题

解决办法分两种情况来考虑：

* 具体代码中使用

	如果在具体业务代码中，操作数据库CURD遇到这个异常，只需要更换`mysql-connector-java`的依赖版本即可

	```
	<dependency>
	      <groupId>mysql</groupId>
	      <artifactId>mysql-connector-java</artifactId>
	      <version>8.0.13</version>
	</dependency>
	```
* mybatis-generator-plugin中使用

	如果是在mybatis-generatotr-plugin中使用，遇到这个问题，那么我们需要调整generatorConfig.xml配置文件：

	使用8.x版本的mysql-connector~~~~
	
	````
	<classPathEntry location="C:\Users\lenovo\.m2\repository\mysql\mysql-connector-java\8.0.12\mysql-connector-java-8.0.12.jar"/>
	````