title: whmcs系统插件定制过程中遇到的坑
date: '2017-06-06 16:32:08'
updated: '2017-06-09 14:14:12'
tags: [whmcs]
permalink: /articles/2017/06/06/1496719206719.html
---
> 这是个人开发过程踩过的雷

1. whmcs系统执行install之后，assets、template下的资源文件会有所不同，所以千万别认为他们是资源文件就随意覆盖。我这么干了之后，前台的域名搜索功能被团灭。
	
	解决办法：重新安装来解决问题

2. 在对whmcs进行重新安装的时候，不能指定旧有的数据库，只能创建一个新的数据库，创建新的数据库之后，将原有的数据原封不动拷贝进去，此时，如果系统版本发生变化，那么访问whmcs系统的页面，将会报一个正在更新的错误。

	解决办法：找到tblconfiguration这张表，将Version字段的值改为现有版本的值即可。
	
3. QA文章存放在tblknowledgebase表格下面

4. 在后台配置域名价格时，每一个域名后缀都会在tbldomainpricing表格下面添加一条记录，但是对这个域名后缀配置的域名价格，则记录在tblpricing，两张表格之间通过relid（表示tbldomainpricing的id）进行关联。