title: Directory
date: '2017-03-30 15:04:50'
updated: '2017-03-30 15:05:34'
tags: [PHP, Directory]
permalink: /articles/2017/03/30/1490857490731.html
---
# [Directory](https://github.com/liumapp/directory)

> 这是笔者自造的一个车轮，可用于方便的解决PHP创建／删除目录，创建／删除文件，及对应权限的问题。

## 使用方法

```
$lmD = new Directory();
 $lmD->setBasePath('/usr/local/var/www/');
 $lmD->buildPath('img/a' , 0755);
 $lmD->buildPath('img/b' , 0755);
 $lmD->buildPath('img/c' , 0755);
 $lmD->buildFile('img/a/a.txt' , 0755);
 $lmD->buildFile('img/b/b.txt' , 0755);
 $lmD->buildFile('img/c/c.txt' , 0755);
 $lmD->removeDirs('img/' , ['a']);//img目录下除了a以外其他全部删除掉
```

> 上述代码执行后会产生一个/usr/local/var/www/img/a/a.txt文件，b.txt和c.txt存在过，但之后被删除了。