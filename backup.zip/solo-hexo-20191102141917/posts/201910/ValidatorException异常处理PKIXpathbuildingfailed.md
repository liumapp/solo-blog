title: ValidatorException异常处理-PKIX path building failed
date: '2019-10-21 09:40:09'
updated: '2019-10-30 15:46:02'
tags: [Maven, SSL]
permalink: /articles/2019/10/21/1571622009261.html
---
> Maven下载依赖抛出一个ssl数字证书的异常:PKIX path building failed: SunCertPathBuilderException: unable to find valid certification path to requested target，记录一下这个问题的前因后果即解决办法

## 问题原因

在我这篇博客中：[Maven依赖下载失败的原因及解决方案](https://www.liumapp.com/articles/2018/03/02/1519962410735.html) ，我将maven的仓库地址设置为 'http://maven.aliyun.com/nexus/content/groups/public' ，别看写着是http开头，实际访问，却是一个由GlobalSign Organization Validation CA颁发证书的https站点，而这个ca机构颁发的证书，在jre/lib/security的可信证书容器cacerts中是没有存放过的，所以报出ssl数字证书不可信的异常。

不信，可以使用这条命令：

````shell
keytool -list -keystore $JAVA_HOME/jre/lib/security/cacerts
````

默认密码为： 'changeit'

查阅一遍可信ca名单 ，你看看有没有GlobalSign

## 解决办法

解决办法也很简单，直接将被质疑的证书导入cacerts即可，这一点很多其他博客也说明过，但他们只关注了keytool的命令是如何来导入证书的，并没有跟读者说明该导入的证书如何去获取

### 获取被质疑的证书

* 在mvn抛出PKIX path building failed: SunCertPathBuilderException的日志中，我们也能看到具体是哪一个镜像仓库地址的证书是不可信的，那么用chrome浏览器访问这个站点

* 点击左上角的锁icon -> 证书 ->  详细信息 -> 复制到文件 -> 选择Base64编码的X.509格式，保存证书到本地目录

* 获取证书结束，这里假设你的证书存放路径为 /tmp/caCert.cer

### 导入证书到cacerts

* 执行以下命令

````shell
keytool -import -file /tmp/caCert.cer -keystore $JAVA_HOME/jre/lib/security/cacerts
````

* 输入cacerts密码: changeit 

* 导入成功，结束

## 另一种解决办法

还有一种简单粗暴的简单办法，直接忽视maven对ssl证书的检查，只需要在执行install等命令的后面，添加几个参数即可

示例：

````
mvn clean install -Dmaven.wagon.http.ssl.insecure=true -Dmaven.wagon.http.ssl.allowall=true
````

