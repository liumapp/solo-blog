title: Mac的IDEA上取消重复代码提醒
date: '2017-12-28 09:10:52'
updated: '2017-12-28 09:10:52'
tags: [Mac, IDEA]
permalink: /articles/2017/12/28/1514423452686.html
---
> 时不时发几篇基础性的IDEA配置文...

废话不多说，直接上图：

![2.pic_hd.jpg](http://oss.fangxinqian.cn/6c184bcf52e642cbaaac462fd312c3d5.jpg)

在Inspection->General->Dupl..Code这一栏取消勾选就可以了。

