title: GitHub——ssh免密登录
date: '2018-08-26 14:43:04'
updated: '2018-08-26 14:43:04'
tags: [GitLab, Github]
permalink: /articles/2018/08/26/1535294584243.html
---
> 出于某种原因，原先在GitHub上设定的ssh key无法使用了，因此每一次在我本地提交代码都需要输入username&password，神一般的烦，恰巧又忘记之前是怎么设置的....索性写篇博文记录一下...

其实总共的操作只需要两步，换成人话来说，就是我们自己整一个证明我自己的凭证，然后复制一份给GitHub，告诉它，下次我提交代码给你看这个凭证，你看了后就以我的名义记录这次提交，不要再问账号密码这些鬼东西了...

接下来用实战来介绍

## 在本地创建登录凭证

这里假设您使用的操作系统为Mac OS（如果看官还在使用Windows的话，请弃坑吧）

打开terminal，执行下述命令

	ssh-keygen -t rsa -b 4096 -C "liumapp.com@gmail.com"

此处邮箱地址请填写您的GitHub邮箱地址

接下来一切按照默认值敲回车即可，但是在设置口令的时候，还请留意一下，请千万不要设置口令（不然每次提交都要输入凭证口令，想想都烦）

接下来创建好的ssk key默认会存放在

	/Users/you/.ssh/id_rsa	

这个位置下，但是现在我们还不能直接使用它，使用命令

	eval "$(ssh-agent -s)"	

启动ssh-agent

然后使用命令

	ssh-add -K ~/.ssh/id_rsa

将ssh key加载到ssh-agent工具下，此处的id_rsa为您创建的ssh-key保存文件	

通过检查相关的输出信息，您基本可以确定自己的操作步骤是否成功

## 上传凭证到GitHub

上传凭证只需要三步

* 复制这个文件的内容

		~/.ssh/id_rsa.pub

	这个文件是您的ssh key公钥的内容

	具体复制文件内容命令可以使用

		pbcopy < ~/.ssh/id_rsa.pub

* 打开GitHub的配置页面，选择ssh and gpg keys，创建一个ssh

	标题随便您填，只要内容是复制粘贴过来的即可

* 保存收功

## 友情提示

如果要直接通过ssh上传代码的话，可能您需要对项目做一点点配置

比如，您在项目根目录下，输入命令：

	git remote -v

如果包含了https的话，那么您可能需要切换到ssh进行连接

具体命令为

	git remote set-url origin git@github.com:USERNAME/REPOSITORY.git


