title: 通过Github与Packagist建立联动关系来解决Github上composer资源包的依赖问题
date: '2017-04-19 10:30:53'
updated: '2017-04-19 10:30:53'
tags: [Packagist, Github, Composer]
permalink: /articles/2017/04/19/1492569053223.html
---
> 在Github创建的PHP项目，通常是通过composer进行依赖资源包的管理，然后有些时候自己在git上的项目，别人使用composer下载的时候，报出项目找不到的问题，这个时候，就需要在Github和Packagist之间建立一个联动关系。

### 实践案例

楼主个人在Github上的项目[yii2-library](https://github.com/liumapp/yii2-library/)，便是通过composer进行管理，composer.json的相关配置如下：

	{
	  "name": "liumapp/yii2-library",
	  "description": "common library for yii2",
	  "version":"v1.0.0",
	  "type": "library",
	  "license": "MIT",
	  "authors": [
		{
		  "name": "liumapp",
	  "email": "liumapp.com@gmail.com",
	  "homepage": "http://www.liumapp.com",
	  "role": "Creator"
	  }
	  ],
	  "require": {
		"php": ">=5.4.0",
	  "yiisoft/yii2": "2.0.10",
	  "yiisoft/yii2-bootstrap": "2.0.6",
	  "bower-asset/pace": "^1.0",
	  "bower-asset/fontawesome": "4.7",
	  "bower-asset/bootstrap3-wysihtml5-bower":"*",
	  "bower-asset/bootstrap-datepicker":"v1.6.4",
	  "bower-asset/eonasdan-bootstrap-datetimepicker":"v4.14.30",
	  "bower-asset/select2":"4.0.3",
	  "bower-asset/ztree_v3":"v3.5.26",
	  "bower-asset/echarts":"3.3.2"
	  },
	  "autoload": {
		"psr-4": {
		  "liumapp\\library\\": ""
	  }
	  }
	}
	
然后我们在本地新建一个项目，添加对liumapp/yii2-library的依赖，相关代码如下：

	"require": {
	  "liumapp/yii2-library":"dev-master"
	},
	
然后我们执行 

	composer install

不出意外，命令行会给出以下错误信息：

	The requested package liumapp/yii2-library could not be found in any version, there may be a typo in the package name.
	
### 具体解决方案

登录[packagist官网](https://packagist.org/)，并使用Github帐号登录，然后点击右上角的submit按钮

到自己的Github项目页面上，复制我们的git链接，我这里的链接是 https://github.com/liumapp/yii2-library.git  ，然后填写到packagist下面的submit输入框里

再回到github项目页

*   点击“Settings”
*   点击"Integrations & services"
*   添加一个 "Packagist" service, 然后根据说明进行配置
*   再进行一次commit操作就可以成功关联

操作完后，我们重新执行composer install 便能够成功下载到自己的项目了。