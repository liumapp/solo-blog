title: Docker读写宿主机磁盘文件之Volumes
date: '2018-04-24 10:47:27'
updated: '2019-04-09 13:16:38'
tags: [Java, Docker]
permalink: /articles/2018/04/24/1524534683638.html
---
> Docker容器只是短暂运行的，换句话说，当容器死亡时，其所产生的文件、包括写入磁盘的都会被删除，并且该容器所创建的文件数据一般也仅仅允许容器本身访问。但是Docker本身也提供了Volumes这个概念，来允许容器与宿主机进行磁盘文件上的交互共享，这也包括跟其他容器之间的数据共享，并且共享在Volumes下的文件当容器死亡时并不会被删除。

## 前言

首先上Github项目源代码: [liumapp/docker-compose-demo](https://github.com/liumapp/docker-compose-demo)

这个项目是利用docker-compose进行编排，将Spring Cloud项目部署到Docker中，具体请参考我的另一篇博客（这并不是这篇博客要说的重点）。

这篇博客介绍的重点在于，如何利用Docker的Volumes来实现Docker容器与宿主机进行文件的读写操作，并且确保在该容器死亡后，所产生的文件并不会被删除。

相关Demo的使用请在docker-compose-demo这个项目中把REAdME.md翻到"write file to host demo"和"read and write file from host demo"这一段。

## 配置docker-compose.yml

既然我们是使用Docker-Compose进行的编排，那么直接配置docker-compose.yml的volumes属性便可，如果您的项目是使用的Dockerfile，那么可以在Docker run的时候带上-v参数来进行设置，这里不多叙述。

首先我们需要针对一个指定的Container去配置它的Volumes：

	demo-api-a:
	 image: liumapp/demo-api-a:v1.0.0
	  restart: always
	  container_name: demo-api-a
	  hostname: demo-api-a
	  ports:
	  - "8081:8081"
	  depends_on:
	  - docker-compose-eureka
		- docker-compose-config
	  volumes:
	  - /Volumes:/Volumes

Demo中我们指定了demo-api-a这个容器，配置的Volumes为

	  - /Volumes:/Volumes
	  
"-"	表示这个地方可以配置多个Volumes，第一个"/Volumes"表示宿主机的目录，第二个"/Volumes"表示Docker环境中的目录。

## 分析

这个地方大家需要注意一下，不是所有的宿主机目录都可以共享给Docker。

以Mac OS为例，大家可以在docker的Preferences下面找到File Sharing，来查看哪些宿主机目录是被允许共享的，如果您设置的目录是不被允许的，那么在后续执行:

	docker-compose up -d
	
的时候，将报出错误

第二个"/Volumes"表示Docker环境中的目录，换句话说，就是我在程序中具体操作的目录地址，它也可以是其他的目录地址，比如我设置了"/tmp/project"目录，那么程序中如果在/tmp/project下创建了一个文件，该文件就会被自动拷贝到宿主机的/Volumes目录下。

## 结尾

最后上两个Demo。

大家把docker-compose-demo用命令:

	docker-compose up -d
	
运行起来后，可以分别访问

	http://localhost:2333/demo-api-a/write
  
和

	http://localhost:2333/demo-api-a/read
  
两个地址，前者是直接在/Volumes下创建一个txt文件，并写入一些简单的字符串。

后者是读取之前创建的txt文件，并写入一个新的txt文件。

通过这两个Demo，相信就能够解决我们上面提到的问题。

如果有新的问题，欢迎大家给我留言。

