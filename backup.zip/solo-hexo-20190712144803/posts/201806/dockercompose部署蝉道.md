title: docker-compose:部署蝉道
date: '2018-06-01 12:14:29'
updated: '2018-06-01 12:14:29'
tags: [Docker, PHP]
permalink: /articles/2018/06/01/1527853767811.html
---
> ZenTaoPMS的发布并不难，利用Docker进行部署也很容易，但是利用Docker-Compose一键编排的资料却很少，这篇博客分享的内容，是利用docker-compose实现一键部署蝉道9.8.3开源版本。

## 前言

按照惯例，先上项目源代码：[liumapp/zentao-in-docker](https://github.com/liumapp/zentao-in-docker)


## 环境部署

蝉道9.8.3的环境配置无非经典的LNMP或者LAMP，这里我们选用LNMP（CentOS7+Nginx+Mysql+PHP5.6）。

那么，直接上docker-compose.yml的文件内容:

	version: "2"

	services:
	  mysql:
		container_name: mysql
		image: mysql:5.5.60
		restart: always
		volumes:
		  - ./mysql/data:/var/lib/mysql
		  - ./mysql/conf/mysqld.conf:/etc/mysql/mysql.conf.d/mysqld.cnf
		ports:
		  - 3306:3306
		environment:
		  - MYSQL_ROOT_PASSWORD=adminadmin
		networks:
		  - zentao-server    

mysql的环境配置，需要注意的地方除去端口、密码及volumes之外，便是一个networks了，在docker-compose完成up的瞬间，一个新的networks会用来连接这些services，networks内部的的service可以直接通过service的name进行通讯，比如，我们可以让运行在php5这个service下的蝉道应用通过hostname:mysql来与mysql service建立数据库的连接，而不是用localhost或者127.0.0.1（事实上用localhost或者127.0.0.1也无法建立于mysql的连接，如果它们部署在同一台宿主机上的话）。
		  
	  nginx:
		container_name: nginx
		restart: always
		image: nginx:1.13
		ports:
		  - 80:80
		  - 8080:8080
		  - 443:443
		  - 5050:5050
		  - 5553:5553
		volumes:
		  - ./conf/vhosts:/etc/nginx/conf.d
		  - ./logs:/var/log/nginx
		  - ./www/:/var/www/
		networks:
		  - zentao-server
		  
Nginx的环境配置。

	  php5:
		container_name: php5
		restart: always
		image: php:5.6-fpm
		volumes:
		  - ./www/:/var/www/
		  - ./conf/php/:/usr/local/etc/php/conf.d/
		expose: 
		  - 9000
		networks:
		  - zentao-server
		command: 
		  - /bin/bash
		  - -c
		  - |
			  docker-php-ext-install pdo_mysql mysqli
			  php-fpm

PHP的环境配置，事实上，唯一的难点就在这里。
因为PHP并不是说拉来image，运行成功就完事了，我们还需要让蝉道的代码copy到容器里去，同时配置蝉道所需要的php扩展，最重要的一个便是pdo_mysql（相信很多小伙伴们，对于PHP扩展的安装深感头疼）。但是不要怕，利用docker-compose的命令便可以解决。

	command: 
	  - /bin/bash
	  - -c
	  - |
		  docker-php-ext-install pdo_mysql mysqli
		  php-fpm
		  
这几句命令的格式可能各位会以为是语法有问题，然而事实却是docker-compose下多行命令的写法。

当然，这几个命令的意思是：让php自己去安装pdo_mysql和mysqli的扩展（其实就是phpize、./configure、make、make install、再配置php.ini那一套，只不过这几个命令把它简化了），最后再启动php-fpm去监听9000端口，至于php的配置文件，大家可以参考项目里面的/conf/php下的文件。
			  
	  networks:
		zentao-server:
		  driver: bridge

最后便是给我们的networks起一个名字，方便管理下面的services。

## 结尾

那么最后，简单运行一下

	docker-compose up -d
	
然后在浏览器里面输入http://testc.com:8080/www便可以进入蝉道的安装界面。

当然，您需要稍微修改一下hosts文件，或者不这么做也可以，直接修改/conf/vhosts/zentaopms.conf文件下的server_name及listen端口号也行。
		  

