title: 删除本地已经存在的maven-archetype
date: '2018-03-21 14:31:57'
updated: '2018-03-21 14:31:57'
tags: [Java]
permalink: /articles/2018/03/21/1521613759082.html
---
> 以Mac环境为例，如何删除本地已经存在的maven-archetype项目

## 删除源文件

依次执行下述命令：

	cd ~/.m2/repository
	
在这个目录下，一般能够找到各种类型的文件夹，命名规则为项目的Group ID从前到后。

找到自己要删除的archetype项目，删除即可

	rm -rf ${your_archetype_project}


## 删除配置

还是在刚刚的目录

	cd ~/.m2/repository
	
我们使用vim打开配置文件：archetype-catalog.xml

在archetypes节点下找到自己要删除的archetype节点，删除这一段配置即可。