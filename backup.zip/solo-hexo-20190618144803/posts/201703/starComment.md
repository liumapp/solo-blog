title: starComment
date: '2017-03-03 14:40:42'
updated: '2017-03-22 17:06:16'
tags: [less, gulp, bower, nodeJs, javascript]
permalink: /articles/2017/03/03/1488522734468.html
---
展示效果
1. ![a0331c4f5ae744f191d1cd5eb03e51a9-1.pic.jpg](//om40sen9v.bkt.clouddn.com//file/2017/3/a0331c4f5ae744f191d1cd5eb03e51a9-1.pic.jpg) 
2. ![dd080a6db8994ccc93b40f3eeacb78c9-2.pic.jpg](//om40sen9v.bkt.clouddn.com//file/2017/3/dd080a6db8994ccc93b40f3eeacb78c9-2.pic.jpg) 

**说明：**

这是一个特别简单的html打分评价效果，通过nodeJS＋bower＋gulp＋less这一套前端自动化开发框架来实现，对于感兴趣的童鞋来说是一个很好的学习教材。

开发者如何使用：

1. 首先本机要有nodeJs环境；
2. 在项目根目录依次执行：
<code class="java">
npm init;
npm install;
bower install;
gulp
</code>
