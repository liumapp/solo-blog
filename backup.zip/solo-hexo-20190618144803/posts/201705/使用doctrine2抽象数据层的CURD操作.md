title: 使用doctrine2抽象数据层的CURD操作
date: '2017-05-10 22:40:34'
updated: '2017-05-11 15:52:40'
tags: [doctrine2]
permalink: /articles/2017/05/10/1494426245436.html
---
### 使用doctrine2抽象数据层的CURD操作

> 依然是在项目开发过程中碰到的问题，需要使用doctrine来解决。虽然doctrine2的英文文档解释的很全面，但是对于之前没有接触过doctrine的人来说，使用它还是有一定的难度，这里笔者通过我们常用的CURD操作，来解释doctrine2的运用。

#### 下载安装

	composer.phar require doctrine/orm 2.4.*
	
#### 前提准备

下载安装完之后，官方手册讲了一大堆的配置，新建bootstrap.php文件，新建cli-config.php文件什么什么的，国内很多人的博客互相抄来抄去也只是把官方手册粗略的翻译了一下，而实际上，如果我们只需要使用doctrine2对数据库进行CURD操作的话，压根不需要这么多繁琐的配置。

话不多说，上代码。

代码Git地址：[liumapp/dns](https://github.com/liumapp/dns.git).

项目目录结构

![2.pic.jpg](http://oss.fangxinqian.cn/53b4e567a8a942cd9cfa134212604f75.jpg)

可以看见，我这里真对doctrine2只额外写了一个src/models/db.php文件。

内容如下：

	/**
	 * Created by PhpStorm. * User: liumapp * Email: liumapp.com@gmail.com
	  * homePage: http://www.liumapp.com
	  * Date: 5/10/17
	 * Time: 4:47 PM */
	 namespace liumapp\dns\models;

	class db {

	  public static function getInstance()
	 {
	  $config = new \Doctrine\DBAL\Configuration();
	//..
	  $connectionParams = array(
	  'dbname' => 'whmcs',
	  'user' => 'root',
	  'password' => '',
	  'host' => '',
	  'driver' => 'pdo_mysql',
	  );
	  $conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams, $config);

	  return $conn;

	  }

	}

所以要使用doctrine进行curd操作数据库的数据，只需要创建一个DriverManager的连接即可，不需要进行额外的配置。而在80%的项目情况下，我们只需要进行curd操作而已。

#### create

获取post值并插入一条新的记录

	$conn  = \liumapp\dns\models\db::getInstance();
	$queryBuilder = $conn->createQueryBuilder();
	$queryBuilder
	  ->insert('lmdns')
	 ->values(
	  array(
	  'uid' => '?',
	  'domainId' => '?',
	  'type' => '?',
	  'subdomain' => '?',
	  'value' => '?',
	  )
	 ) ->setParameter(0, addslashes($_POST['uid']))
	 ->setParameter(1, addslashes($_POST['domainId']))
	 ->setParameter(2, addslashes($_POST['type']))
	 ->setParameter(3, addslashes($_POST['subdomain']))
	 ->setParameter(4, addslashes($_POST['value']))
	;
	$queryBuilder->execute();
	
#### update

更新用户的登陆次数

	$conn  = \liumapp\dns\models\db::getInstance();
	$queryBuilder = $conn->createQueryBuilder();
	$queryBuilder
		->update('users', 'u')
		->set('u.logins', 'u.logins + 1')
		->set('u.last_login', '?')
		->setParameter(0, $userInputLastLogin)
	;
	$queryBuilder->execute();
	
执行成功后的结果将会返回1

#### read

读取所有的文章记录

	use Doctrine\DBAL\DriverManager;

	$conn  = \liumapp\dns\models\db::getInstance();

	$sql = "SELECT * FROM articles";
	
	$stmt = $conn->query($sql); // Simple, but has several drawbacks
	
	while ($row = $stmt->fetch()) {
		var_dump($row);//将会以数组的形式把元组打印出来
	}
	
根据邮箱，读取指定的用户名称和id字段的值	
	
	$conn  = \liumapp\dns\models\db::getInstance();
	$queryBuilder = $conn->createQueryBuilder();
	$queryBuilder
		->select('id', 'name')
		->from('users')
		->where('email = ? and isdel = 0')
		->setParameter(0, $userInputEmail)
	;
	$result = $queryBuilder->execute();
	while($row = $result->fetch()) {
	  var_dump($row);
	}
	//或者也可以直接获取全部
	$rows = $result->fetchAll()

#### delete

删除id为1的user。

	$conn  = \liumapp\dns\models\db::getInstance();
	$conn->createQueryBuilder()
         ->delete('users', 'u')
         ->where('u.id = :user_id')
         ->setParameter(':user_id', 1)
		 ->execute();
	
	//或者
	$conn->delete('user', array('id' => 1));
	
	