title: DNSBrood解析DNS过程中进行Debug
date: '2017-07-12 10:19:37'
updated: '2017-07-12 16:03:41'
tags: [DNS, dnsJava, Java, IDEA, Shell]
permalink: /articles/2017/07/12/1499822853171.html
---
> DNSBrood是一款基于dnsJava的DNS server，尚处于开发过程中，所以需要在其解析DNS的过程中进行Debug测试。但出于一些原因，Debug必须在其打包好且正在运行的Jar包上进行。所以我将尝试IDEA的Remote远程Debug功能来进行测试工作。

[DNSBrood](https://github.com/liumapp/DNSBrood)

### IDEA配置Remote

* 进入IDEA的Edit Configure页面

* 在add new configure选项里面选择remote

* 相应视图如下：

	![1.pic.jpg](http://oss.fangxinqian.cn/f6d5e71fa0204e73be668713255ca11d.jpg)

  将红框框住的内容复制，用于下文的修改启动脚本，当然，这里有三段脚本内容，具体选择哪一段要视自己的实际情况来定。

* 点击确定。

### 修改启动脚本

修改启动脚本blackhole.sh

首先设置两个变量：

	JVM_OPTION="-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005"
	HOME_JAR=/yourpath/target/blackhole-1.2.2.jar

然后修改start：

	start)

	 echo "Starting blackhole..."

	 java -jar ${JVM_OPTION} -Djava.io.tmpdir="$HOME_DIR/cache" $HOME_JAR -d"$HOME_DIR">> $HOME_DIR/log &

	 ;;

在修改restart:

	restart)

	 echo "Stopping blackhole..."

	 java -jar $HOME_DIR/lib/wifesays-1.0.0-alpha.jar -cshutdown > /dev/null;

	 sleep 2;

	 echo "Starting blackhole..."

	 java -jar ${JVM_OPTION} -Djava.io.tmpdir="$HOME_DIR/cache" $HOME_JAR -d"$HOME_DIR">> $HOME_DIR/log &

	 ;;

接下来启动DNSBrood，打开日志文件，如果有：

	Listening for transport dt_socket at address: 5005
	
就说明配置正确

### 断点测试

因为整个项目是通过socket来判断用户处理DNS解析的请求，所以我们在运行DNSBrood的时候，还需要DNSBee来配合使用，两个系统的使用这篇博文先不多讲。

这里我们在us.codecraft.wifesays.me.HusbandEar这个类的process方法的

	logger.info("wife says \"" + lineIn + "\" ,what you should do?");
	
这行代码上设置断点，然后通过DNSBee发送一段请求：

	17-07-12 10:17:44,908 INFO us.codecraft.wifesays.me.HusbandEar(HusbandEar.java:83) ## wife says "delete_zones_ip_127.0.0.1" ,what you should do?

	17-07-12 10:17:44,908 INFO us.codecraft.wifesays.me.HusbandEar(HusbandEar.java:83) ## wife says "add_zones_ip_127.0.0.1:6.7.4.5_gmail.liumapp.com" ,what you should do?

	line is :127.0.0.1:6.7.4.5_gmail.liumapp.com

	17-07-12 10:17:44,910 INFO us.codecraft.wifesays.me.HusbandEar(HusbandEar.java:83) ## wife says "add_zones_ip_127.0.0.1:55.55.55.55_gg.liumapp.com" ,what you should do?

	line is :127.0.0.1:55.55.55.55_gg.liumapp.com

	17-07-12 10:17:44,912 INFO us.codecraft.wifesays.me.HusbandEar(HusbandEar.java:83) ## wife says "add_zones_ip_127.0.0.1:88.88.88.8_tt.liumapp.com" ,what you should do?

	line is :127.0.0.1:88.88.88.8_tt.liumapp.com

如果IDEA出现如下Debug信息：

![2.pic.jpg](http://oss.fangxinqian.cn/d6ef649c19814f36a791a6a2cd540055.jpg)

那就说明Debug测试成功了。

