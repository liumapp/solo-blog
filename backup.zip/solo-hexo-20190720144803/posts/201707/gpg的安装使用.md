title: gpg的安装使用
date: '2017-07-20 14:18:49'
updated: '2019-01-28 14:38:03'
tags: [安全加密, gpg, Linux, Mac]
permalink: /articles/2017/07/20/1500521485758.html
---
> 记录我在Mac上安装gpg的过程及使用

### 定义

gpg是加密和数字签名的免费工具，大多用于加密信息的传递。除了仅用密码加密外，GPG最大的不同是提供了“公钥/私钥”对。利用一方的“公钥”别人加密信息不再需要告诉密码，随时随地都能发送加密信息。而这种加密是单向的，只有一方的“私钥”能解开加密。数字签名又是另一大使用方向。通过签名认证，别人能确保发布的消息来自一方，而且没有经过修改。

### 安装

安装命令利用brew即可，具体视操作环境有所差异。

	sh-3.2# brew install gpg

	**==>** **Downloading https://homebrew.bintray.com/bottles/gnupg-1.4.20.el_capitan.bottle.tar.gz**

	######################################################################## 100.0%

	**==>** **Pouring gnupg-1.4.20.el_capitan.bottle.tar.gz**

	/usr/local/Cellar/gnupg/1.4.20: 53 files, 5.4M

	sh-3.2# gpg --version

	gpg (GnuPG) 1.4.20

	Copyright (C) 2015 Free Software Foundation, Inc.

	License GPLv3+: GNU GPL version 3 or later 

	This is free software: you are free to change and redistribute it.

	There is NO WARRANTY, to the extent permitted by law.

	Home: ~/.gnupg

	支持的算法：

	公钥：RSA, RSA-E, RSA-S, ELG-E, DSA

	对称加密：IDEA, 3DES, CAST5, BLOWFISH, AES, AES192, AES256,

	 TWOFISH, CAMELLIA128, CAMELLIA192, CAMELLIA256

	散列：MD5, SHA1, RIPEMD160, SHA256, SHA384, SHA512, SHA224

	压缩：不压缩, ZIP, ZLIB, BZIP2
	

### 生成私钥

安装之后需要利用gpg --gen-key命令生成私钥，这一步需要对私钥的用户、邮箱、有效期进行配置，我的操作记录如下：

	sh-3.2# gpg --gen-key

	gpg (GnuPG) 1.4.20; Copyright (C) 2015 Free Software Foundation, Inc.

	This is free software: you are free to change and redistribute it.

	There is NO WARRANTY, to the extent permitted by law.

	请选择您要使用的密钥种类：

	 (1) RSA and RSA (default)

	 (2) DSA and Elgamal

	 (3) DSA (仅用于签名)

	 (4) RSA (仅用于签名)

	您的选择？ 

	RSA 密钥长度应在 1024 位与 4096 位之间。

	您想要用多大的密钥尺寸？(2048)

	您所要求的密钥尺寸是 2048 位              

	请设定这把密钥的有效期限。

	 0 = 密钥永不过期

	  = 密钥在 n 天后过期

	 w = 密钥在 n 周后过期

	 m = 密钥在 n 月后过期

	 y = 密钥在 n 年后过期

	密钥的有效期限是？(0) 

	密钥永远不会过期               

	以上正确吗？(y/n)y



	您需要一个用户标识来辨识您的密钥；本软件会用真实姓名、注释和电子邮件地址组合

	成用户标识，如下所示：

	 “Heinrich Heine (Der Dichter) ”

	真实姓名：liumei 

	姓名含有无效的字符                           

	真实姓名：liumapp (liumapp) 

	姓名含有无效的字符                                      

	真实姓名：liumapp

	电子邮件地址：liumapp.com@gmail.com

	注释：                                    

	您选定了这个用户标识：

	 “liumapp ”

	更改姓名(N)、注释(C)、电子邮件地址(E)或确定(O)/退出(Q)？o

	您需要一个密码来保护您的私钥。                                               

	我们需要生成大量的随机字节。这个时候您可以多做些琐事(像是敲打键盘、移动

	鼠标、读写硬盘之类的)，这会让随机数字发生器有更好的机会获得足够的熵数。

	........+++++

	...+++++

	我们需要生成大量的随机字节。这个时候您可以多做些琐事(像是敲打键盘、移动

	鼠标、读写硬盘之类的)，这会让随机数字发生器有更好的机会获得足够的熵数。

	....+++++

	+++++

	gpg: /var/root/.gnupg/trustdb.gpg：建立了信任度数据库

	gpg: 密钥 636BA03D 被标记为绝对信任

	公钥和私钥已经生成并经签名。

	gpg: 正在检查信任度数据库

	gpg: 需要 3 份勉强信任和 1 份完全信任，PGP 信任模型

	gpg: 深度：0 有效性： 1 已签名： 0 信任度：0-，0q，0n，0m，0f，1u

	pub  2048R/636BA03D 2017-07-20

	密钥指纹 = 7CFB 016A 298A C90C C324 6A32 DAB3 F9DA 636B A03D

	uid liumapp 

	sub  2048R/9F2B7F4B 2017-07-20
	
### 发布公钥

首先我们要看看自己的公钥编号是什么：

	sh-3.2# gpg --list-keys

	/var/root/.gnupg/pubring.gpg

	----------------------------

	pub  2048R/636BA03D 2017-07-20

	uid liumapp 

	sub  2048R/9F2B7F4B 2017-07-20
	
可以看到，我的公钥编号是636BA03D，所以接下来使用命令：

	gpg --keyserver hkp://pool.sks-keyservers.net --send-keys 636BA03D
	
将公钥上传到线上

	sh-3.2# gpg --keyserver hkp://pool.sks-keyservers.net --send-keys 636BA03D

	gpg: sending key 636BA03D to hkp server pool.sks-keyservers.net
	
当然也可以使用命令

	gpg --keyserver hkp://pool.sks-keyservers.net --recv-keys 636BA03D
	
来检查是否上传成功

不过考虑到公钥线上仓库数量比较多，等待他们全部同步完成需要一定的时间，建议在这个公钥仓库也同样上传一遍：

	gpg --keyserver hkp://keyserver.ubuntu.com --send-keys 636BA03D
	
### 使用

gpg的使用一般搭配Maven，比如maven的插件maven-gpg-plugin，当然也有很多其他的用法，官方的说明比较详细：[working-with-pgp](http://central.sonatype.org/pages/working-with-pgp-signatures.html)。我自己仅仅就maven-gpg-plugin的使用进行一个记录。

##### 场景说明

利用maven和gpg，将一个maven项目上传到maven中央仓库的私服中。

##### 配置

pom.xml:

首先需要取保虾面的几项基础配置要有：

	 <licenses>
		<license>
		  <name>GNU General Public License v3.0</name>
		  <url>http://www.gnu.org/licenses/agpl-3.0.html</url>
		  <distribution>repo</distribution>
		  <comments>A socket manager</comments>
		</license>
	  </licenses>

	  <developers>
		<developer>
		  <name>liumapp</name>
		  <url>http://www.liumapp.com</url>
		  <email>liumapp.com@gmail.com</email>
		</developer>
	  </developers>

	  <scm>
		<connection>scm:git:https://github.com/liumapp/DNSQueen.git</connection>
		<developerConnection>scm:git:https://github.com/liumapp/DNSQueen.git</developerConnection>
		<url>https://github.com/liumapp/DNSQueen</url>
		<tag>v${project.version}</tag>
	  </scm>

	  <distributionManagement>
		<snapshotRepository>
		  <id>ossrh</id>
		  <url>https://oss.sonatype.org/content/repositories/snapshots</url>
		</snapshotRepository>
		<repository>
		  <id>ossrh</id>
		  <name>Maven Central Staging Repository</name>
		  <url>https://oss.sonatype.org/service/local/staging/deploy/maven2/</url>
		</repository>
	  </distributionManagement>

然后添加以下插件：

	<plugin>
        <groupId>org.sonatype.plugins</groupId>
        <artifactId>nexus-staging-maven-plugin</artifactId>
        <version>1.6.3</version>
        <extensions>true</extensions>
        <configuration>
          <serverId>ossrh</serverId>
          <nexusUrl>https://oss.sonatype.org/</nexusUrl>
          <autoReleaseAfterClose>true</autoReleaseAfterClose>
        </configuration>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-gpg-plugin</artifactId>
        <version>1.6</version>
        <executions>
          <execution>
            <id>sign-artifacts</id>
            <phase>verify</phase>
            <goals>
              <goal>sign</goal>
            </goals>
          </execution>
        </executions>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-javadoc-plugin</artifactId>
        <version>2.10.3</version>
        <executions>
          <execution>
            <id>attach-javadocs</id>
            <goals>
              <goal>jar</goal>
            </goals>
          </execution>
        </executions>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-source-plugin</artifactId>
        <executions>
          <execution>
            <id>attach-sources</id>
            <goals>
              <goal>jar-no-fork</goal>
            </goals>
          </execution>
        </executions>
      </plugin>

然后便要修改maven的settings.xml文件，打开maven的安装目录，找到config下的settings.xml，在servers节点和profiles节点分别添加以下两段内容：

	<server>
        <id>ossrh</id>
        <username>sonatype的用户名</username>
        <password>sonatype的密码</password>
    </server>

	<profile>
        <id>ossrh</id>
        <activation>
          <activeByDefault>true</activeByDefault>//这个true的作用就是oss.sonatype的Staging Repositories会自动release
        </activation>
        <properties>
          <gpg.executable>gpg2</gpg.executable>
          <gpg.passphrase>安装gpg时设置的密码</gpg.passphrase>
        </properties>
    </profile>

然后我们回到maven的项目根目录，执行：

	mvn deploy -Dmaven.test.skip=true -e
	
如果看到build success的话，那么此刻我们的maven项目应该成功上传到maven中央仓库的一个私服里面了。我这边的相关日志如下：

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.pom.asc

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.pom.asc (473 B at 0.1 KB/sec)

	Downloading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/maven-metadata.xml

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/maven-metadata.xml

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/maven-metadata.xml (299 B at 0.2 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-javadoc.jar.asc

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-javadoc.jar.asc (473 B at 1.2 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-sources.jar.asc

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-sources.jar.asc (473 B at 1.6 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.jar

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.jar (29 KB at 17.1 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.pom

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.pom (6 KB at 4.7 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.jar.asc

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0.jar.asc (473 B at 1.6 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-sources.jar

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-sources.jar (17 KB at 13.6 KB/sec)

	Uploading: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-javadoc.jar

	Uploaded: https://oss.sonatype.org:443/service/local/staging/deployByRepositoryId/comliumapp-1007/com/liumapp/DNSQueen/1.0.0/DNSQueen-1.0.0-javadoc.jar (131 KB at 18.6 KB/sec)

	[INFO] * Upload of locally staged artifacts finished.

	[INFO] * Closing staging repository with ID "comliumapp-1007".

	Waiting for operation to complete.........

	[INFO] Remote staged 1 repositories, finished with success.

	[INFO] Remote staging repositories are being released...

	Waiting for operation to complete..........

	[INFO] Remote staging repositories released.

	[INFO] ------------------------------------------------------------------------

	[INFO] BUILD SUCCESS

	[INFO] ------------------------------------------------------------------------

	[INFO] Total time: 01:33 min

	[INFO] Finished at: 2017-07-20T14:08:53+08:00

	[INFO] Final Memory: 31M/562M

	[INFO] ------------------------------------------------------------------------
	
最后附一张私服截图：

![5.pic.jpg](http://oss.fangxinqian.cn/a1d43b2571b548c98ddd3dc101933db6.jpg)