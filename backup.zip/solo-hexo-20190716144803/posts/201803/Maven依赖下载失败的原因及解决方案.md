title: Maven依赖下载失败的原因及解决方案
date: '2018-03-02 11:52:22'
updated: '2019-06-12 10:35:55'
tags: [Maven]
permalink: /articles/2018/03/02/1519962410735.html
---
> Maven依赖下载失败的原因，通过我自己在项目中的实践和摸索，总结出来主要有两点：使用的Maven仓库镜像地址在国外被墙、依赖本身存放在Maven仓库以外的地方。

## 失败原因

### 使用的Maven仓库镜像地址在国外被墙

第一种原因相信大家最常碰到，百度或者谷歌搜到的问题也大都是这个问题，解决办法也很简单，换用一个国内的镜像地址即可，这里不做多说。

### 依赖本身存放在Maven仓库以外的地方

第二种原因相信大家碰到的几率就比较少了，因为很少有发布的开源项目选择了Maven以外的仓库（其实也不少，但是大家用到的应该不多），我会在下面的解决方案中结合具体的例子来叙述。

### 所依赖的项目类型为pom

第三种原因属于习惯性问题，一般来说，我们加maven依赖，都是像下面这样配置：

````mxml
<dependency>
    <groupId>com.itextpdf</groupId>
    <artifactId>itext7-core</artifactId>
    <version>7.1.5</version>
</dependency>
````

但偶尔就是会遇到这个依赖死活下载不下来，没有办法打包，但在idea中又可能是运行正常的？？？

去maven中央仓库搜索，可以发现这个依赖是属于pom类型的：

![image.png](https://img.hacpai.com/file/2019/06/image-7ef78bb7.png)

所以这种情况下，我们加载它就需要使用

````mxml
<dependency>
      <groupId>com.itextpdf</groupId>
      <artifactId>itext7-core</artifactId>
      <version>7.1.5</version>
      <type>pom</type>
</dependency>
````


## 解决方案

### 第一种

网上搜到的最简单粗暴的办法就是换用阿里云的Maven仓库，但各位是否思考过一个问题，如果阿里云的Maven仓库也没有这个依赖怎么办？

所以我们可以使用阿里云的Maven仓库作为首选地址，再添加一个备用的地址，如：

我们可以在本地maven的配置文件setting.xml中做如下配置：

	<mirror>
        <id>nexus-aliyun</id>
        <mirrorOf>central</mirrorOf>
        <name>Nexus aliyun</name>
        <url>http://maven.aliyun.com/nexus/content/groups/public</url>
    </mirror>
    <mirror>
        <id>spring-libs-milestone</id>
        <mirrorOf>central</mirrorOf>
        <name>Spring Milestones</name>
        <url>http://repo.spring.io/libs-milestone</url>
    </mirror>
	
基本上90%以上的Maven依赖下载失败都能够解决。	

### 第二种

考虑到大部分同学可能没有碰到过这种情况，所以我觉一个栗子（虽然我不喜欢吃栗子）:

比如 Ring core 这个项目 Github开源项目的地址为: https://github.com/ring-clojure/ring](https://github.com/ring-clojure/ring) 

大家在Maven的中央仓库站点搜索这个项目，很容易就能够找到它:

![1.pic_hd.jpg](http://oss.fangxinqian.cn/35c79685861446b185069c34e8b372a4.jpg)

但是如果直接去引用，那么很抱歉，Maven会告诉你下载失败。

为什么呢？

因为它的jar包压根就没有放在Maven仓库上，而是放在了一个叫做[Clojars](http://mvnrepository.com/repos/clojars)的地方。

![2.pic.jpg](http://oss.fangxinqian.cn/b2fa474d9464402bbd4d766657f2dc75.jpg)

解决办法很简单，我们遇到这样的依赖的时候，只需要在项目的pom文件中做如下配置即可:

	<repositories>
	  <repository>
		<id>clojars</id>
		<url>http://clojars.org/repo/</url>
	  </repository>
	</repositories>
	
同样的道理，如果项目放在了其他的地方，我们可以根据它的地址，再去做相应的配置即可完成该依赖的下载。

### 第三种

增加```<type>pom</type>```即可

## 结尾

如果大家觉得我的博文对各位有帮助，欢迎关注我的Github: [liumapp](https://github.com/liumapp)
