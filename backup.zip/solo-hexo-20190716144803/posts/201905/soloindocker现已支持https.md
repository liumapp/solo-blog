title: solo-in-docker现已支持https
date: '2019-05-23 10:26:47'
updated: '2019-05-23 11:34:57'
tags: [Java, ssl, Docker, Solo]
permalink: /articles/2019/05/23/1558578407774.html
---
> 先前发布的solo-in-docker项目支持各位黑客派会员一键部署solo项目，但遗憾的是只支持http协议，今天发布的v1.3.0版本全部支持https协议

项目地址: [github/solo-in-docker](https://github.com/liumapp/solo-in-docker)

同时感谢 @Fly 大佬提供的支持

## 1. HTTP部署

* clone项目，```cd http```进入http目录

* 按照http目录下的readme配置docker-compose，只需要修改自己的域名跟端口

* 启动，结束（启动、结束、查看日志等命令请参考http目录下的readme）

## 2. HTTPS部署

* 请自行获取ssl数字证书

* clone项目，```cd https```进入https目录

* 按照https目录下的readme配置nginx.conf与docker-compose，前者是让nginx找到证书，后者是修改自己的域名跟端口

* 启动，结束

## 3. 先部署HTTP再升级HTTPS

对于一些老用户，可能您之前用的http方式部署的项目，现在想升级到https的话，只需要做两件事情

* 按照https目录下的readme获取证书、配置

* 将老项目的mysql/data目录复制替换到https的mysql/data目录即可

