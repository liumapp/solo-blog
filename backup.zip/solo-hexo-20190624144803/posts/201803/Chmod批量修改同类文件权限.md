title: Chmod批量修改同类文件权限
date: '2018-03-07 16:21:48'
updated: '2018-04-10 14:24:49'
tags: [Linux]
permalink: /articles/2018/03/07/1520410908517.html
---
> chmod是Linux下修改权限的命令，在平常的使用也是非常频繁的，那么我们如何使用它来批量修改同类型文件呢

现在假设root用户在/usr/local/project/目录下创建了一个目录，名为food

然后在food目录下创建三个子目录，分别名为foo1, foo2, foo3 

每个子目录都包含三个文件，分别为apple, pear, orange

在不进行其他设置的情况下，其他普通用户是没有权限对这些“水果”们进行操作。

现在如果要让名为lisi的用户可以去写food目录下面所有的apple，那么很显然，root用户需要修改所有的apple权限。

那怎么样去修改呢，用

	chmod -R a+w apple

一个一个去改吗？

显然这样做太low，一个简单的办法是：

进入food目录下执行：

	chmod -R a+w */apple
	
即可。

上面所述的简单Demo同理可以应用在其他不同场景下，具体不多叙述。
	


