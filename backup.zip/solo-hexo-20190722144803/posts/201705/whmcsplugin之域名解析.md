title: whmcs-plugin之域名解析
date: '2017-05-23 09:48:53'
updated: '2017-05-23 09:48:53'
tags: [Webnic, whmcs]
permalink: /articles/2017/05/23/1495503001523.html
---
### whmcs-plugin之域名解析

> 通过对whmcs域名解析的功能开发，来记录一下工作上遇到的whmcs插件开发。

### 成果

话不多说，先看看最终完成的作品

首先，我们锁定功能的入口是在域名管理中心里面，然后在二级导航栏里面添加一栏“域名解析”，用户点击后，跳转到我自己定义的解析页面上。


![2.pic.jpg](http://oss.fangxinqian.cn/fdc8a2b3551a438c95a2fbe307df95db.jpg)


在这个解析页面上，用户可以对自己域名的A记录和CNAME记录进行解析，解析是及时生效的。（这里使用的DNS解析服务器是由Webnic提供，相应细节暂不透露，这里只针对whmcs插件开发来讲）

![3.pic.jpg](http://oss.fangxinqian.cn/8430f6e7a9944aa894234f5d9c72d99e.jpg)

### 开发过程

首先这里涉及到一个域名解析面板，和一个域名解析功能，在开发过程中，我把这两个模块拆分成两个独立的项目，分别命名为 dnspannel 和 dns，项目源码请见：[dns](https://github.com/liumapp/dns.git) 和 [dnspannel](https://github.com/liumapp/dnspannel.git)。

然后回到whmcs系统本身上来，首先是功能的入口，也就是说，我如何让用户跳转到我写的这个新页面里来：

首先在whmcs系统根目录下，我新建两个文件，分别为dns.php和lmConfig.php，然后在includes/hooks/下，新建一个AddDnsMenu.php文件

![4.pic.jpg](http://oss.fangxinqian.cn/fb1b6df546b24cdb87de9ff681c4739d.jpg)

![5.pic.jpg](http://oss.fangxinqian.cn/6ba22d0b586a4626911865b00972b0bf.jpg)

AddDnsMenu.php定义了一个钩子，在用户进入一个域名的详情时，去修改二级导航栏，把我们的“域名解析”加入导航中，其代码如下：

	/**
	 * Created by PhpStorm.
	 * User: liumapp 
	 * Email: liumapp.com@gmail.com
	 * homePage: http://www.liumapp.com
	 * Date: 5/8/17
	 * Time: 3:44 PM */

	use WHMCS\View\Menu\Item as MenuItem;

	add_hook('ClientAreaPrimarySidebar', 1, function (MenuItem $primarySidebar)

	{
	  if (!is_null($primarySidebar->getChild('Domain Details Management'))) {
	  $domainId = addslashes($_GET['id']);
	  $domainId = ($domainId == '' ) ? addslashes($_GET['domainid']) : $domainId;
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('DNS')
	 ->setLabel('域名解析')
	 ->setUri('dns.php?id=' . $domainId)
	 ->setOrder(100);
	  }
	});

lmConfig.php定义了我们需要的额外配置信息，这里进行保密。

dns.php则是具体的页面了，但这只是用户点击域名解析后跳转执行的后台脚本，真正的模板文件还是要在template/lmsix/目录下，新建一个dns.tpl文件。

我相信大部分人的template目录下应该没有lmsix目录，因为这是我自己根据six进行修改的一套模板，暂时没有对外开放源码。

![6.pic.jpg](http://oss.fangxinqian.cn/8ce4dec03c1a42feb767da552daa57f4.jpg)

dns.php脚本的代码如下：

	/**
	 * Created by PhpStorm. 
	 * User: liumapp 
	 * Email: liumapp.com@gmail.com
	 * homePage: http://www.liumapp.com
	 * Date: 5/8/17
	 * Time: 4:19 PM */

	use WHMCS\ClientArea;
	use WHMCS\Database\Capsule;
	use WHMCS\View\Menu\Item as MenuItem;

	define('CLIENTAREA', true);

	require __DIR__ . '/init.php';

	$ca = new ClientArea();

	$ca->setPageTitle('域名解析');

	$ca->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));

	$ca->addToBreadCrumb('dns.php', '域名解析');

	$ca->initPage();

	$ca->requireLogin(); // Uncomment this line to require a login to access this page

	// To assign variables to the template system use the following syntax.
	// These can then be referenced using {$variablename} in the template.

	//$ca->assign('variablename', $value);

	// Check login status
	if ($ca->isLoggedIn()) {

	  /**
	 * User is logged in - put any code you like here * * Here's an example to get the currently logged in clients first name */  $clientName = Capsule::table('tblclients')
	 ->where('id', '=', $ca->getUserID())->pluck('firstname');
	  // 'pluck' was renamed within WHMCS 7.0.  Replace it with 'value' instead.
	 // ->where('id', '=', $ca->getUserID())->value('firstname');  $ca->assign('clientname', $clientName);

	} else {

	// User is not logged in
	$ca->assign('clientname', 'Random User');

	}

	//auto load

	function classLoadDns ($class)
	{
	  $path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
	  $path = str_replace('liumapp' . DIRECTORY_SEPARATOR, '', $path);
	  $path = str_replace('dns' . DIRECTORY_SEPARATOR , '' , $path);
	  $file = '/alidata/www/default/whmcs/vendor2/vendor/liumapp/dns/src/' . $path . '.php';
	  if (file_exists($file)) {
	  require_once $file;
	  }
	}

	spl_autoload_register('classLoadDns');
	$dns = new \liumapp\dns\dns();

	// data

	$domainId = addslashes($_GET['id']);
	$domainId = ($domainId == '' ) ? addslashes($_GET['domainid']) : $domainId;
	$dns->domainId = $domainId;

	$ca->assign('domainId' , $domainId);
	$ca->assign('dns' , $dns);
	/**
	 * Set a context for sidebars * * @link http://docs.whmcs.com/Editing_Client_Area_Menus#Context
	  */
	Menu::addContext();

	/**
	 * Setup the primary and secondary sidebars * * @link http://docs.whmcs.com/Editing_Client_Area_Menus#Context
	  */

	Menu::primarySidebar('domainView');
	Menu::secondarySidebar('domainView');

	add_hook('ClientAreaPrimarySidebar', 1, function (MenuItem $primarySidebar)
	{
	  if (!is_null($primarySidebar->getChild('Domain Details Management'))) {
	  $child = $primarySidebar->getChild('Domain Details Management')->getChild('Overview');
	  if (is_null($child)) {
	  $domainId = addslashes($_GET['id']);
	  $domainId = ($domainId == '' ) ? addslashes($_GET['domainid']) : $domainId;
	  $primarySidebar->removeChild('DNS');
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('Overview')
	 ->setLabel('总览')
	 ->setUri('clientarea.php?action=domaindetails&id='.$domainId.'#tabOverview')
	 ->setOrder(100);
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('Auto Renew Settings')
	 ->setLabel('自助续费')
	 ->setUri('clientarea.php?action=domaindetails&id='.$domainId.'#tabAutorenew')
	 ->setOrder(110);
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('Modify Nameservers')
	 ->setLabel('NS服务器')
	 ->setUri('clientarea.php?action=domaindetails&id='.$domainId.'#tabNameservers')
	 ->setOrder(120);
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('Registrar Lock Status')
	 ->setLabel('域名锁定')
	 ->setUri('clientarea.php?action=domaindetails&id='.$domainId.'#tabReglock')
	 ->setOrder(130);
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('Domain Contacts')
	 ->setLabel('联系人信息')
	 ->setUri('clientarea.php?action=domaincontacts&domainid=' . $domainId)
	 ->setOrder(140);
	  $primarySidebar->getChild('Domain Details Management')
	 ->addChild('DNS')
	 ->setLabel('域名解析')
	 ->setUri('dns.php?id=' . $domainId)
	 ->setOrder(150);
	  }
	 }});

	# Define the template filename to be used without the .tpl extension

	$ca->setTemplate('dns');

	$ca->output();
	
	
我们可以看到，这里我写了一个spl_autoload_register，这是为了引入dns项目，具体的业务逻辑和视图逻辑再由dns和dnspanel这两个项目去执行，一定程度上可以保持项目日后的维护性。

再对于dns.tpl,其代码如下所示：

	  type="text/javascript">
	$('#Primary_Sidebar-Domain_Details_Management-DNS').addClass('active');

	{$dns->init()}
	  {$dns->renderTable()}
	  {$dns->renderJs()}
	  
整个whmcs的插件开发就到此结束，很抱歉不能把所有细节分享出来，因为涉及到一些商业机密，这里仅仅把自己开发过程的心得和体会进行记录，仅为学习。