title: whmcs-addon-module之新闻批量上传
date: '2017-05-26 16:11:57'
updated: '2017-05-26 16:11:57'
tags: [whmcs]
permalink: /articles/2017/05/26/1495785636018.html
---
### whmcs-addon-module之新闻批量上传

> 这是一个实现新闻批量上传功能的whmcs插件，基于addon-module来实现的。

### 实现功能

安装完本插件后，在后台管理页面里面上传一个csv文件，上传后，将csv文件里面的新闻内容插入whmcs系统的新闻表中

基本如下图所示：

![1.pic.jpg](http://oss.fangxinqian.cn/32381d528ce74a24b6eb92108ff7e196.jpg)

![2.pic.jpg](http://oss.fangxinqian.cn/682212d8a72e456f9b62b24a53fef626.jpg)

同时可以在配置中选择是否立即发布，当勾选以后，批量添加的新闻将会立即发布到前台，不勾选的话，是不会立即发布到前台的。

![3.pic.jpg](http://oss.fangxinqian.cn/ee795b39e8c64888aa23a1e1c7627ac0.jpg)

### 代码与解析

首先完整的源码请看我的Github项目[whmcs-plugin-multyLoadAnnouncements](https://github.com/liumapp/whmcs-plugin-multyLoadAnnouncements)

在分析上，我们只分析一下处理csv文件的内容，并将其保存到whmcs的新闻表这一块的代码：

首先源码如下：


	public function handpost ()
	{

	  if (!isset($_FILES['csv'])) {
	  throw new \ErrorException('文件上传有误！');
	  }

	  $csv = $_FILES['csv'];

	  $file = fopen($csv['tmp_name'] , 'r');

	  $row = 1;

	  while ($data = fgetcsv($file , 10000, ",")) {

	  if ($row == 1) {$row++;continue;} //跳过title

	  $this->saveData($data);
	  $row++;

	  }

	 fclose($file);

	  $row = $row - 1;

	  echo '成功保存了' . $row . '条记录';
	}

	/**
	 * 保存一行announcement * @param array $data
	 */private function saveData ($data)
	{
	  $pdo = Capsule::connection()->getPdo();
	  $pdo->beginTransaction();
	  try {
	  $statement = $pdo->prepare(
	  'insert into tblannouncements (date , announcement , title , published , parentid , language) values(:date , :announcement , :title , :published , :parentid , :language)'
	  );

	  $statement->execute(
	 [  ':date' => $data[0],
	  ':announcement' => $data[1],
	  ':title' => $data[2],
	  ':published' => addslashes($_POST['published']),
	  ':parentid' => 0,
	  ':language' => '',
	  ]
	 );
	  $pdo->commit();

	  } catch (\Exception $e) {

	  echo "Uh oh! Inserting didn't work, but I was able to rollback. {$e->getMessage()}";
	  $pdo->rollBack();

	  }
	}
	
可以看到，插件并没有保存用户上传的csv文件，而是将上传的文件，通过读取临时文件名的形式，利用fgetcsv()去一行一行的读取，再将每行的记录通过whmcs自带的Capsule类执行insert的操作，如果报出error，再执行回滚操作。