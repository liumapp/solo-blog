title: 通过本地repository加载jar包到Maven依赖中
date: '2019-04-12 15:19:13'
updated: '2019-04-12 17:42:06'
tags: [Java, Maven]
permalink: /articles/2019/04/12/1555053553824.html
---
> 很多优秀的Java项目实际上并不提供免费使用，比如aspose，而作为个人的话一般而言都会选择它的破解版本来研究，那么破解后的jar包肯定是不能直接在Maven的中央仓库下载到的，我们只能选择本地导入或者私服的方式来加载，后者会要求你具备nexus私服系统，前者若通过system scope来导入的话，是无法使用使用jar-with-dependencies进行打包的，那么这里提供另一种实现方式：在项目下创建一个repository来加载

先上项目源代码：[github/simple-convert]([https://github.com/liumapp/simple-convert](https://github.com/liumapp/simple-convert))

## 创建本地repository

* 进入项目根目录，假设我们有一个名为libs的目录，libs下面有一个名为aspose-words-15.8.0-jdk16.jar的jar包（破解好的jar包）

* 在项目根目录下创建一个名为repo的目录，接下来把这个目录作为我们的本地repository

* 在libs目录下执行命令，将aspose的jar包deploy到repo下面

	```
	mvn deploy:deploy-file -DgroupId=com.aspose.words -DartifactId=aspose-words -Dversion=15.8.0 -Dpackaging=jar -Dfile=./aspose-words-15.8.0-jdk16.jar -Durl=file://${您的项目根目录绝对地址}\repo\ 
	```
* build success后我们应该可以在repo目录下观察到理想的结果：

![1.png](https://github.com/liumapp/simple-convert/blob/master/data/1.png?raw=true)

## 配置pom.xml

* 首先配置我们刚刚添加的本地repository
	
	```
	 <repositories>
	    <repository>
	      <id>project.local</id>
	      <name>project</name>
	      <url>file:${project.basedir}/repo</url>
	    </repository>
	  </repositories>
	```	

* 接下来直接使用aspose的jar包便可

	```
	<dependency>
	      <groupId>com.aspose.words</groupId>
	      <artifactId>aspose-words</artifactId>
	      <version>15.8.0</version>
	    </dependency>
	```

## 总结

通过这种方式来让maven加载本地的jar包，可以规避 system scope 所会带来的问题，同时能够最大化避免跟其他plugin（打jar包的plugin）所可能产生的冲突

那么还有一个新的问题，如果我们现在的这个项目: simple-converter发布到Maven中央仓库，然后其他客户加载它的依赖后，aspose的这个jar包能否下载到呢？

答案是不能的，客户必须在他们本地的项目根目录中，使用同样的命令，创建repo仓库后才可导入