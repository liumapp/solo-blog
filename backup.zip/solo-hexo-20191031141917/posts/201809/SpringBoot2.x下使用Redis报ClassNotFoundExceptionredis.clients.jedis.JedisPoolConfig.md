title: 'SpringBoot2.x下使用Redis报ClassNotFoundException: redis.clients.jedis.JedisPoolConfig'
date: '2018-09-18 02:55:02'
updated: '2018-09-18 02:55:02'
tags: [Redis, Maven, Java]
permalink: /articles/2018/09/18/1537239301796.html
---
> 在Spring Boot 1.x系列下，大部分情况我们都是使用Jedis来与Redis建立连接，但如果切换到Spring Boot 2.x系列呢？

在SpringBoot 2.x系列我们要使用Redis，按照官方的说明，直接引入依赖：


<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-data-redis</artifactId>           
</dependency> 

即可使用，但是用习惯Jedis的同学可能会碰到以下异常：

 Caused by: java.lang.ClassNotFoundException: redis.clients.jedis.JedisPoolConfig
  
因为Spring Boot 2.x系列默认使用的Redis连接为Lettuce，而非Jedis

所以比较习惯使用Jedis的小伙伴们，请一定记得排除Lettuce依赖，并额外引入Jedis依赖

  <dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-data-redis</artifactId>
	<exclusions>
	  <exclusion>
	   <groupId>io.lettuce</groupId>
	   <artifactId>lettuce-core</artifactId>
	  </exclusion>
	</exclusions>            
  </dependency>        
  <dependency>
	<groupId>redis.clients</groupId>
	<artifactId>jedis</artifactId>
  </dependency> 


