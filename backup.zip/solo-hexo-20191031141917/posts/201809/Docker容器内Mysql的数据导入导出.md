title: Docker容器内Mysql的数据导入/导出
date: '2018-09-08 03:19:52'
updated: '2018-09-08 03:43:24'
tags: [Docker, Mysql]
permalink: /articles/2018/09/08/1536376279620.html
---
> Mysql数据的导入导出我们都知道一个mysqldump命令就能够解决，但如果是运行在docker环境下的mysql呢？

解决办法其实还是用mysqldump命令，但是我们需要进入docker的mysql容器内去执行它，并且通过配置volumes让导出的数据文件可以拷贝到宿主机的磁盘上

所以操作步骤就可以分为：

* 配置docker的volumes

* 进入docker的mysql容器，导出数据文件

至于数据导入，太过简单，就不说了

## 配置volumes

首先我是利用docker-compose进行docker容器的编排，完整的配置代码请看这个项目: [liumapp/rabbitmq-mysql-redis-in-docker](https://github.com/liumapp/rabbitmq-mysql-redis-in-docker)

请注意这个项目的docker-compose.yml配置文件中，有以下几行：

	 mysql:
		container_name: mysql
		image: mysql:5.5.60
		restart: always
		volumes:
		  - ./mysql/data:/var/lib/mysql
		  - ./mysql/conf/mysqld.conf:/etc/mysql/mysql.conf.d/mysqld.cnf
		  
我对mysql容器配置的volumes，是把项目的mysql/data目录和docker容器内的/var/lib/mysql建立映射关系

所以下面我进入docker的mysql容器内执行导出命令的时候，只需要把数据导出在/var/lib/mysql/目录下，就可以在宿主机的./mysql/data/目录下找到对应的数据文件

## 进入容器导出数据

首先执行 

	docker ps
	
找到mysql容器的name

然后执行

	docker exec -it mysql /bin/bash
	
进入容器

执行命令

	whereis mysql
	
找到mysql的运行路径，我这里是：/usr/local/mysql/bin，用cd进入

	cd /usr/local/mysql/bin
	
请注意，这里的路径是指docker容器内的路径，跟您的宿主机路径没有关系	

执行导出命令

	mysqldump -u 用户名 -p 数据库名 > 保存文件.sql
	
输入密码后基本导出成功，请注意，保存文件的路径要设置在volumes下面，即/var/lib/mysql/下

随后输入

	exit
	
退出容器内部，回到宿主机上，我们就能够找到导出的数据文件了

如果您要导出csv格式的话，将mysqldump的那句命令改为：

	mysql -u 用户名 --password=密码 --database=数据库名 --execute='SELECT `FIELD`, `FIELD` FROM `TABLE` LIMIT 0, 10000 ' -X > 保存文件.sql
	
即可	


