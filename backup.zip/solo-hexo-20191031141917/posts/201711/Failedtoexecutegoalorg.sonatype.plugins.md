title: Failed to execute goal org.sonatype.plugins
date: '2017-11-27 09:11:56'
updated: '2019-09-02 19:58:12'
tags: [Maven, Java]
permalink: /articles/2017/11/27/1511745116428.html
---
> 这段时间在Maven中央仓库又发布了几个项目，本来一直好好的，昨天开始对版本进行更新的时候，发现开始报错：[ERROR] Failed to execute goal org.sonatype.plugins:nexus-staging-maven-plugin:1.6.3:deploy (injected-nexus-deploy) on project certificate-generator: Could not perform action: there are failing staging rules! Staging rules failure! -> [Help 1]

## 有图有真相

首先已经上传了的Maven项目一览：

![3.pic_hd.jpg](http://oss.fangxinqian.cn/143b37a42623493f8b2f4430672d01c8.jpg)

如上图，红线框的几个项目最近执行

	mvn deploy -Dmaven.test.skip=true -e 
	
进行更新版本，会报文章摘要和标题的错误信息。

我登陆了Nexus Repository Manager检查过情况，相关的错误信息如下图所示：

![1.pic_hd.jpg](http://oss.fangxinqian.cn/28225f64de4246f1b25d521360777475.jpg)

上图说这个项目缺少权限，当然，肯定不会是因为本地项目目录没有执行权限或者写权限之类的问题（因为我已经试过了）。

![2.pic_hd.jpg](http://oss.fangxinqian.cn/06c42a52296a43d2b7f033b0daf67e41.jpg)

这个错误报的很奇怪，没看懂。

所以...求助大神，这个问题怎么解。

不要说百度谷歌了...我都试过实在没找到才来发帖求助的

## 猜你不会看的详细错误日志

	Waiting for operation to complete……………

	[ERROR] 
	[ERROR] Nexus Staging Rules Failure Report
	[ERROR] ==================================
	[ERROR] 
	[ERROR] Repository "comliumapp-1030" failures
	[ERROR]   Rule "RepositoryWritePolicy" failures
	[ERROR]     * Artifact updating: Repository ='releases:Releases' does not allow updating artifact='/com/liumapp/certificate/certificate-generator/v1.0.0/certificate-generator-v1.0.0.pom'
	[ERROR]     * Artifact updating: Repository ='releases:Releases' does not allow updating artifact='/com/liumapp/certificate/certificate-generator/v1.0.0/certificate-generator-v1.0.0-javadoc.jar'
	[ERROR]     * Artifact updating: Repository ='releases:Releases' does not allow updating artifact='/com/liumapp/certificate/certificate-generator/v1.0.0/certificate-generator-v1.0.0-sources.jar'
	[ERROR]     * Artifact updating: Repository ='releases:Releases' does not allow updating artifact='/com/liumapp/certificate/certificate-generator/v1.0.0/certificate-generator-v1.0.0.jar'
	[ERROR] 
	[ERROR] 
	[INFO] ————————————————————————————————————
	[INFO] BUILD FAILURE
	[INFO] ————————————————————————————————————
	[INFO] Total time: 04:02 min
	[INFO] Finished at: 2017-11-26T17:27:17+08:00
	[INFO] Final Memory: 36M/450M
	[INFO] ————————————————————————————————————
	[ERROR] Failed to execute goal org.sonatype.plugins:nexus-staging-maven-plugin:1.6.3:deploy (injected-nexus-deploy) on project certificate-generator: Could not perform action: there are failing staging rules! Staging rules failure! -> [Help 1]
	org.apache.maven.lifecycle.LifecycleExecutionException: Failed to execute goal org.sonatype.plugins:nexus-staging-maven-plugin:1.6.3:deploy (injected-nexus-deploy) on project certificate-generator: Could not perform action: there are failing staging rules!
		at org.apache.maven.lifecycle.internal.MojoExecutor.execute(MojoExecutor.java:212)
		at org.apache.maven.lifecycle.internal.MojoExecutor.execute(MojoExecutor.java:153)
		at org.apache.maven.lifecycle.internal.MojoExecutor.execute(MojoExecutor.java:145)
		at org.apache.maven.lifecycle.internal.LifecycleModuleBuilder.buildProject(LifecycleModuleBuilder.java:116)
		at org.apache.maven.lifecycle.internal.LifecycleModuleBuilder.buildProject(LifecycleModuleBuilder.java:80)
		at org.apache.maven.lifecycle.internal.builder.singlethreaded.SingleThreadedBuilder.build(SingleThreadedBuilder.java:51)
		at org.apache.maven.lifecycle.internal.LifecycleStarter.execute(LifecycleStarter.java:128)
		at org.apache.maven.DefaultMaven.doExecute(DefaultMaven.java:307)
		at org.apache.maven.DefaultMaven.doExecute(DefaultMaven.java:193)
		at org.apache.maven.DefaultMaven.execute(DefaultMaven.java:106)
		at org.apache.maven.cli.MavenCli.execute(MavenCli.java:863)
		at org.apache.maven.cli.MavenCli.doMain(MavenCli.java:288)
		at org.apache.maven.cli.MavenCli.main(MavenCli.java:199)
		at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
		at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
		at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
		at java.lang.reflect.Method.invoke(Method.java:498)
		at org.codehaus.plexus.classworlds.launcher.Launcher.launchEnhanced(Launcher.java:289)
		at org.codehaus.plexus.classworlds.launcher.Launcher.launch(Launcher.java:229)
		at org.codehaus.plexus.classworlds.launcher.Launcher.mainWithExitCode(Launcher.java:415)
		at org.codehaus.plexus.classworlds.launcher.Launcher.main(Launcher.java:356)
	Caused by: org.apache.maven.plugin.MojoExecutionException: Could not perform action: there are failing staging rules!
		at org.sonatype.nexus.maven.staging.deploy.strategy.StagingDeployStrategy.releaseAfterClose(StagingDeployStrategy.java:202)
		at org.sonatype.nexus.maven.staging.deploy.strategy.StagingDeployStrategy.finalizeDeploy(StagingDeployStrategy.java:162)
		at org.sonatype.nexus.maven.staging.deploy.DeployMojo.execute(DeployMojo.java:213)
		at org.apache.maven.plugin.DefaultBuildPluginManager.executeMojo(DefaultBuildPluginManager.java:134)
		at org.apache.maven.lifecycle.internal.MojoExecutor.execute(MojoExecutor.java:207)
		… 20 more
	Caused by: com.sonatype.nexus.staging.client.StagingRuleFailuresException: Staging rules failure!
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV3ServiceImpl.monitorRepositoryTransition(StagingWorkflowV3ServiceImpl.java:273)
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV2ServiceImpl.monitorRepositoryTransition(StagingWorkflowV2ServiceImpl.java:430)
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV2ServiceImpl$10.perform(StagingWorkflowV2ServiceImpl.java:282)
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV2ServiceImpl$10.perform(StagingWorkflowV2ServiceImpl.java:277)
		at com.sonatype.nexus.staging.client.internal.ExceptionConverter.runAndReturn(ExceptionConverter.java:39)
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV2ServiceImpl.releaseStagingRepositories(StagingWorkflowV2ServiceImpl.java:276)
		at com.sonatype.nexus.staging.client.internal.StagingWorkflowV3ServiceImpl.releaseStagingRepositories(StagingWorkflowV3ServiceImpl.java:92)
		at org.sonatype.nexus.maven.staging.deploy.strategy.StagingDeployStrategy.releaseAfterClose(StagingDeployStrategy.java:187)
		… 24 more
	[ERROR] 
	[ERROR] Re-run Maven using the -X switch to enable full debug logging.
	[ERROR] 
	[ERROR] For more information about the errors and possible solutions, please read the following articles:
	[ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
	
	
## 解决办法

经过博主个人坚(xia)持(mao)不(peng)懈(shang)的(si)尝(hao)试(zi)，终于解决了这个问题。

解决办法：

登陆自己在Nexus Repository Manager平台的帐号，点击Staging Repositories，在出来的列表里面，把所有自己先前上传的有错误的项目全部删除，然后重新上传的过程中，一个一个上传，不要同时上传，就可以通过编译成功发布。

如果再试一次还是失败的，重新去Nexus删除刚刚失败的发布，然后用一个新的版本号再尝试一次即可解决
