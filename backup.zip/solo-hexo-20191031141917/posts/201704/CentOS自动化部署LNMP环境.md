title: CentOS自动化部署LNMP环境
date: '2017-04-20 14:35:30'
updated: '2017-06-09 15:14:31'
tags: [CentOS, 自动化部署, Shell]
permalink: /articles/2017/04/20/1492658108249.html
---

## CentOS自动化部署LNMP环境

***

> 因为公司项目较多，而且每一个项目一般都部署在一台独立的服务器上，每台服务器的环境部署其实是一个重复的工作，所以就用shell做了一个LNMP环境的自动化部署。

### 预期目标

通过执行一个shell脚本，暂且命名为install.sh，自动在CentOS系统上安装php-5.6.30，nginx-1.12.0，mysql-5.5.37，同时完成相关配置文件的调整、目录的索引、依赖库的安装、ftp、jpeg、libevent、libiconv、libmycrypt、libpng、pcre、openssl、zlib等CentOS常用程序的安装。

通过执行一个shell脚本，暂且命名为uninstall.sh，自动删除安装过的所有程序。

### 设计思路


1.使用固定的版本

2.所有程序的源代码跟shell脚本部署在相同目录下

3.shell脚本使用以程序名称命名的目录来分别运行，install.sh作为入口文件和主文件，具体的安装脚本分割开来

最终得到的目录结构如下图所示

![bf8b910235c747099d3699c57d19dcec-2.pic.jpg](//om40sen9v.bkt.clouddn.com//file/2017/4/bf8b910235c747099d3699c57d19dcec-2.pic.jpg) 


### 代码讲解

源代码： **[lnmp](https://github.com/liumapp/lnmp)**

> 代码部分分为安装和卸载两个部分进行解读

####  安装

直接上install.sh的代码

	#!/bin/bash

	####---- global variables ----begin####
	export nginx_version=1.12.0
	export mysql_version=5.5.37
	export php_version=5.6.30
	export vsftpd_version=3.0.2
	export install_ftp_version=0.0.0
	####---- global variables ----end####

	web=nginx
	install_log=/alidata/website-info.log

	####---- version report ----begin####

	tmp=1
	echo ""
	echo "You select the version :"
	echo "web    : $web"
	if echo $web |grep "nginx" > /dev/null;then
	  echo "nginx : $nginx_version"
	else
	  echo "false"
	  exit 0
	fi
	echo "php    : $php_version"
	echo "mysql  : $mysql_version"

	read -p "Enter the y or Y to continue:" isY
	if [ "${isY}" != "y" ] && [ "${isY}" != "Y" ];then
	   exit 1
	fi
	####---- version report ----end####


	####---- Clean up the environment ----begin####
	echo "will be installed, wait ..."
	./uninstall.sh in &> /dev/null
	####---- Clean up the environment ----end####


	if echo $web|grep "nginx" > /dev/null;then
	web_dir=nginx-${nginx_version}
	else
	echo "false"
	exit 0
	fi

	php_dir=php-${php_version}

	if [ `uname -m` == "x86_64" ];then
	machine=x86_64
	else
	machine=i686
	fi

	####---- global variables ----begin####
	export web
	export web_dir
	export php_dir
	export mysql_dir=mysql-${mysql_version}
	export vsftpd_dir=vsftpd-${vsftpd_version}
	####---- global variables ----end####

	ifcentos=$(cat /proc/version | grep centos)

	####---- install dependencies ----begin####
	if [ "$ifcentos" != "" ] || [ "$machine" == "i686" ];then
	rpm -e httpd-2.2.3-31.el5.centos gnome-user-share &> /dev/null
	fi

	\cp /etc/rc.local /etc/rc.local.bak
	if [ "$ifredhat" != "" ];then
	rpm -e --allmatches mysql MySQL-python perl-DBD-MySQL dovecot exim qt-MySQL perl-DBD-MySQL dovecot qt-MySQL mysql-server mysql-connector-odbc php-mysql mysql-bench libdbi-dbd-mysql mysql-devel-5.0.77-3.el5 httpd php mod_auth_mysql mailman squirrelmail php-pdo php-common php-mbstring php-cli &> /dev/null
	fi

	if [ "$ifcentos" != "" ];then
	  sed -i 's/^exclude/#exclude/' /etc/yum.conf
	  yum makecache
	  yum -y remove mysql MySQL-python perl-DBD-MySQL dovecot exim qt-MySQL perl-DBD-MySQL dovecot qt-MySQL mysql-server mysql-connector-odbc php-mysql mysql-bench libdbi-dbd-mysql mysql-devel-5.0.77-3.el5 httpd php mod_auth_mysql mailman squirrelmail php-pdo php-common php-mbstring php-cli &> /dev/null
	  yum -y install gcc gcc-c++ gcc-g77 make libtool autoconf patch unzip automake libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl libmcrypt libmcrypt-devel libpng libpng-devel libjpeg-devel openssl openssl-devel curl curl-devel libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl autoconf automake libaio*
	  iptables -F
	else
	  echo "error !! Your system is not centos!"
	  exit 0	
	fi
	####---- install dependencies ----end####

	####---- openssl update---begin####
	./env/update_openssl.sh
	####---- openssl update---end####

	####---- install software ----begin####
	rm -f tmp.log
	echo tmp.log

	./env/install_set_ulimit.sh

	./env/install_dir.sh
	echo "---------- make dir ok ----------" >> tmp.log

	./env/install_env.sh
	echo "---------- env ok ----------" >> tmp.log

	./mysql/install_${mysql_dir}.sh
	echo "---------- ${mysql_dir} ok ----------" >> tmp.log

	if echo $web |grep "nginx" > /dev/null;then
		./nginx/install_nginx-${nginx_version}.sh
		echo "---------- ${web_dir} ok ----------" >> tmp.log
		./php/install_nginx_php-${php_version}.sh
		echo "---------- ${php_dir} ok ----------" >> tmp.log
	else
		./apache/install_httpd-${httpd_version}.sh
		echo "---------- ${web_dir} ok ----------" >> tmp.log
		./php/install_httpd_php-${php_version}.sh
		echo "---------- ${php_dir} ok ----------" >> tmp.log
	fi

	./php/install_php_extension.sh
	echo "---------- php extension ok ----------" >> tmp.log

	./ftp/install_${vsftpd_dir}.sh
	echo "---------- vsftpd-$vsftpd_version  ok ----------" >> tmp.log

	mkdir -p /alidata/www/default
	if echo $web |grep "nginx" > /dev/null;then
		\cp ./res/index-nginx.html /alidata/www/default/index.html
	else
		\cp ./res/index-apache.html /alidata/www/default/index.html
	fi

	cat > /alidata/www/default/info.php << EOF
	<?php
	phpinfo();
	?>
	EOF

	chown www:www -R /alidata/www/

	\cp ./res/initPasswd.sh /alidata/init/
	chmod 755 /alidata/init/initPasswd.sh

	echo "---------- web init ok ----------" >> tmp.log
	####---- install software ----end####


	####---- Start command is written to the rc.local ----begin####
	if ! cat /etc/rc.local | grep "/etc/init.d/mysqld" > /dev/null;then 
		echo "/etc/init.d/mysqld start" >> /etc/rc.local
	fi
	if echo $web|grep "nginx" > /dev/null;then
	  if ! cat /etc/rc.local | grep "/etc/init.d/nginx" > /dev/null;then 
		 echo "/etc/init.d/nginx start" >> /etc/rc.local
		 echo "/etc/init.d/php-fpm start" >> /etc/rc.local
	  fi
	else
	  if ! cat /etc/rc.local | grep "/etc/init.d/httpd" > /dev/null;then 
		 echo "/etc/init.d/httpd start" >> /etc/rc.local
	  fi
	fi
	if ! cat /etc/rc.local | grep "/etc/init.d/vsftpd" > /dev/null;then 
		echo "/etc/init.d/vsftpd start" >> /etc/rc.local
	fi
	if ! cat /etc/rc.local | grep "/alidata/init/initPasswd.sh" > /dev/null;then 
		echo "/alidata/init/initPasswd.sh" >> /etc/rc.local
	fi
	####---- Start command is written to the rc.local ----end####


	####---- centos yum configuration----begin####
	if [ "$ifcentos" != "" ] && [ "$machine" == "x86_64" ];then
	sed -i 's/^#exclude/exclude/' /etc/yum.conf
	mkdir -p /var/lock/subsys/
	fi
	####---- centos yum configuration ----end####

	####---- mysql password initialization ----begin####
	echo "---------- rc init ok ----------" >> tmp.log
	TMP_PASS=$(date | md5sum |head -c 10)
	/alidata/server/mysql/bin/mysqladmin -u root password "$TMP_PASS"
	sed -i s/'mysql_password'/${TMP_PASS}/g account.log
	echo "---------- mysql init ok ----------" >> tmp.log
	####---- mysql password initialization ----end####


	####---- Environment variable settings ----begin####
	\cp /etc/profile /etc/profile.bak
	if echo $web|grep "nginx" > /dev/null;then
	  echo 'export PATH=$PATH:/alidata/server/mysql/bin:/alidata/server/nginx/sbin:/alidata/server/php/sbin:/alidata/server/php/bin' >> /etc/profile
	  export PATH=$PATH:/alidata/server/mysql/bin:/alidata/server/nginx/sbin:/alidata/server/php/sbin:/alidata/server/php/bin
	else
	  echo 'export PATH=$PATH:/alidata/server/mysql/bin:/alidata/server/httpd/bin:/alidata/server/php/sbin:/alidata/server/php/bin' >> /etc/profile
	  export PATH=$PATH:/alidata/server/mysql/bin:/alidata/server/httpd/bin:/alidata/server/php/sbin:/alidata/server/php/bin
	fi
	####---- Environment variable settings ----end####


	####---- restart ----begin####
	if echo $web|grep "nginx" > /dev/null;then
	/etc/init.d/php-fpm restart > /dev/null
	/etc/init.d/nginx restart > /dev/null
	else
	/etc/init.d/httpd restart > /dev/null
	/etc/init.d/httpd start &> /dev/null
	fi
	/etc/init.d/vsftpd restart
	####---- restart ----end####

	####---- log ----begin####
	\cp tmp.log $install_log
	cat $install_log
	\cp -a account.log /alidata/
	####---- log ----end####
	bash

通过上面的脚本我们可以知道，它在安装不同程序的时候，是调用不同的shell脚本来进行安装的。

比如，安装环境的脚本：

> 请注意，安装环境的脚本文件是部署在env目录下方

#### install_dir.sh

#!/bin/bash

	userdel www
	groupadd www
	useradd -g www -M -d /alidata/www -s /sbin/nologin www &> /dev/null

	mkdir -p /alidata
	mkdir -p /alidata/server
	mkdir -p /alidata/server/openssl
	mkdir -p /alidata/www
	mkdir -p /alidata/init
	mkdir -p /alidata/log
	mkdir -p /alidata/log/php
	mkdir -p /alidata/log/mysql
	chown -R www:www /alidata/log

	mkdir -p /alidata/server/${mysql_dir}
	ln -s /alidata/server/${mysql_dir} /alidata/server/mysql

	mkdir -p /alidata/server/${php_dir}
	ln -s /alidata/server/${php_dir} /alidata/server/php


	mkdir -p /alidata/server/${web_dir}
	if echo $web |grep "nginx" > /dev/null;then
	mkdir -p /alidata/log/nginx
	mkdir -p /alidata/log/nginx/access
	ln -s /alidata/server/${web_dir} /alidata/server/nginx
	else
	mkdir -p /alidata/log/httpd
	mkdir -p /alidata/log/httpd/access
	ln -s /alidata/server/${web_dir} /alidata/server/httpd
	fi
	
	
#### install_env.sh	
	
	
	#!/bin/sh

	CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
	if [ ! -f libiconv-1.13.1.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/libiconv-1.13.1.tar.gz
	fi
	rm -rf libiconv-1.13.1
	tar zxvf libiconv-1.13.1.tar.gz
	cd libiconv-1.13.1
	./configure --prefix=/usr/local
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	cd ..

	if [ ! -f zlib-1.2.3.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/zlib-1.2.3.tar.gz
	fi
	rm -rf zlib-1.2.3
	tar zxvf zlib-1.2.3.tar.gz
	cd zlib-1.2.3
	./configure
	if [ $CPU_NUM -gt 1 ];then
		make CFLAGS=-fpic -j$CPU_NUM
	else
		make CFLAGS=-fpic
	fi
	make install
	cd ..

	if [ ! -f freetype-2.1.10.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/freetype-2.1.10.tar.gz
	fi
	rm -rf freetype-2.1.10
	tar zxvf freetype-2.1.10.tar.gz
	cd freetype-2.1.10
	./configure --prefix=/usr/local/freetype.2.1.10
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	cd ..

	if [ ! -f libpng-1.2.50.tar.gz ];then
		#wget http://soft.phpwind.me/web/libpng-1.2.8.tar.gz
		wget http://oss.aliyuncs.com/aliyunecs/onekey/libpng-1.2.50.tar.gz
	fi
	rm -rf libpng-1.2.50
	tar zxvf libpng-1.2.50.tar.gz
	cd libpng-1.2.50
	./configure --prefix=/usr/local/libpng.1.2.50
	if [ $CPU_NUM -gt 1 ];then
		make CFLAGS=-fpic -j$CPU_NUM
	else
		make CFLAGS=-fpic
	fi
	make install
	cd ..

	if [ ! -f libevent-1.4.14b.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/libevent-1.4.14b.tar.gz
	fi
	rm -rf libevent-1.4.14b
	tar zxvf libevent-1.4.14b.tar.gz
	cd libevent-1.4.14b
	./configure
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	cd ..

	if [ ! -f libmcrypt-2.5.8.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/libmcrypt-2.5.8.tar.gz
	fi
	rm -rf libmcrypt-2.5.8
	tar zxvf libmcrypt-2.5.8.tar.gz
	cd libmcrypt-2.5.8
	./configure --disable-posix-threads
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	/sbin/ldconfig
	cd libltdl/
	./configure --enable-ltdl-install
	make
	make install
	cd ../..

	if [ ! -f pcre-8.12.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/pcre-8.12.tar.gz
	fi
	rm -rf pcre-8.12
	tar zxvf pcre-8.12.tar.gz
	cd pcre-8.12
	./configure
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	cd ..

	if [ ! -f jpegsrc.v6b.tar.gz ];then
		wget http://oss.aliyuncs.com/aliyunecs/onekey/jpegsrc.v6b.tar.gz
	fi
	rm -rf jpeg-6b
	tar zxvf jpegsrc.v6b.tar.gz
	cd jpeg-6b
	if [ -e /usr/share/libtool/config.guess ];then
	cp -f /usr/share/libtool/config.guess .
	elif [ -e /usr/share/libtool/config/config.guess ];then
	cp -f /usr/share/libtool/config/config.guess .
	fi
	if [ -e /usr/share/libtool/config.sub ];then
	cp -f /usr/share/libtool/config.sub .
	elif [ -e /usr/share/libtool/config/config.sub ];then
	cp -f /usr/share/libtool/config/config.sub .
	fi
	./configure --prefix=/usr/local/jpeg.6 --enable-shared --enable-static
	mkdir -p /usr/local/jpeg.6/include
	mkdir /usr/local/jpeg.6/lib
	mkdir /usr/local/jpeg.6/bin
	mkdir -p /usr/local/jpeg.6/man/man1
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install-lib
	make install
	cd ..

	#load /usr/local/lib .so
	touch /etc/ld.so.conf.d/usrlib.conf
	echo "/usr/local/lib" > /etc/ld.so.conf.d/usrlib.conf
	/sbin/ldconfig

	#create account.log
	cat > account.log << END
	##########################################################################
	# 
	# thank you for using aliyun virtual machine
	# 
	##########################################################################

	FTP:
	account:www
	password:ftp_password

	MySQL:
	account:root
	password:mysql_password
	END


#### install_set_ulimit.sh

#!/bin/sh

	if cat /etc/security/limits.conf | grep "* soft nofile 65535" > /dev/null;then
		echo ""
	else
		echo "* soft nofile 65535" >> /etc/security/limits.conf
	fi

	if cat /etc/security/limits.conf | grep "* hard nofile 65535" > /dev/null ;then
		echo ""
	else
		echo "* hard nofile 65535" >> /etc/security/limits.conf
	fi

#### update_openssl.sh

	#!/bin/bash
	if ls /usr/local/ssl > /dev/null ;then
		if openssl version -a |grep "OpenSSL 1.0.1h"  > /dev/null;then 
			exit 0
		fi
	fi
	CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
	yum install zlib -y
	rm -rf openssl-1.0.1h
	if [ ! -f openssl-1.0.1h.tar.gz ];then
		wget http://t-down.oss-cn-hangzhou.aliyuncs.com/openssl-1.0.1h.tar.gz
	fi
	tar zxvf openssl-1.0.1h.tar.gz
	\mv /usr/local/ssl /usr/local/ssl.OFF
	cd openssl-1.0.1h
	./config shared zlib
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	\mv /usr/bin/openssl /usr/bin/openssl.OFF
	\mv /usr/include/openssl /usr/include/openssl.OFF
	ln -s /usr/local/ssl/bin/openssl /usr/bin/openssl
	ln -s /usr/local/ssl/include/openssl /usr/include/openssl
	if ! cat /etc/ld.so.conf| grep "/usr/local/ssl/lib" >> /dev/null;then
		echo "/usr/local/ssl/lib" >> /etc/ld.so.conf
	fi
	ldconfig -v
	openssl version -a

安装ftp的脚本

> 请注意，安装ftp的脚本是部署在ftp目录下

#### install_vsftpd-3.0.2.sh

#!/bin/bash

	if [ `uname -m` == "x86_64" ];then
	machine=x86_64
	else
	machine=i686
	fi
	ifrpm=$(cat /proc/version | grep -E "redhat|centos")
	ifdpkg=$(cat /proc/version | grep -Ei "ubuntu|debian")
	ifcentos=$(cat /proc/version | grep centos)

	if [ "$ifrpm" != "" ];then
		if [ ! -f vsftpd-3.0.2-2.el6.x86_64.rpm ];then
			wget http://test-oracle.oss-cn-hangzhou.aliyuncs.com/vsftpd-3.0.2-2.el6.x86_64.rpm
		fi
		rpm -ivh vsftpd-3.0.2-2.el6.x86_64.rpm
		\cp -f ./ftp/config-ftp/rpm_ftp/* /etc/vsftpd/
	fi

	if [ "$ifcentos" != "" ] && [ "$machine" == "i686" ];then
		rm -rf /etc/vsftpd/vsftpd.conf
		\cp -f ./ftp/config-ftp/vsftpdcentosi686.conf /etc/vsftpd/vsftpd.conf
	fi

	/etc/init.d/vsftpd start

	chown -R www:www /alidata/www

	#bug kill: '500 OOPS: vsftpd: refusing to run with writable root inside chroot()'
	chmod a-w /alidata/www

	MATRIX="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
	LENGTH="9"
	while [ "${n:=1}" -le "$LENGTH" ]
	do
		PASS="$PASS${MATRIX:$(($RANDOM%${#MATRIX})):1}"
		let n+=1
	done
	if [ "$ifrpm" != "" ];then
	echo $PASS | passwd --stdin www
	else
	echo "www:$PASS" | chpasswd
	fi

	sed -i s/'ftp_password'/${PASS}/g account.log


安装mysql的脚本

>  请注意，mysql的安装是部署在mysql目录下

#### install_mysql-5.5.37.sh

	#!/bin/bash
	if [ `uname -m` == "x86_64" ];then
	machine=x86_64
	else
	machine=i686
	fi
	if [ $machine == "x86_64" ];then
	  rm -rf mysql-5.5.37-linux2.6-x86_64
	  if [ ! -f mysql-5.5.37-linux2.6-x86_64.tar.gz ];then
		 wget http://test-oracle.oss-cn-hangzhou.aliyuncs.com/mysql-5.5.37-linux2.6-x86_64.tar.gz
	  fi
	  tar -xzvf mysql-5.5.37-linux2.6-x86_64.tar.gz
	  mv mysql-5.5.37-linux2.6-x86_64/* /alidata/server/mysql
	else
	  rm -rf mysql-5.5.37-linux2.6-i686
	  if [ ! -f mysql-5.5.37-linux2.6-i686.tar.gz ];then
		wget http://test-oracle.oss-cn-hangzhou.aliyuncs.com/mysql-5.5.37-linux2.6-i686.tar.gz
	  fi
	  tar -xzvf mysql-5.5.37-linux2.6-i686.tar.gz
	  mv mysql-5.5.37-linux2.6-i686/* /alidata/server/mysql
	fi

	groupadd mysql
	useradd -g mysql -s /sbin/nologin mysql
	/alidata/server/mysql/scripts/mysql_install_db --datadir=/alidata/server/mysql/data/ --basedir=/alidata/server/mysql --user=mysql
	chown -R mysql:mysql /alidata/server/mysql/
	chown -R mysql:mysql /alidata/server/mysql/data/
	chown -R mysql:mysql /alidata/log/mysql
	\cp -f /alidata/server/mysql/support-files/mysql.server /etc/init.d/mysqld
	sed -i 's#^basedir=$#basedir=/alidata/server/mysql#' /etc/init.d/mysqld
	sed -i 's#^datadir=$#datadir=/alidata/server/mysql/data#' /etc/init.d/mysqld
	\cp -f /alidata/server/mysql/support-files/my-medium.cnf /etc/my.cnf
	sed -i 's#skip-external-locking#skip-external-locking\nlog-error=/alidata/log/mysql/error.log#' /etc/my.cnf
	chmod 755 /etc/init.d/mysqld
	/etc/init.d/mysqld start


安装nginx的脚本

>  nginx的安装脚本部署在nginx目录下

#### install_nginx-1.12.0.sh

	#!/bin/bash
	rm -rf nginx-1.12.0
	if [ ! -f nginx-1.12.0.tar.gz ];then
	  echo "you lost your nginx file !"
	  exit 0	
	fi
	tar zxvf nginx-1.12.0.tar.gz
	cd nginx-1.12.0
	./configure --user=www \
	--group=www \
	--prefix=/alidata/server/nginx \
	--with-http_stub_status_module \
	--without-http-cache \
	--with-http_ssl_module \
	--with-http_gzip_static_module
	CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
	if [ $CPU_NUM -gt 1 ];then
		make -j$CPU_NUM
	else
		make
	fi
	make install
	chmod 775 /alidata/server/nginx/logs
	chown -R www:www /alidata/server/nginx/logs
	chmod -R 775 /alidata/www
	chown -R www:www /alidata/www
	cd ..
	cp -fR ./nginx/config-nginx/* /alidata/server/nginx/conf/
	chmod 755 /alidata/server/nginx/sbin/nginx
	#/alidata/server/nginx/sbin/nginx
	mv /alidata/server/nginx/conf/nginx /etc/init.d/
	chmod +x /etc/init.d/nginx
	/etc/init.d/nginx start

安装php的脚本

> PHP的安装脚本在php目录下

#### install_nginx_php-5.6.30.sh

	#!/bin/bash
	rm -rf php-5.6.30
	if [ ! -f php-5.6.30.tar.gz ];then
	  echo "you lost your php file!"
	  exit
	fi
	tar zxvf php-5.6.30.tar.gz
	cd php-5.6.30
	./configure --prefix=/alidata/server/php \
	--with-config-file-path=/alidata/server/php/etc \
	--with-mysql=mysqlnd \
	--with-mysqli=mysqlnd \
	--with-pdo-mysql=mysqlnd \
	--enable-fpm \
	--enable-fastcgi \
	--enable-static \
	--enable-inline-optimization \
	--enable-sockets \
	--enable-wddx \
	--enable-zip \
	--enable-calendar \
	--enable-bcmath \
	--enable-soap \
	--with-zlib \
	--with-iconv \
	--with-gd \
	--with-xmlrpc \
	--enable-mbstring \
	--without-sqlite \
	--with-curl \
	--enable-ftp \
	--with-mcrypt  \
	--with-freetype-dir=/usr/local/freetype.2.1.10 \
	--with-jpeg-dir=/usr/local/jpeg.6 \
	--with-png-dir=/usr/local/libpng.1.2.50 \
	--disable-ipv6 \
	--disable-debug \
	--disable-maintainer-zts \
	--disable-safe-mode \
	--disable-fileinfo

	CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
	if [ $CPU_NUM -gt 1 ];then
		make ZEND_EXTRA_LIBS='-liconv' -j$CPU_NUM
	else
		make ZEND_EXTRA_LIBS='-liconv'
	fi
	make install
	cd ..
	cp ./php-5.6.30/php.ini-production /alidata/server/php/etc/php.ini
	#adjust php.ini
	sed -i 's#; extension_dir = \"\.\/\"#extension_dir = "/alidata/server/php/lib/php/extensions/no-debug-non-zts-20131226/"#'  /alidata/server/php/etc/php.ini
	sed -i 's/post_max_size = 8M/post_max_size = 64M/g' /alidata/server/php/etc/php.ini
	sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 64M/g' /alidata/server/php/etc/php.ini
	sed -i 's/;date.timezone =/date.timezone = PRC/g' /alidata/server/php/etc/php.ini
	sed -i 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=1/g' /alidata/server/php/etc/php.ini
	sed -i 's/max_execution_time = 30/max_execution_time = 300/g' /alidata/server/php/etc/php.ini
	#adjust php-fpm
	cp /alidata/server/php/etc/php-fpm.conf.default /alidata/server/php/etc/php-fpm.conf
	sed -i 's,user = nobody,user=www,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,group = nobody,group=www,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,^pm.min_spare_servers = 1,pm.min_spare_servers = 5,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,^pm.max_spare_servers = 3,pm.max_spare_servers = 35,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,^pm.max_children = 5,pm.max_children = 100,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,^pm.start_servers = 2,pm.start_servers = 20,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,;pid = run/php-fpm.pid,pid = run/php-fpm.pid,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,;error_log = log/php-fpm.log,error_log = /alidata/log/php/php-fpm.log,g'   /alidata/server/php/etc/php-fpm.conf
	sed -i 's,;slowlog = log/$pool.log.slow,slowlog = /alidata/log/php/\$pool.log.slow,g'   /alidata/server/php/etc/php-fpm.conf
	#self start
	install -v -m755 ./php-5.6.30/sapi/fpm/init.d.php-fpm  /etc/init.d/php-fpm
	/etc/init.d/php-fpm start
	sleep 5


#### install_php_extension.sh

	#!/bin/bash

	if [ `uname -m` == "x86_64" ];then
	machine=x86_64
	else
	machine=i686
	fi

	#memcache
	#if [ ! -f memcache-3.0.6.tgz ];then
	#	wget http://oss.aliyuncs.com/aliyunecs/onekey/php_extend/memcache-3.0.6.tgz
	#fi
	#rm -rf memcache-3.0.6
	#tar -xzvf memcache-3.0.6.tgz
	#cd memcache-3.0.6
	#/alidata/server/php/bin/phpize
	#./configure --enable-memcache --with-php-config=/alidata/server/php/bin/php-config
	#CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
	#if [ $CPU_NUM -gt 1 ];then
	#    make -j$CPU_NUM
	#else
	#    make
	#fi
	#make install
	#cd ..
	#echo "extension=memcache.so" >> /alidata/server/php/etc/php.ini

	#zend
	if ls -l /alidata/server/ |grep "5.3.18" > /dev/null;then
	  mkdir -p /alidata/server/php/lib/php/extensions/no-debug-non-zts-20090626/
	  if [ $machine == "x86_64" ];then
		  if [ ! -f ZendGuardLoader-php-5.3-linux-glibc23-x86_64.tar.gz ];then
			wget http://oss.aliyuncs.com/aliyunecs/onekey/php_extend/ZendGuardLoader-php-5.3-linux-glibc23-x86_64.tar.gz
		  fi
		  tar zxvf ZendGuardLoader-php-5.3-linux-glibc23-x86_64.tar.gz
		  mv ./ZendGuardLoader-php-5.3-linux-glibc23-x86_64/php-5.3.x/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20090626/
	  else
		  if [ ! -f ZendGuardLoader-php-5.3-linux-glibc23-i386.tar.gz ];then
			wget http://oss.aliyuncs.com/aliyunecs/onekey/php_extend/ZendGuardLoader-php-5.3-linux-glibc23-i386.tar.gz
		  fi
		  tar zxvf ZendGuardLoader-php-5.3-linux-glibc23-i386.tar.gz
		  mv ./ZendGuardLoader-php-5.3-linux-glibc23-i386/php-5.3.x/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20090626/
	  fi
	  echo "zend_extension=/alidata/server/php/lib/php/extensions/no-debug-non-zts-20090626/ZendGuardLoader.so" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.enable=1" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.disable_licensing=0" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.obfuscation_level_support=3" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.license_path=" >> /alidata/server/php/etc/php.ini 
	elif ls -l /alidata/server/ |grep -E "5.4.23|5.4.27" > /dev/null;then
	  mkdir -p /alidata/server/php/lib/php/extensions/no-debug-non-zts-20100525/
	  if [ $machine == "x86_64" ];then
		  if [ ! -f ZendGuardLoader-70429-PHP-5.4-linux-glibc23-x86_64.tar.gz ];then 
			wget http://oss.aliyuncs.com/aliyunecs/onekey/php_extend/ZendGuardLoader-70429-PHP-5.4-linux-glibc23-x86_64.tar.gz
		  fi
		  tar zxvf ZendGuardLoader-70429-PHP-5.4-linux-glibc23-x86_64.tar.gz
		  mv ./ZendGuardLoader-70429-PHP-5.4-linux-glibc23-x86_64/php-5.4.x/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20100525/
	  else
		  if [ ! -f ZendGuardLoader-70429-PHP-5.4-linux-glibc23-i386.tar.gz ];then 
			wget http://oss.aliyuncs.com/aliyunecs/onekey/php_extend/ZendGuardLoader-70429-PHP-5.4-linux-glibc23-i386.tar.gz
		  fi
		  tar zxvf ZendGuardLoader-70429-PHP-5.4-linux-glibc23-i386.tar.gz
		  mv ./ZendGuardLoader-70429-PHP-5.4-linux-glibc23-i386/php-5.4.x/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20100525/
	  fi
	  echo "zend_extension=/alidata/server/php/lib/php/extensions/no-debug-non-zts-20100525/ZendGuardLoader.so" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.enable=1" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.disable_licensing=0" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.obfuscation_level_support=3" >> /alidata/server/php/etc/php.ini
	  echo "zend_loader.license_path=" >> /alidata/server/php/etc/php.ini 
	elif ls -l /alidata/server/ |grep "5.5.7" > /dev/null;then
	  mkdir -p /alidata/server/php/lib/php/extensions/no-debug-non-zts-20121212/
	  sed -i 's#\[opcache\]#\[opcache\]\nzend_extension=opcache.so#' /alidata/server/php/etc/php.ini
	  sed -i 's#;opcache.enable=0#opcache.enable=1#' /alidata/server/php/etc/php.ini
	elif ls -l /alidata/server/ |grep "5.6.30" > /dev/null;then
	  mkdir -p /alidata/server/php/lib/php/extensions/no-debug-non-zts-20131226/
	  sed -i 's#\[opcache\]#\[opcache\]\nzend_extension=opcache.so#' /alidata/server/php/etc/php.ini
	  sed -i 's#;opcache.enable=0#opcache.enable=1#' /alidata/server/php/etc/php.ini
	fi

	cd php-5.6.30/ext/openssl/
	\cp -a config0.m4 config.m4
	/alidata/server/php/bin/phpize
	./configure --with-openssl=/usr/local/ssl/ --with-php-config=/alidata/server/php/bin/php-config
	make
	make install
	echo "extension=openssl.so" >> /alidata/server/php/etc/php.ini
	cd ../../../


最后是密码的配置

> 密码的配置部署在res目录下

#### initPasswd.sh

	#!/bin/bash
	ifrpm=$(cat /proc/version | grep -E "redhat|centos")
	ifdpkg=$(cat /proc/version | grep -Ei "ubuntu|debian")

	#modify ftp passwd
	PASS=$(date | md5sum |head -c 9)
	if [ "$ifrpm" != "" ];then
		echo $PASS | passwd --stdin www
	else
		echo "www:$PASS" | chpasswd
	fi

	sed -i "9s/.*/password:${PASS}/" /alidata/account.log
	sleep 1

	#modify mysql passwd
	PASS=$(date | md5sum |head -c 10)
	OLDPASSWD=$(sed -n '13p' /alidata/account.log |awk -F: '{print $2}')
	/alidata/server/mysql/bin/mysqladmin -uroot -p$OLDPASSWD password $PASS
	sed -i "13s/.*/password:${PASS}/" /alidata/account.log

	if [ "$ifrpm" != "" ];then
			sed -i "/\/alidata\/init.*/d" /etc/rc.d/rc.local
	else
			sed -i "/\/alidata\/init.*/d" /etc/rc.local
	fi



#### 卸载

#### uninstall.sh

#!/bin/bash

	if [ "$1" != "in" ];then
		echo "Before cleaning the installation script environment !"
		echo "Please backup your data !!"
		read -p "Enter the y or Y to continue:" isY
		if [ "${isY}" != "y" ] && [ "${isY}" != "Y" ];then
		   exit 1
		fi
	fi

	mkdir -p /alidata

	/etc/init.d/mysqld stop &> /dev/null
	/etc/init.d/nginx stop &> /dev/null
	/etc/init.d/php-fpm stop &> /dev/null
	/etc/init.d/vsftpd stop &> /dev/null
	/etc/init.d/httpd stop &> /dev/null
	killall mysqld &> /dev/null
	killall nginx &> /dev/null
	killall httpd &> /dev/null
	killall apache2 &> /dev/null
	killall vsftpd &> /dev/null
	killall php-fpm &> /dev/null

	echo "--------> Clean up the installation environment"
	rm -rf /usr/local/freetype.2.1.10
	rm -rf /usr/local/libpng.1.2.50
	rm -rf /usr/local/freetype.2.1.10
	rm -rf /usr/local/libpng.1.2.50
	rm -rf /usr/local/jpeg.6

	echo ""
	echo "--------> Delete directory"
	echo "/alidata/server/mysql             delete ok!" 
	rm -rf /alidata/server/mysql
	echo "rm -rf /alidata/server/mysql-*    delete ok!"
	rm -rf /alidata/server/mysql-*
	echo "/alidata/server/php               delete ok!"
	rm -rf /alidata/server/php
	echo "/alidata/server/php-*             delete ok!"
	rm -rf /alidata/server/php-*
	echo "/alidata/server/nginx             delete ok!"
	rm -rf /alidata/server/nginx
	echo "rm -rf /alidata/server/nginx-*    delete ok!"
	rm -rf /alidata/server/nginx-*
	echo "/alidata/server/httpd             delete ok!"
	rm -rf /alidata/server/httpd
	echo "/alidata/server/httpd-*           delete ok!"
	rm -rf /alidata/server/httpd-*
	echo ""
	echo "/alidata/log/php                  delete ok!"
	rm -rf /alidata/log/php
	echo "/alidata/log/mysql                delete ok!"
	rm -rf /alidata/log/mysql
	echo "/alidata/log/nginx                delete ok!"
	rm -rf /alidata/log/nginx
	echo "/alidata/log/httpd                delete ok!"
	rm -rf /alidata/log/httpd
	echo ""

	echo "/alidata/www                      delete ok!"
	rm -rf /alidata/www
	echo "/alidata/init                     delete ok!"
	rm -rf /alidata/init

	echo ""
	echo "--------> Delete file"
	echo "/etc/my.cnf                delete ok!"
	rm -f /etc/my.cnf
	echo "/etc/init.d/mysqld         delete ok!"
	rm -f /etc/init.d/mysqld
	echo "/etc/init.d/nginx          delete ok!"
	rm -f /etc/init.d/nginx
	echo "/etc/init.d/php-fpm        delete ok!"
	rm -r /etc/init.d/php-fpm
	echo "/etc/init.d/httpd          delete ok!"
	rm -f /etc/init.d/httpd

	echo ""
	ifrpm=$(cat /proc/version | grep -E "redhat|centos")
	ifdpkg=$(cat /proc/version | grep -Ei "ubuntu|debian")
	ifcentos=$(cat /proc/version | grep centos)
	echo "--------> Clean up files"
	echo "/etc/rc.local                   clean ok!"
	if [ "$ifrpm" != "" ];then
		if [ -L /etc/rc.local ];then
			echo ""
		else
			\cp /etc/rc.local /etc/rc.local.bak
			rm -rf /etc/rc.local
			ln -s /etc/rc.d/rc.local /etc/rc.local
		fi
		sed -i "/\/etc\/init\.d\/mysqld.*/d" /etc/rc.d/rc.local
		sed -i "/\/etc\/init\.d\/nginx.*/d" /etc/rc.d/rc.local
		sed -i "/\/etc\/init\.d\/php-fpm.*/d" /etc/rc.d/rc.local
		sed -i "/\/etc\/init\.d\/vsftpd.*/d" /etc/rc.d/rc.local
		sed -i "/\/etc\/init\.d\/httpd.*/d" /etc/rc.d/rc.local
		sed -i "/\/alidata\/init\/initPasswd\.sh.*/d" /etc/rc.d/rc.local
	else
		sed -i "/\/etc\/init\.d\/mysqld.*/d" /etc/rc.local
		sed -i "/\/etc\/init\.d\/nginx.*/d" /etc/rc.local
		sed -i "/\/etc\/init\.d\/php-fpm.*/d" /etc/rc.local
		sed -i "/\/etc\/init\.d\/vsftpd.*/d" /etc/rc.local
		sed -i "/\/etc\/init\.d\/httpd.*/d" /etc/rc.local
		sed -i "/\/alidata\/init\/initPasswd\.sh.*/d" /etc/rc.local
	fi

	echo ""
	echo "/etc/profile                    clean ok!"
	sed -i "/export PATH=\$PATH\:\/alidata\/server\/mysql\/bin.*/d" /etc/profile
	source /etc/profile

	echo ""
	if [ "$ifrpm" != "" ];then
		yum -y remove vsftpd  &> /dev/null
		rpm -e vsftpd
		rm -f /etc/vsftpd/chroot_list
		rm -f /etc/vsftpd/ftpusers
		rm -f /etc/vsftpd/user_list
		rm -f /etc/vsftpd/vsftpd.conf
	else
		apt-get -y remove vsftpd
		rm -f /etc/vsftpd.conf
		rm -f /etc/vsftpd.chroot_list
		rm -f /etc/vsftpd.user_list
		rm -rf /etc/pam.d/vsftpd
	fi
	echo "vsftpd                    remove ok!"

	rm -rf /alidata/account.log
	rm -rf /alidata/website-info.log
	if [ "$1" != "in" ];then
		bash
	fi




代码有点多，不过一次部署，到处执行，哈哈哈






























