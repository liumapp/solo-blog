title: Gitlab更换管理员账号
date: '2017-09-20 09:25:31'
updated: '2017-09-20 09:26:58'
tags: [Java, GitLab]
permalink: /articles/2017/09/20/1505869072729.html
---
> 因为人事变动种种原因，公司的Gitlab管理员发生了变更，那么管理员的账号如何变呢？

登录Gitlab服务器命令行，输入：

	gitlab-rails console production
	
敲完这行需要等相当一会儿。加载完成后我们继续：

现在假设已经知道管理员的账号是A@gt.com，而新任管理员的账号是B@gt.com，那么我现在要做的事情就是把A的管理员权限分给B。

好，首先我们看看A的账号是什么一个情况：

	user = User.find_by(email: 'A@gt.com')
	
不出意外，应该能获得下面的结果：

User id: 2, email: "A@gt.com", created_at: "2017-08-01 08:39:48", updated_at: "2017-09-15 07:51:03", name: "A", admin: true, projects_limit: 100000, skype: "", linkedin: "", twitter: "", authentication_token: "9jGGbRiQstD9w86mx8fy", bio: "", username: "A", can_create_group: true, can_create_team: false, state: "active", color_scheme_id: 5, password_expires_at: nil, created_by_id: 1, last_credential_check_at: nil, avatar: "user2-160x160.jpg", hide_no_ssh_key: true, website_url: "", notification_email: "A@gt.com", hide_no_password: false, password_automatically_set: false, location: "", encrypted_otp_secret: nil, encrypted_otp_secret_iv: nil, encrypted_otp_secret_salt: nil, otp_required_for_login: false, otp_backup_codes: nil, public_email: "", dashboard: 2, project_view: 1, consumed_timestep: nil, layout: 0, hide_project_limit: false, otp_grace_period_started_at: nil, external: false, incoming_email_token: "c6tdd0o2vjtvozmsxsokyevd3", organization: "", require_two_factor_authentication_from_group: false, two_factor_grace_period: 48, ghost: nil, last_activity_on: "2017-09-15", notified_of_own_activity: false, preferred_language: "zh_CN", rss_token: "w8sNQVnbbs7nmzsJMH17", external_email: false, email_provider: nil
	
仔细一看，不难发现有一个admin: true这个东西，现在再来看看B的账号：

	2.3.0 :002 > user = User.find_by(email: 'B@gt.com')
	
得到的结果

User id: 4, email: "B@gt.com", created_at: "2017-08-01 09:32:14", updated_at: "2017-09-11 10:05:26", name: "B", admin: false, projects_limit: 100000, skype: "", linkedin: "", twitter: "", authentication_token: "EbjnW994JEnHeM_zt66N", bio: nil, username: "liumapp", can_create_group: true, can_create_team: false, state: "active", color_scheme_id: 1, password_expires_at: nil, created_by_id: 1, last_credential_check_at: nil, avatar: nil, hide_no_ssh_key: false, website_url: "", notification_email: "B@gt.com", hide_no_password: false, password_automatically_set: false, location: nil, encrypted_otp_secret: nil, encrypted_otp_secret_iv: nil, encrypted_otp_secret_salt: nil, otp_required_for_login: false, otp_backup_codes: nil, public_email: "", dashboard: 0, project_view: 2, consumed_timestep: nil, layout: 0, hide_project_limit: false, otp_grace_period_started_at: nil, external: false, incoming_email_token: "5ihdkwe1mwfp5etf4aw9wqoyh", organization: nil, require_two_factor_authentication_from_group: false, two_factor_grace_period: 48, ghost: nil, last_activity_on: "2017-09-19", notified_of_own_activity: false, preferred_language: "en", rss_token: "4oxyaVZN4sz1whQ2nao4", external_email: false, email_provider: nil
 
然后B的admin属性的值为false，所以我们要让B替换A作管理员，只需要把A的admin改为false，把B的admin改为true即可。

具体操作：

首先我们把A的admin属性设置为false：

依次输入以下命令：

	user = User.find_by(email: 'A@gt.com')

	user.admin=false

	user.save!
	
然后我们再把B的admin属性设置为true：

依次输入以下命令：

	user = User.find_by(email: 'B@gt.com')

	user.admin=true

	user.save!
	
好，做到这里就结束了，退出操作命令行的话按crtl＋c是没有用的，要输入exit。