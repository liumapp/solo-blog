title: Eureka注册服务列表显示IP
date: '2018-03-09 09:30:02'
updated: '2018-03-09 09:30:02'
tags: [SpringCloud, Java]
permalink: /articles/2018/03/09/1520558595253.html
---
> Eureka注册中心的首页有一栏专门显示当前已注册的服务，但是一般是以主机名+端口号的形式，尤其当我们部署到线上的时候。

## 前言

一般而言，我们是比较希望已注册服务以Ip+端口的形式显示，配置的过程也比较简单，但是笔者在具体实践到阿里云ECS的时候，发现该显示Ip的地方，依然是一个主机名。

经过研究，发现配置是正确的，阿里云ECS（CentOS7）不生效的原因在与主机的Hosts文件。

因为注册在ECS上的服务，注册到Eureka之后，他们默认是通过ECS的内网IP进行通讯，然而内网的IP又会默认的在主机的/etc/hosts文件里面被配置上一个唯一的主机名称。

所以我们只需要在/etc/hosts文件里，把内网IP对应的主机名那一行注释掉，就可以了。

## 配置

在Eureka做如下配置:

	spring.application.name=eureka
	server.port=1234
	spring.cloud.client.ipAddress=10.10.10.10
	eureka.instance.prefer-ip-address=true
	eureka.instance.instance-id=${spring.cloud.client.ipAddress}:${spring.application.name}:${server.port}
	eureka.client.serviceUrl.defaultZone=http://10.10.10.10:1234/eureka/
	
然后其余的client，加上以下配置:

	spring.cloud.client.ipAddress=${your-server-ip}
	eureka.client.serviceUrl.defaultZone=http://10.10.10.10:1234/eureka/