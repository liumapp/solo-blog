title: Mac下部署一个简单的SpringBoot项目到Docker中
date: '2018-01-18 09:35:43'
updated: '2018-01-19 09:58:44'
tags: [Java, Docker]
permalink: /articles/2018/01/18/1516236390045.html
---
> SpringCloud + Docker 的便利和强大真的超乎想象，我已经入坑了...好了，不说废话，记录一个简单的 Demo 供其他同学排坑。

## 前言

惯例不能丢，先上源代码：[docker-demo](https://github.com/liumapp/docker-demo)

这个项目的代码是我执行在Docker上部署SpringBoot的java代码和Dockerfile配置文件，相关的执行命令语句也记录在上。

## 操作流程

### 本地部署

1. 在 Mac 上安装启动 Docker。详细步骤请参考：[MacOS安装Docker](http://www.liumapp.com/articles/2017/12/27/1514347974172.html)

2. clone 项目：[docker-demo](https://github.com/liumapp/docker-demo)，然后依次执行：

		docker build -t docker-demo ../docker-demo
		
	和
	
		docker run -d -p 8080:8080 docker-demo
		

### 线上部署

以CentOS为例，线上部署的例子可能我下面没有说清楚，之后整理好例子后会及时更新的，有问题欢迎大家留言。

1. CentOS 安装 docker 容器服务

2. 把本地部署好的 docker-demo 推送镜像到 CentOS的 docker 容器服务。

3. 利用Docker的镜像服务，可以直接在本地使用docker命令来操作 CentOS 上的 docker 镜像。

## 结果图

![1.pic_hd.jpg](http://oss.fangxinqian.cn/5c5540bc771e4805b339fef1d724762c.jpg)