title: Bind服务搭建及测试
date: '2017-06-21 10:43:24'
updated: '2017-06-27 15:32:43'
tags: [Bind, DNS, Linux]
permalink: /articles/2017/06/20/1497938145148.html
---
> 前段时间做过的域名销售系统，现在公司希望不再依赖webnic方面提供的DNS解析服务，转而自主研发一台DNS server，我这里选择了Bind，写博文记录一下其相关的搭建和测试过程。

# Bind

Bind是一款开放源码的DNS服务器软件，Bind由美国加州大学Berkeley分校开发和维护的，全名为Berkeley Internet Name Domain它是目前世界上使用最为广泛的DNS服务器软件，支持各种unix平台和windows平台。

### 安装

Redhat系列：yum install bind bind-chroot（bind-chroot包含了一些安全工具）

Ubuntu系列：apt-get install bind9

Windows系列：用你妹的Windows

当然啦，Bind是开放源代码的，所以我们也可以用源码进行安装，不过很麻烦啊啊啊....

我自己的系统是CentOS，安装完之后，使用如下的命令能够看到对应结果：

	rpm -qa | grep bind

![bind.jpg](http://oss.fangxinqian.cn/fdfe8be4cbb546dbaf8fae394feb1cfd.jpg)

### 启动

启动命令分为两种，第一种应该是通用的：

	/etc/init.d/named start
	
请注意，我这里加了一个应该，因为我自己也不确定，按照我自己的经验来看，使用yum安装后的软件，在/etc/init.d下面应该会有对应的可执行文件，只是我的CentOS下面并没有named，不知道其他童鞋使用不同的Linux发行版本会不会有所不同。
	
第二种是CentOS下的：

	systemctl start named
	
同理，我使用的CentOS7，启动之后，可以看到如下进程：

	[root@iZ28vhwdq63Z /]# ps -aux | grep named

	named 30409 0.0 0.7 167268 14380 ? Ssl 09:15  0:00 /usr/sbin/named -u named

### 配置

首先，我们可以通过以下命令来查找bind安装后的配置文件在哪里：

	rpm -ql bind | more

![bindconf.jpg](http://oss.fangxinqian.cn/dde9de91c3f6495cae4f956a2172a3e5.jpg)

如图所示，/etc/named.conf就是bind的主配置文件

##### 配置项

* options {} : 整个bind使用的全局选项,监听端口，文件存储位置，缓存的存储位置，权限加密的控制等等

		options {
			listen-on port 53 { 127.0.0.1; }; //TCP/UDP监听端口及地址，这个一般不用修改
			listen-on-v6 port 53 { ::1; }; //ip6的情况下
			directory 	"/var/named";//bind数据库的文件，配置的zone的文件以及主配置文件的目录
			dump-file 	"/var/named/data/cache_dump.db";//DNS解析过的内容缓存的位置
			statistics-file "/var/named/data/named_stats.txt";//静态解析文件
			memstatistics-file "/var/named/data/named_mem_stats.txt";//内存统计信息
			allow-query     { localhost; };//权限控制

			/* 
			 * author:liumapp
			 * homePage:http://www.liumapp.com
			 *
			 *  下面都是DNS加密的选项
			*/
			recursion yes;

			dnssec-enable yes;
			dnssec-validation yes;

			/* Path to ISC DLV key */
			bindkeys-file "/etc/named.iscdlv.key";

			managed-keys-directory "/var/named/dynamic";

			pid-file "/run/named/named.pid";
			session-keyfile "/run/named/session.key";
		};

* logging {} : 服务日志选项，日志输出文件的位置，级别等

		logging {
			channel default_debug {
					file "data/named.run"; //输出文件位置
					severity dynamic; //级别
			};
		};

* zone . {} : 最重要的一个，DNS域解析

		zone "." IN { //.表示根域
			type hint;//这个type有很多种类型，当其为master，表示其为主DNS。
			file "named.ca"; // named.ca是一台根域服务器
		};

##### 注意事项

* 语法书写，非常严格。每一行必须以;结尾
* @是DNS记录中的保留字，表示当前域名
* 记录不准折行书写
* 单行记录开头不准有空格或者tab开头
* Bind所有的配置文件，都需要赋予named用户可以读取的权限

# 测试

### A记录解析

测试内容，就是看看能不能成功解析我的www.liumapp.com到对应的ip地址，请注意：我安装bind的服务器跟安装我博客的服务器不是在同一台服务器上面，所以它们两者的IP地址是不同的。

首先，我们把原来的配置文件named.conf进行备份，之后对它的内容改为如下所示：

	#
	#User: liumapp
	#Email: liumapp.com@gmail.com
	#homePage: http://www.liumapp.com
	#Date: 6/21/17
	#Time: 10:00 AM
	#

	options {
		directory "/var/named";
	};
	zone "liumapp.com" {
		type master;
		file "liumapp.com.zone";
	};
	
然后，我们在/var/named目录下，新建一个liumapp.com.zone文件，其内容如下：

	#
	#User: liumapp
	#Email: liumapp.com@gmail.com
	#homePage: http://www.liumapp.com
	#Date: 6/21/17
	#Time: 10:11 AM
	#

	#time to live的缩写,该字段指定IP包被路由器丢弃之前允许通过的最大网段数量
	$TTL 7200

	#这里面有一个邮箱，liumapp.com@gmail.com，但是@符号在bind配置文件有自己的特殊含义，所以我们使用.来代替
	#最后的222 1H 15M 1W 1D跟DNS主从有关
	#配置liumapp.com和管理员的邮箱
	liumapp.com. IN SOA liumapp.com. liumapp.com.gmail.com (222 1H 15M 1W 1D)

	#配置bind，liumapp.com这个域由哪一台DNS server 进行解析
	liumapp.com. IN NS dns1.liumapp.com.

	# 对解析liumapp.com的DNS server做一个A纪录
	# 这里，我直接把安装了bind的服务器的IP地址写了上去
	# 这个dns1.liumapp.com也可以写成dns1
	dns1.liumapp.com. IN A 115.29.32.62

	# 对www.liumapp.com做一条A纪录的解析
	# 这个www.liumapp.com也可以写成www
	www.liumapp.com. IN A 106.14.212.41
	
另外，请大家注意，上面两个文件请不要包含有注释，上面的注释是我为了方便阅读和理解写上去的，真正使用的时候要删除掉的。

之后，重启bind：

	systemctl restart named
	
好，接下来我们使用dig命令来检查一下能否成功解析www.liumapp.com

输入命令：

	dig @115.29.32.62 www.liumapp.com
	
115.29.32.62是我们DNS server的IP地址,www.liumapp.com如果成功解析的话，应该能指向到106.14.212.41这个IP地址

敲回车后，我们可以看到下面的结果：

![result.jpg](http://oss.fangxinqian.cn/4e60b83f9f824886b5ad4534dd22c231.jpg)

可以看到，解析成功了。

### CNAME记录解析

现在我们使用一个cnametest.com这个域名来做一个cname记录解析：

首先，基于上面的配置文件的基础，我们在named.conf下修改为如下代码：

	options {
		directory "/var/named";
	};

	zone "liumapp.com" {
		type master;
		file "liumapp.com.zone";
	};

	zone "cnametest.com" {
		type master;
		file "cnametest.com.zone";
	};

然后在/var/named目录下添加一个cnametest.com.zone文件，内容为：

	$TTL 7200
	cnametest.com. IN SOA cnametest.com. liumapp.com.gmail.com (4012100 1H 15M 1W 1D)
	cnametest.com. IN NS dns1.liumapp.com.
	dns1.liumapp.com. IN A 115.29.32.62
	www.cnametest.com. IN CNAME www.liumapp.com.

重启bind，使用dig命令测试后，如果成功将有如下结果出现：

![cnameresult.jpg](http://oss.fangxinqian.cn/7b88938b68ab447693f9dadcb3236577.jpg)

### 正向解析测试

正向解析其实跟我们的添加A记录解析是一样的，都是从域名到IP。

### 反向解析测试

反向解析，这边我查阅到的资料提及到的反向解析一般是应用在MX邮件服务里，所以这里以mail测试对象。

首先在/var/named/liumapp.com.zone文件中添加一段mail的解析代码：

	@ IN MX 10 mail 
	mail IN A 115.29.32.63

然后回到/etc/named.conf添加一段：

	zone "32.29.115.in-addr.arpa" {
		type master;
		file "115.29.32.zone";
	};

这里需要注意一下，我在写反向解析的zone的时候，用的IP网段是反过来写的

然后我们在/var/named/下面新建一个115.29.32.zone文件，其内容为：

	$TTL 3600
	@ IN SOA 32.29.115.in-addr.arpa. liumapp.com.gmail.com(2014012200 1H 15M 1W 1D)
	@ IN NS dns1.liumapp.com.
	62 IN PTR dns1.liumapp.com.
	63 IN PTR mail.liumapp.com.

115.29.32.62是我们的Bind服务器地址，115.29.32.63是我们的mail服务器地址。这里把它们两者写在一个网段里面。

最后我们用命令

	dig -x 115.29.32.63 @115.29.32.62
	
如果mail.liumapp.com成功解析出来，那就说明测试成功了。

![forward.jpg](http://oss.fangxinqian.cn/c2a11c73522b4e928393d71226549900.jpg)

# DNS相关知识

### 根域

我们经常看见的域名，比如www.liumapp.com，在DNS里面，它是等于www.liumapp.com.的，注意:

* 最后面有一个“.”，这个".”就表示根域
* .com 表示一级域名
* liumapp.com 表示二级域名

### 域名解析过程

##### 权威DNS解析

现在有这样的一个场景，我在一个chrome上，输入www.liumapp.com，那么浏览器将根据以下步骤去找到我这个域名对应的IP地址：

* 解析器向名字服务器（及我将要搭建的DNS server）发出“www.liumapp.com”的请求（解析器基本上每个浏览器都会有）
* 如果这台DNS server有www.liumapp.com对应的IP记录，那么它直接返回IP结果
* 如果没有，那么这台DNS server将把“www.liumapp.com”发向根域server（也是一台DNS server，全球一共13台根域server）进行查询
* 根域server返回一级域名.com解析服务器的IP地址
* 我自己的DNS server再将www.liumapp.com发往.com解析服务器进行查询
* .com解析服务器返回liumapp.com域名服务器的IP地址
* 我自己的DNS server再将www.liumapp.com发往liumapp.com域名服务器
* liumapp.com域名服务器就将会返回我这个域名对应的：权威解析IP地址，这个时候，我们也把这台liumapp.com域名服务器称之为具有对liumapp.com的权威解析server
* 我自己的DNS server将权威解析回来的IP地址进行缓存，再返回给用户

### DNS解析记录的分类

在阿里云买过域名的童鞋应该能发现，在进行域名解析的时候，会有一个下拉框，里面有：A记录、CNAME记录、MX记录等等，我们的DNS解析记录就按这几个进行分类的。

##### A记录

根据域名，返回ip地址，就称之为A记录

##### CNAME记录

CNAME记录怎么解释我自己也不好说，干脆拿一个实际应用来分析吧：
比如，我现在的www.liumapp.com以及是一个A记录了，它已经对应到了一台固定IP的服务器上了，当然啦，用户访问它的时候，就是访问我的博客。
现在我可能要再弄一个专门放我小电影的网站，可我又不想别人知道，所以我再整一个新的子域名：heiheihei.liumapp.com，然后我在解析的时候呢，把heiheihei.liumapp.com解析到www.liumapp.com，这个时候，我们就把heiheihei.liumapp.com称之为CNAME记录，虽然它们两个域名最终是解析到同一个服务器上，但是服务器的tomcat或者nginx能够判断出来访域名的不同而做出不同的行为，www.liumapp.com来访的时候，我的nginx就打开我的博客给你，heiheihei.liumapp.com来访的时候，我的nginx就把小电影项目返回。（在浏览器敲了heiheihei.liumapp.com的童鞋请自行面壁）

就我个人的项目实战经验来看，CNAME应用的场景是很多的，包括阿里云的OSS、阿里云的CDN加速等等，这些东西具体怎么应用我之后再写新的博文进行分析。

##### NS 

NS记录呢，可能阿里云的域名解析并没有，因为它是在DNS server找不到对应IP的时候，返回另外一个DNS server的ip地址，这个地址呢我们就称之为NS。

##### MX 

针对邮件服务进行的解析，比如腾讯企业邮箱...

### 正向解析与反向解析

##### 正向解析

通过域名查找IP，返回的是一个A记录

##### 反向解析

通过IP查找对应域名，返回的是PTR记录，一般在邮件系统里面用到







