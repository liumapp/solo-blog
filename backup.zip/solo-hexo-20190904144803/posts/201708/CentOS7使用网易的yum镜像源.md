title: CentOS7使用网易的yum镜像源
date: '2017-08-01 09:43:45'
updated: '2017-08-01 09:43:45'
tags: [Linux, CentOS]
permalink: /articles/2017/08/01/1501551825701.html
---
> 最近用yum下载gitlab，实在无法忍受默认源的下载速度，便换了网易的，这里记录一下更换的方法。

首先进入操作目录：

	cd /etc/yum.repos.d

然后我们要备份现有的源文件：

	mv CentOS-Base.repo CentOS-Base.repo.default
	
下载网易源：

	wget -o CentOS-Base.repo http://mirrors.163.com/.help/CentOS7-Base-163.repo
	
写入：

	cp -rp CentOS7-Base-163.repo CentOS-Base.repo
	
赋予权限:

	chmod -R 777 CentOS-Base.repo
	
清理yum：

	yum clean all

	yum makecache

结束。


