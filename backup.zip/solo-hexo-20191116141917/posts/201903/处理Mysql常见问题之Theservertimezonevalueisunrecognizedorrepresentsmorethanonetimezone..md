title: 处理Mysql常见问题之：" The server time zone value '???ú±ê×??±??' is unrecognized or
  represents more than one time zone."
date: '2019-03-20 14:15:40'
updated: '2019-03-20 14:18:54'
tags: [Mysql]
permalink: /articles/2019/03/20/1553062540312.html
---
> 还是同样使用mybatis-generator-plugin插件过程中遇到的问题，不过这个比较简单，配置一下时区即可

更新mysql连接的url，将时区信息带上去，我们北京是东8时区，所以是GMT+8

具体代码如下：

`jdbc:mysql://localhost:3306/solo?serverTimezone=GMT%2B8`

也顺便记录一下我常用的mysql连接配置：

`jdbc:mysql://localhost:3306/solo?serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=utf8&useSSL=false`