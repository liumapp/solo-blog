title: No thread-bound request found
date: '2017-07-25 09:14:55'
updated: '2017-07-25 09:14:55'
tags: [Java, Spring]
permalink: /articles/2017/07/25/1500945068899.html
---
> 在Spring框架下使用filter引起的一个错误

在web.xml配置文件中有如下代码：

    <filter>
        <filter-name>LoginRequireFilter</filter-name>
        <filter-class>com.liumapp.DNSBee.filter.LoginRequireFilter</filter-class>
        <init-param>
            <param-name>noCheckPath</param-name>
            <param-value>login;register;nav</param-value>
        </init-param>
    </filter>
    <filter-mapping>
        <filter-name>LoginRequireFilter</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>
	
很简单的登录过滤器，但是在运行时报出

HTTP Status 500 - No thread-bound request found: Are you referring to request attributes outside of an actual web request, or processing a request outside of the originally receiving thread? If you are actually operating within a web request and still receive this message, your code is probably running outside of DispatcherServlet/DispatcherPortlet: In this case, use RequestContextListener or RequestContextFilter to expose the current request.

的错误。

解决办法：

在上面的filter之前加入一段：

	<listener>
        <listener-class>org.springframework.web.context.request.RequestContextListener</listener-class>
    </listener>