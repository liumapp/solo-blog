title: whmcs系统添加网银支付接口
date: '2017-04-26 15:44:36'
updated: '2017-04-26 15:45:48'
tags: [whmcs, 网银]
permalink: /articles/2017/04/26/1493190767340.html
---
### whmcs系统添加网银支付接口

> 其实利用whmcs系统的文档，按照规范编写网银支付接口是很简单的，但是问题在于，我要如何去使用现成的代码来完成这个接口呢。这里我们使用[payment](https://github.com/liumapp/payment.git)项目（笔者针对支付功能进行封装的一个library）来在whmcs系统上实现这个支付接口。

具体代码已经部署在github上，具体链接为[whmcs-union](https://github.com/liumapp/whmcs-union.git)

那么我们直接把重点放在whmcs系统中对外部项目的引用。

### 不能直接使用composer

笔者的whmcs系统版本为7.x，下载的源文件中并没有composer.json，所以在whmcs根目录下，冒然执行composer init然后require项目，将会覆盖掉vendor目录下原有的composer文件，导致whmcs系统无法正常定位到其本身依赖的库文件。

#### 解决办法

在根目录下新建一个目录，名为vendor2，再在vendor2中执行composer init ，再require你需要引入的项目即可，但是要注意一点，不能直接requireone './vendor2/vendor/autoload.php'文件，因为系统将会直接报错，换句话说，可以使用composer下载依赖，但是定位依赖的spl_autoload_register需要自己写。

### spl_autoload_register示范

仅供参考，毕竟每一个不通的依赖，spl_autoload_register都是有可能不一样的，所以我们在具体调用的位置再去编写。

	/**
	 * Created by PhpStorm. * User: liumapp * Email: liumapp.com@gmail.com
	  * homePage: http://www.liumapp.com
	  * Date: 4/25/17
	 * Time: 10:49 AM */
	function union_config() {
	  $configarray = array(
	  "FriendlyName" => array("Type" => "System", "Value"=>"银联网关支付"),
	  "unionCertDir" => array("FriendlyName" => "银联证书存储目录", "Type" => "text", "Size" => "50" ),
	  "unionEncryptCertPath" => array("FriendlyName" => "银联公钥", "Type" => "text", "Size" => "50" ),
	  "unionMerId" => array("FriendlyName" => "银联商户号", "Type" => "text", "size" => "50"),
	  "unionSignCertPath" => array("FriendlyName" => "银联商户私钥", "Type" => "text", "Size" => "50" ),
	  "unionSignCertPwd" => array("FriendlyName" => "银联商户私钥密码", "Type" => "text", "Size" => "50" ),
	  );
	  return $configarray;
	}

	function classLoadPayment ($class)
	{
	  $path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
	  $path = str_replace('liumapp' . DIRECTORY_SEPARATOR, '', $path);
	  $path = str_replace('payment' . DIRECTORY_SEPARATOR , '' , $path);
	  $file = '/alidata/www/default/whmcs/vendor2/vendor/liumapp/payment/src/' . $path . '.php';
	  if (file_exists($file)) {
	  require_once $file;
	  }
	}

	function union_link($params) {

	 spl_autoload_register('classLoadPayment');
	  $systemurl = $params['systemurl'];
	  $data = [
	  'config' => [
	  'merId' => $params['unionMerId'],
	  'sdk_sign_cert_path' => $params['unionSignCertPath'],
	  'sdk_sign_cert_pwd' => $params['unionSignCertPwd'],
	  'sdk_encrypt_cert_path' => $params['unionEncryptCertPath'],
	  'sdk_verify_cert_dir' => $params['unionCertDir'],
	  'frontUrl' => $systemurl."/modules/gateways/callback/union_return.php",
	  'backUrl' => $systemurl."/modules/gateways/callback/union_callback.php",
	  ],
	  'data' => [
	  'orderId' => time(),
	  'txnTime' => date('YmdHmi' , time()),
	  'txnAmt' => 1,
	  ],
	  ];
	  return \liumapp\payment\client\Charge::run('uni_con' , $data['config'] , $data['data']);
	}