title: PHP mkdir permission denied
date: '2017-03-01 17:00:25'
updated: '2017-03-22 17:06:45'
tags: [Windows, Linux, PHP]
permalink: /articles/2017/03/01/1488358552108.html
---

<code>$name = '/uploads/' . date('Y') . '/' . date('m') . '/' . date('d') . '/' . uniqid() . '/';</code><br>
<code>mkdir($name , 0777 , true);</code>

php中使用上述代码在创建多级目录的时候，在windows能够正常运行，但部署到Linux/Unix下面就会报Perssion Denied，这是为什么呢？

> 这是因为在Linux系统中创建文件／文件夹会受到umask的影响，当umask设置为022时，实际PHP创建的0777目录权限就会变成0755。

解决办法也很简单：

<code>$dir = '/uploads/' . date('Y') . '/';</code><br>
<code>        if (!file_exists($dir)) {</code><br>
<code>            mkdir($dir , 0777 , true);</code><br>
<code>            chmod($dir , 0777);</code><br>
<code>        }</code><br>
<code>        $dir = $dir . date('m') . '/';</code><br>
<code>        if (!file_exists($dir)) {</code><br>
<code>            mkdir($dir , 0777 , true);</code><br>
<code>            chmod($dir , 0777);</code><br>
<code>        }</code><br>
<code>        $dir = $dir . date('d') . '/';</code><br>
<code>        if (!file_exists($dir)) {</code><br>
<code>            mkdir($dir , 0777 , true);</code><br>
<code>            chmod($dir , 0777);</code><br>
<code>        }</code><br>
<code>        $dir = $dir . uniqid() . '/';</code><br>
<code>        if (!file_exists($dir)) {</code><br>
<code>            mkdir($dir , 0777 , true);</code><br>
<code>            chmod($dir , 0777);</code><br>
<code>        }</code><br>

