title: Github未记录contributions
date: '2017-05-12 11:23:41'
updated: '2017-06-07 14:28:05'
tags: [Github]
permalink: /articles/2017/05/12/1494559178478.html
---
### Github未记录contributions

> 这段时间提交到git上面的commit，突然发现没有被记录到contributions里面，导致那个面板看起来“很不友善”，经过短暂的研究（half hour），贡献出解决方案。

#### 何为contributions

如图

![1.pic.jpg](http://oss.fangxinqian.cn/0550bde9cb844032a0b99b44ebea9b7b.jpg)

如果有提交的话，那么当天就会是一个绿色的格子，由提交的数量决定颜色的深浅。

#### 未被记录的原因

看了看github的文档，发现有三种情况不会被记录：
1.  用户名或者邮箱跟github没有关联上， github认为不是你提交的， 不统计。
2.  fork 的项目， 不统计
3.  没有在版本库的master【默认分支】上提交

这里我检查了一下自己的项目，发现果然是因为账号没有关联上的原因。

![2.pic.jpg](http://oss.fangxinqian.cn/0ad450f3bb264808a04dd533194e08aa.jpg)

可以看到，我使用的其他账号去上传所以才没有被记录。

#### 解决方案

	git config --global user.email "你的邮件地址"
	git config --global user.name "你的Github用户名"

#### 其他情况

假如自己先前一直提交代码的项目，后来不想再看到它，把它删掉了，那么与之相对应的提交统计也会被删除（也就是说之前的一些统计格子也是能够发生变化的）