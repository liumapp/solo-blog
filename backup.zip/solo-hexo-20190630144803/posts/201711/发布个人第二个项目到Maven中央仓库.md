title: 发布个人第二个项目到Maven中央仓库
date: '2017-11-15 10:52:02'
updated: '2017-11-15 10:52:02'
tags: [Maven, Java]
permalink: /articles/2017/11/15/1510713422953.html
---
> 之前发布DNSQueen的时候，写过两篇博文记录了项目发布的流程，今天去发布第二个新项目的时候，发现，操作流程跟我之前记录的稍微不一样，为了避免误导别人，所以写下这篇文章。

## 前言

当看官是第一次发布项目到Maven中央仓库的时候，的确可以参照我之前写的两篇博文：[发布Maven项目到中央仓库](http://www.liumapp.com/articles/2017/07/17/1500257349266.html)和[gpg的安装使用](http://www.liumapp.com/articles/2017/07/20/1500521485758.html)来操作。

但如果是第二次发布的话，那么操作流程稍微有一些不一样。

这篇博文仅仅记录了不一样的地方，而不会完整的记录所有操作步骤。

## 正事

### 不需要发issue

首先我们不需要去[issues.sonatype.org](https://issues.sonatype.org)这个站点创建issue。

我第二次傻傻的创建issue直接被管理员鄙视了...

上图:

![1.pic_hd.jpg](http://oss.fangxinqian.cn/2cdbf896727e408e8453e507427ea733.jpg)

翻译过来就是，你已经拿到com.liumapp及其所有二级域名的项目上传许可，所以不需要再来申请了，你个二货。

当然，如果看官的第二个项目跟自己之前上传的项目不是同一个groupId（不是用的同一个域名），那么还是要重新创建一遍issue的。

### 不需要Release

再其次，在使用gpg上传项目到私服的时候，上传成功后不需要我们再去执行close、release的操作，直接就上传成功了。

上图：

![2.pic_hd.jpg](http://oss.fangxinqian.cn/1c7c7a75f0d74d099364ca3db7191f75.jpg)

本人这次上传的项目为

	<dependency>
		<groupId>com.liumapp.redis</groupId>
		<artifactId>redis-operator</artifactId>
		<version>v1.0.0</version>
	</dependency>
	
在本地直接执行：

	mvn deploy -Dmaven.test.skip=true  -e
	
后遍上传成功，甚是方便。
