title: Git后悔系列——gitignore忽略指定目录，但不忽略该目录下的指定文件
date: '2017-05-05 10:07:26'
updated: '2017-05-05 10:07:26'
tags: [whmcs, Github]
permalink: /articles/2017/05/05/1493950046424.html
---
### Git后悔系列——gitignore忽略指定目录，但不忽略该目录下的指定文件

> 手头上正在处理whmcs闭源系统，因为是闭源，所以不能把所有的代码都加到Git库里，但是我写的代码肯定要加到Git库，因为怕哪天whmcs系统一个自动更新，把系统认为很奇怪的文件都删掉就麻烦了。
所以在编写.gitignore上，除了要把相当一部分被加密的whmcs源码写入忽略规则之外，我们还需要指定自己编写的文件不要被忽略。

#### 案例

我们以whmcs系统的modules目录为例，该modules目录下的内容如图所示：

![1.pic.jpg](http://oss.fangxinqian.cn/655feab5ffe1486fb1c0709e1b5ac3c2.jpg)

现在接入了支付宝的gateway接口，所以我们引入了相关文件，如图

![2.pic.jpg](http://oss.fangxinqian.cn/f12c60b2bfe748709c54bbe5b21e922a.jpg)

画红框的表示额外引入的文件，那么现在我需要编写gitignore，既要忽视modules下的所有文件，又要不忽视接入的支付宝支付的相关文件。

#### 代码

	/modules/*

	!/modules/gateways

	/modules/gateways/*

	!/modules/gateways/callback

	/modules/gateways/callback/*

	!/modules/gateways/alipay.php

	!/moduels/gateways/callback/alipay.*

	!/modules/gateways/callback/alipay*

	!/modules/gateways/callback/cacert.pem
	
