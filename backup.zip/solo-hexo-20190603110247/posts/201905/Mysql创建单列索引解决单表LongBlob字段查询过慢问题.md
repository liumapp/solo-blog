title: Mysql创建单列索引解决单表LongBlob字段查询过慢问题
date: '2019-05-21 17:07:45'
updated: '2019-05-21 19:52:40'
tags: [Mysql]
permalink: /articles/2019/05/21/1558429665771.html
---
> Mysql中，只要表中存在longblob或者longtext类型的字段，并且数据量一多，那么对这张的查询操作将会变得非常缓慢，但使用单列索引就可以解决此类问题

## 问题重现

现在mysql中有一张表，假设名为 imgs ，一共三个字段，id, mid, fileData，其中id为主键，mid为关联表id，fileData为一个longBlob类型的字段

现在我们用脚本或者代码随机往imgs表中插入10w条左右的数据，再运行由mybatis生成的查询sql：

````sql
select 'true' as QUERYID, id, mid, fileData from imgs WHERE ( mid = 1257 )
````
那么不出意外，运行这段sql所需要的时间将会是非常高昂的成本（在我本地测试用了足足5秒）

对应到线上环境，5秒的查询时间是不可能被允许的，必须优化

## 创建单列索引

我们可以分析，如此缓慢的查询，其本质原因就是因为longBlob字段造成的开销影响的，如果可以在查询之初就迅速定位一个较小的范围，那么就可以解决这个问题

而索引恰恰就能够完美的解决： 如果我们对mid创建索引index，那么mysql能够通过where mid = 1257迅速把搜索范围定位到mid = 1257的范围内，然后再去根据其他搜索条件去查找

运行以下sql创建索引：

````sql
alter table imgs add index mid(mid);
````

之后再运行同样的查询语句： 

````sql
select 'true' as QUERYID, id, mid, fileData from imgs WHERE ( mid = 1257 )
````

就可以解决问题，至少在我本地，由原本的5秒查询时间，缩短到了0.02秒