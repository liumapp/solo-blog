title: Maven设置阿里云中央仓库
date: '2017-10-22 12:45:20'
updated: '2017-10-22 12:45:20'
tags: [Maven]
permalink: /articles/2017/10/22/1508647241163.html
---
> 周日在家办公，发现Maven下载依赖速度无法忍受，细查，居然忘记设置了Maven的国内镜像仓库。

闲话不多说，先上相关环境：

* Maven安装地址为/usr/local/maven3.3.9

* 操作系统 Mac OS

操作步骤:

* cd /usr/local/maven3.3.9/conf

* vim settings.xml

* 在第150行的样子，我们可以找到mirros标签，在其内部添加以下代码：

	```
	 <mirror>
		<id>alimaven</id>
		<mirrorOf>central</mirrorOf>
		<name>aliyun maven</name>
		<url>http://maven.aliyun.com/nexus/content/repositories/central/</url>
	 </mirror>

	```

* vim下使用set number命令可以显示行数

* 保存后将立即生效


