title: B3log 后台拿不到社区推荐、发布的文章也无法同步到社区
date: '2017-07-12 10:41:39'
updated: '2017-07-12 15:52:37'
tags: [Java, Solo]
permalink: /articles/2017/07/12/1499827297261.html
---
后台首页拿不到社区推荐的文件，看了下network，发现
https://hacpai.com/apis/articles?p=1&size=7&tags=Java,Maven,css,javascript+nodeJs+bower+gulp+less,GloboDNS,Github,ddd,%E6%BB%B4%E6%BB%B4,javascript,url,%E6%8D%A2%E8%82%A4,PHP+Linux+Windows,whmcs,Linux,IDEA,PHP,aja,CentOS,tag,css3&callback=jQuery17205134093271555178_1499826529924&_=1499826530496
这一段请求报404错误

![51af010b04c54dcdae2ea960a827faf8-image.png](https://img.hacpai.com/file/2017/7/51af010b04c54dcdae2ea960a827faf8-image.png) 

自己发布的文章也没有同步到社区，难怪你们最近没有看到我写的文章啊有木有？？？

以下是相关日志的内容，同时声明一下：我没有改solo的任何代码，在正常运行相当长的时间下突然出现这个问题的。

## 再来一段新鲜的solo错误日志：

	[ERROR]-[2017-07-12 09:44:42]-[org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer:137]: FreeMarker renders error

	FreeMarker template error:

	The following has evaluated to null or missing:

	==> title [in template "error/404.ftl" at line 4, column 7]

	----

	Tip: If the failing expression is known to be legally refer to something that's sometimes null or missing, either specify a default value like myOptionalVar!myDefault, or use <#if myOptionalVar??>when-present<#else>when-missing. (These only cover the last step of the expression; to cover the whole expression, use parenthesis: (myOptionalVar.foo)!myDefault, (myOptionalVar.foo)??

	----

	----

	FTL stack trace ("~" means nesting-related):

	 - Failed at: ${title} [in template "error/404.ftl" at line 4, column 5]

	 ~ Reached through: #nested [in template "macro-common-page.ftl" in macro "commonPage" at line 21, column 13]

	 ~ Reached through: @commonPage "404 Not Found!" [in template "error/404.ftl" at line 3, column 1]

	----

	Java stack trace (for programmers):

	----

	freemarker.core.InvalidReferenceException: [... Exception message was already printed; see it above ...]

	 at freemarker.core.InvalidReferenceException.getInstance(InvalidReferenceException.java:131)

	 at freemarker.core.EvalUtil.coerceModelToString(EvalUtil.java:355)

	 at freemarker.core.Expression.evalAndCoerceToString(Expression.java:82)

	 at freemarker.core.DollarVariable.accept(DollarVariable.java:41)

	 at freemarker.core.Environment.visit(Environment.java:324)

	 at freemarker.core.MixedContent.accept(MixedContent.java:54)

	 at freemarker.core.Environment.visit(Environment.java:324)

	 at freemarker.core.Environment.invokeNestedContent(Environment.java:546)

	 at freemarker.core.BodyInstruction.accept(BodyInstruction.java:56)

	 at freemarker.core.Environment.visit(Environment.java:324)

	 at freemarker.core.MixedContent.accept(MixedContent.java:54)

	 at freemarker.core.Environment.visit(Environment.java:324)

	 at freemarker.core.Macro$Context.runMacro(Macro.java:184)

	 at freemarker.core.Environment.invoke(Environment.java:701)

	 at freemarker.core.UnifiedCall.accept(UnifiedCall.java:84)

	 at freemarker.core.Environment.visit(Environment.java:324)

	 at freemarker.core.MixedContent.accept(MixedContent.java:54)

	 at freemarker.core.Environment.visit(Environment.java:324)
	 at freemarker.template.Template.process(Template.java:325)

	 at org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer.genHTML(AbstractFreeMarkerRenderer.java:161)

	 at org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer.render(AbstractFreeMarkerRenderer.java:132)

	 at org.b3log.latke.servlet.DispatcherServlet.result(DispatcherServlet.java:111)

	 at org.b3log.latke.servlet.DispatcherServlet.service(DispatcherServlet.java:89)

	 at javax.servlet.http.HttpServlet.service(HttpServlet.java:731)

	 at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:303)

	 at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:208)

	 at org.apache.catalina.core.ApplicationDispatcher.invoke(ApplicationDispatcher.java:743)

	 at org.apache.catalina.core.ApplicationDispatcher.processRequest(ApplicationDispatcher.java:487)

	 at org.apache.catalina.core.ApplicationDispatcher.doForward(ApplicationDispatcher.java:410)

	 at org.apache.catalina.core.ApplicationDispatcher.forward(ApplicationDispatcher.java:337)

	 at org.apache.catalina.core.StandardHostValve.custom(StandardHostValve.java:479)

	 at org.apache.catalina.core.StandardHostValve.status(StandardHostValve.java:341)

	 at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:206)

	 at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:103)

	 at org.apache.catalina.valves.AccessLogValve.invoke(AccessLogValve.java:962)

	 at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:116)

	 at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:445)

	 at org.apache.coyote.http11.AbstractHttp11Processor.process(AbstractHttp11Processor.java:1115)

	 at org.apache.coyote.AbstractProtocol$AbstractConnectionHandler.process(AbstractProtocol.java:637)

	 at org.apache.tomcat.util.net.JIoEndpoint$SocketProcessor.run(JIoEndpoint.java:318)

	 at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)

	 at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)

	 at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:61)

	 at java.lang.Thread.run(Thread.java:748)
	 
	 
## 再来一段新鲜的localhost_access_log.2017-07-12.txt

	106.14.212.41 - - [12/Jul/2017:10:37:49 +0800] "GET /./solo/console/stat/onlineVisitorRefresh HTTP/1.1" 500 -

	183.247.162.210 - - [12/Jul/2017:10:37:53 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827074777 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:37:59 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827081294 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:03 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827084596 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:09 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827091296 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:13 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827094597 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:19 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827101295 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:23 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827104661 HTTP/1.1" 200 47

	183.247.162.210 - - [12/Jul/2017:10:38:29 +0800] "GET /console/plugins/b3log-broadcast/chance?_=1499827111294 HTTP/1.1" 200 47
	
	
## 再来一段新鲜的catalina.2017-07-12.log日志：

	Jul 12, 2017 10:22:22 AM org.apache.coyote.http11.AbstractHttp11Processor process

	INFO: Error parsing HTTP request header

	 Note: further occurrences of HTTP header parsing errors will be logged at DEBUG level.

	java.lang.IllegalArgumentException: Invalid character found in method name. HTTP method names must be tokens

	 at org.apache.coyote.http11.InternalInputBuffer.parseRequestLine(InternalInputBuffer.java:136)

	 at org.apache.coyote.http11.AbstractHttp11Processor.process(AbstractHttp11Processor.java:1028)

	 at org.apache.coyote.AbstractProtocol$AbstractConnectionHandler.process(AbstractProtocol.java:637)

	 at org.apache.tomcat.util.net.JIoEndpoint$SocketProcessor.run(JIoEndpoint.java:316)

	 at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)

	 at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)

	 at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:61)

	 at java.lang.Thread.run(Thread.java:748)

	Jul 12, 2017 10:22:22 AM org.apache.coyote.http11.AbstractHttp11Processor process

	INFO: Error parsing HTTP request header

	 Note: further occurrences of HTTP header parsing errors will be logged at DEBUG level.

	java.lang.IllegalArgumentException: Invalid character found in method name. HTTP method names must be tokens

	 at org.apache.coyote.http11.InternalInputBuffer.parseRequestLine(InternalInputBuffer.java:136)

	 at org.apache.coyote.http11.AbstractHttp11Processor.process(AbstractHttp11Processor.java:1028)

	 at org.apache.coyote.AbstractProtocol$AbstractConnectionHandler.process(AbstractProtocol.java:637)

	 at org.apache.tomcat.util.net.JIoEndpoint$SocketProcessor.run(JIoEndpoint.java:316)

	 at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)

	 at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)

	 at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:61)

	 at java.lang.Thread.run(Thread.java:748)

	~