title: SpringBoot仿微服务CoreArchetype
date: '2017-12-20 11:30:21'
updated: '2017-12-20 11:30:21'
tags: [Java]
permalink: /articles/2017/12/19/1513666850042.html
---
> SpringBoot独立模块部署方案的初始代码，以封装为Archetype方便各位调用。

## 前言

先上CoreArchetype的源代码：

[spring-boot-core-module](https://github.com/liumapp/spring-boot-core-module)


## 安装

获取源代码后，进行项目目录依次执行

*   mvn archetype:create-from-project

*   cd target/generated-sources/archetype

*   mvn install

## 使用

在您希望生成项目的位置输入命令：

	mvn archetype:generate
	
在出来的列表中选择spring-boot-core-module对应的序号，随后输入新项目的groupId、artifactId以及version即可。

## pom

对于pom.xml中关键的内容的解释

	<parent>
	  <groupId>org.springframework.boot</groupId>
	  <artifactId>spring-boot-starter-parent</artifactId>
	  <version>1.5.6.RELEASE</version>
	</parent>
	
因为用CoreArchetype打包生成的项目，需要具备独立运行的能力，所以我们需要加上它的parent。
	
	<packaging>jar</packaging>
	
通过Jar包来进行部署，方便用shell脚本进行管理。

	<properties>
	  <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
	  <springboot.version>1.5.6.RELEASE</springboot.version>
	  <java.version>1.8</java.version>
	</properties>
	
基本设置，没啥好说的。

	<dependencies>
	  <dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-web</artifactId>
		<version>${springboot.version}</version>
	  </dependency>
	  <dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-devtools</artifactId>
		<version>${springboot.version}</version>
		<optional>true</optional>
		<scope>runtime</scope>
	  </dependency>
	  <dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-test</artifactId>
		<version>${springboot.version}</version>
		<scope>test</scope>
	  </dependency>
	</dependencies>
	
一个独立模块，很多时候都是通过API向外开发数据的输入和输出，但是我们也要考虑前端直接使用Http协议的情况，所以最好使用spring-boot-starter-web而不是spring-boot-starter。

	<build>
	  <plugins>
		<plugin>
		  <groupId>org.springframework.boot</groupId>
		  <artifactId>spring-boot-maven-plugin</artifactId>
		  <executions>
			<execution>
			  <goals>
				<goal>repackage</goal>
			  </goals>
			</execution>
		  </executions>
		</plugin>
	  </plugins>
	</build>

直接运行必备插件。







