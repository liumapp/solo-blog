title: 'error: insufficient permission for adding an object to repository database
  .git/objects'
date: '2017-05-12 16:07:45'
updated: '2017-05-13 10:25:21'
tags: [Github]
permalink: /articles/2017/05/12/1494576464986.html
---
###  error: insufficient permission for adding an object to repository database .git/objects

> 先声明，这是笔者在开发过程中碰到的一个问题，暂时没有找出原因及对应的解决方案，先抛出来占个坑。

![6.pic.jpg](http://oss.fangxinqian.cn/8589df9f372246da9e9334d59ca70c2f.jpg)

### 问题产生原因

在对项目"dns"进行git操作的过程中，先后使用了多个账号，其中一个为root账号（操作环境是Mac OS），使用了root账号进行了git的add和commit操作后，再使用普通账号去操作时，普通账号没有对.git进行写的权限。（不过很好奇的是我最后还是写入成功了）

### 解决办法

用root账号赋予.git目录写权限即可。