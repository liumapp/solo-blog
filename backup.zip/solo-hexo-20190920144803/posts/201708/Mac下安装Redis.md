title: Mac下安装Redis
date: '2017-08-18 19:07:30'
updated: '2017-08-18 19:07:30'
tags: [Redis, Mac]
permalink: /articles/2017/08/18/1503054449983.html
---
> 在Mac环境下，我们通常使用HomeBrew来安装常用的软件，包括Redis。

### 安装

在命令行下，使用

	brew install redis
	
即可安装redis，其安装位置在/usr/local/opt/redis下，但它的配置文件在/usr/local/etc/redis.conf。

在运行Redis的时候，如果不以守护进程运行，将会占用一个shell界面。

### 开启守护进程模式

	vim /usr/local/etc/redis.conf
	
找到daemonize no 这一行，把no改为yes。

执行命令

	/usr/local/opt/redis/bin/redis-server /usr/local/etc/redis.conf
	
