title: Mac安装RabbitMQ——排坑及通用操作
date: '2018-03-21 10:49:04'
updated: '2018-03-21 10:49:04'
tags: [Mac]
permalink: /articles/2018/03/21/1521550528953.html
---
> Mac使用HomeBrew安装RabbitMQ是一件非常简单的事情，但是里面也有一些坑存在。

## 安装

最简单的办法，直接执行

	brew install rabbitmq
	
但是如果您的Mac环境跟我的一样，稍微有一点点没有跟上时代的潮流，那么便很容易出现下面的问题：

![1.pic.jpg](http://oss.fangxinqian.cn/f0b1fe499322463a95ed161d35994270.jpg)

解决办法：根据错误提示，需要我们执行

	brew link jpeg libpng
	
但这才是问题的刚刚开始，因为执行上面这条命令之后，很快又一个错误会发生：

![2.pic.jpg](http://oss.fangxinqian.cn/54910a9fb6924bbda607682a0b795195.jpg)

上面的错误提示我们需要删除一个文件，但是你以为删除掉就可以了吗？

我们删除该文件后再次执行

	brew link jpeg libpng
	
马上又会再出来一个错误提示，让我们再删除一个文件...

![3.pic.jpg](http://oss.fangxinqian.cn/9a1f685dee6f4a249b2234a7844fb1a4.jpg)

如此往复...

直到您看到那一小行字：

![24.pic.jpg](http://oss.fangxinqian.cn/4b871393cdac4c799066398dea69f225.jpg)

force ... 呵呵

所以我们需要执行:

	brew link --overwrite libpng
	
让这个问题一次性解决掉。（不知道有多少粗心大意的同学会老老实实一个一个删...）	

然后再次执行

	brew link jpeg libpng
	
就不会有错误提示了

![25.pic.jpg](http://oss.fangxinqian.cn/41a41e356e4a402a8741f2725152169e.jpg

安装完这两个依赖之后，我们再次安装rabbitMQ:

![26.pic.jpg](http://oss.fangxinqian.cn/1dc11db166404a7281478c72ea2ea962.jpg)

便能够完成安装。

## 通用操作

### 启动

启动RabbitMQ，不建议直接执行

	/usr/local/Cellar/rabbitmq/3.6.1/sbin/rabbitmq-server
	
最好执行

	/usr/local/Cellar/rabbitmq/3.6.1/sbin/rabbitmqctl start_app
	
因为rabbitmq并没有直接给我们配置环境变量，所以我们需要自己在~/.bash_profile文件中，增加以下配置:

	export PATH=$PATH:/usr/local/Cellar/rabbitmq/3.6.1/sbin/
		

### 关闭

	/usr/local/Cellar/rabbitmq/3.6.1/sbin/rabbitmqctl stop_app

### 登陆管理界面

在浏览器输入: http://localhost:15672/

用户名和密码都为: guest

### 创建User并设置权限

#### 添加User

![1.pic_hd.jpg](http://oss.fangxinqian.cn/b3847398c5c34eb1967e1901d0ded468.jpg)

#### 设置User权限

不然在项目中，该User无法与rabbitServer建立连接

![2.pic.jpg](http://oss.fangxinqian.cn/9d875bcc15a24d12a9b1ef1faadd3adb.jpg)



