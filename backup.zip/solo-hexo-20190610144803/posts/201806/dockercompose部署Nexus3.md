title: docker-compose:部署Nexus3
date: '2018-06-12 07:10:22'
updated: '2018-06-12 07:10:22'
tags: [Maven, Docker]
permalink: /articles/2018/06/12/1528768888425.html
---
> 利用docker-compose在docker下部署Maven私服Nexus

## 前言

先上项目源代码 [liumapp/nexus-in-docker](https://github.com/liumapp/nexus-in-docker)和用于测试发布的 [liumapp/convert-html-to-pdf](https://github.com/liumapp/convert-html-to-pdf)

nexus-in-docker项目用于在系统的Docker上部署Nexus3，convert-html-to-pdf用于测试发布到该Nexus私服上。

## Nexus安装运行

使用命令

	docker-compose up -d 
	
会自动去docker hub拉取Nexus:3.12.1版本的镜像并生成容器运行。

不过因为设置了volumes与容器内的/nexus-data目录建立关联，所以在运行之前，需要确保nexus-in-docker的根目录具备写权限。

运行成功后（不会有提示信息，可以使用 ``` docker logs -t -f --tail 100 nexus ``` 来查看启动日志），在浏览器内访问http://localhost:8081便可以打开Nexus的管理web页面。

初始的管理员帐号密码为 admin/admin123。

## Deploy项目

### 创建Repository

使用admin登陆后，我们可以在设置一栏里创建一个Repository，需要注意的地方只有三个：

* Recipe要选择Maven2(hosted)。

	可能有小伙伴会问，为什么不是Maven2(group)或者Maven2(proxy)呢？
	首先要搞清楚proxy,hosted,group三者的关系：
	
	*   `proxy` 远程仓库的代理，比如说`nexus`配置了一个`central repository`的`proxy`,当用户向这个`proxy`请求一个`artifact`的时候，会现在本地查找，如果找不到，则会从远程仓库下载，然后返回给用户。
	
	*   `hosted` 宿主仓库，用户可以把自己的一些仓库`deploy`到这个仓库中
	
	*   `group` 仓库组，是nexus特有的概念，目的是将多个仓库整合，对用户暴露统一的地址，这样就不需要配置多个仓库地址。
	
	所以我们的项目是要发布到本地的Nexus私服，自然就要选择hosted。
	
* Version policy要选择Mixed

	因为我们的Maven项目在打版本的时候，有时候是Release版本，有时候就是一个v1.0.0版本，像我就喜欢用后者，选择Mixed可以让私服支持不同类型的项目版本，如果您选择的是Release或者Snapshot，那么deploy过来的项目就必须是这两种类型的版本，不然就会报错。

* Deployment policy要选择Allow redeploy

	一个项目总不可能不更新迭代了吧，除非已经放弃治疗删库跑路了。
	
### 添加Nexus用户

添加一个Nexus用户，用于后面的Deploy，只需要注意两点：

* User的ID将会在后面的Maven配置项中作为username来使用，所以很多情况都会发现id跟username相同的情况。

* User的status请注意设置为active，虽然这是一个显而易见的事情，但还是会存在很多粗心大意的情况。
	
### 本地Deploy

接下来轮到我们的另一个测试项目[liumapp/convert-html-to-pdf](https://github.com/liumapp/convert-html-to-pdf)上场。

首先修改本地maven的配置文件settings.xml，把新添加的maven私服用户写入server下。

	<servers>
	  <server>
		<id>liumapp</id>
		<username>liumapp</username>
		<password>liumapp</password>
	  </server>
	</servers>
	
在要发布到该私服下的maven项目中，添加：

	<distributionManagement>
		<repository>
			<id>liumapp</id>
			<url>http://127.0.0.1:8081/repository/liumapp/</url>
		</repository>
	</distributionManagement>
	
这里repository/liumapp的liumapp代表您刚刚创建的repository名称，并不是用户名。	
	
然后在build下添加以下插件

	  <!--发布代码Jar插件-->
      <plugin>
          <groupId>org.apache.maven.plugins</groupId>
          <artifactId>maven-deploy-plugin</artifactId>
          <version>2.7</version>
      </plugin>
      <!--发布源码插件-->
      <plugin>
          <groupId>org.apache.maven.plugins</groupId>
          <artifactId>maven-source-plugin</artifactId>
          <version>2.2.1</version>
          <executions>
              <execution>
                  <phase>package</phase>
                  <goals>
                      <goal>jar</goal>
                  </goals>
              </execution>
          </executions>
      </plugin>
	
最后在console下输入命令

	mvn deploy
	
具体的配置可以直接在convert-html-to-pdf下查看pom.xml文件。

如果您要发布的是一个Jar包，那么直接使用命令：

	mvn deploy:deploy-file -DgroupId=com.aspose.words -DartifactId=aspose-words -Dversion=15.8.0 -Dpackaging=jar -Dfile=./aspose-words-15.8.0-jdk16.jar -Durl=http://127.0.0.1:8081/repository/liumapp/ -DrepositoryId=liumapp
	
即可。	
	
## 使用私服

在要从该私服下载依赖的项目中，配置pom.xml文件：

	<repositories>
	  <repository>
		<id>test</id>
		<url>http://127.0.0.1:8081/repository/liumapp/</url>
	  </repository>
	</repositories>
	
即可




	