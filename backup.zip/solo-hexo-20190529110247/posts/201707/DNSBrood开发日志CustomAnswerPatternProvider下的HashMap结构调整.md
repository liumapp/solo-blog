title: DNSBrood开发日志——CustomAnswerPatternProvider下的HashMap结构调整
date: '2017-07-27 14:55:28'
updated: '2017-07-31 09:15:07'
tags: [DNS, dnsJava, Java]
permalink: /articles/2017/07/27/1501137632912.html
---
> 调整的HashMap，原设计目的是存放要响应客户正向解析请求的DNS记录。调整后目的不变，只不过不再以用户ip为键，转而使用域名为键。

### 旧的方案

如图，之前是根据用户主机的IP作为唯一性判断，所以将IP作为键，每一个用户IP对应的值都为一个新的HashMap，该Map下再去存放以域名为键，解析的地址为值的数据。

![1.pic.jpg](http://oss.fangxinqian.cn/e13cdb1b707c415e94ffac26fd1e981f.jpg)

### 新的方案

利用HashMap键的唯一性，将域名作为键，其值为新的HashMap，并存放如下键值对数据：

	"ip" => "1.2.3.4","userNumber" => "LM123123123"
	
更改后的结构如下图所示：
	
![1.pic.jpg](http://oss.fangxinqian.cn/b4eca2f32c77449d8595a4ba94759880.jpg)
	
### 缘由

主要还是因为需求发生了变动，原设计是以用户机IP作为域名所属的判断依据，新的方案要改为使用userNumber作为依据。

