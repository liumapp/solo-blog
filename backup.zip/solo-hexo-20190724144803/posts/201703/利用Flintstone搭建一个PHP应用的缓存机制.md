title: 利用Flintstone搭建一个PHP应用的缓存机制
date: '2017-03-30 14:49:51'
updated: '2017-03-30 14:49:51'
tags: [PHP, Flintstone]
permalink: /articles/2017/03/29/1490780263848.html
---
# FlintStone

> [Flintstone](https://github.com/fire015/flintstone.git)是一款key-value键值对类型的基于文件的database，实际应用场景比较适合于搭建PHP缓存机制。

***

## 下载安装

利用 composer:

在composer.json文件中使用以下代码

	"require": {
	  "fire015/flintstone":"v1.9.0"
	},
	
执行composer require fire015/flintstone命令

## 如何使用

写入操作的示范代码如下：

	$orderId = time() . rand(100 , 999);
	$data = Flintstone::load('unionData' , ['dir' => __DIR__ . '/../data/']);
	$data->set('orderId' , $orderId);
	$data->set('txnTime' , date('YmdHmi' , time()));
	$data->set('txnAmt' , 1);

上述代码执行后，将会在data目录下生成一个unionData.dat文件，同时以键值对的形式存储了orderId,txtTime,txnAmt的value

读取操作的示范代码如下：

	$data = Flintstone::load('unionData' , ['dir' => __DIR__ . '/../data/']);
	$result = [
	  'orderId' => $data->get('orderId'),
	  'txnTime' => $data->get('txnTime'),
	  'txnAmt' => $data->get('txnAmt'),
	];
	
上述代码执行后，$result将获取到unionData存储的内容

## 总结

Flintstone类似于redis，是一款key-value键值对存储系统，适用于存储内容变化不大不频繁的内容，即用于缓存页面。

但是如果对于经常需要变换的内容，比如订单数据，那么使用Flintstone就不适宜了，这里笔者就犯了过渡设计的错误。


