title: 合作项目——Git分支的选择
date: '2018-01-02 22:01:00'
updated: '2018-02-25 16:55:49'
tags: [Github, GitLab]
permalink: /articles/2018/01/02/1514900679451.html
---
> 时不时发几篇基础的Git命令文章......

假设现在我们从GitHub上拉下来一个带有多个分支的项目，可是如果直接在本地使用命令：

	git branch 
	
查看分支，估计只会看到一个master分支。

如图：

![1.pic.jpg](http://oss.fangxinqian.cn/69e209c39f394f45b80bbc59cd800324.jpg)

那么其他的分支去哪了？

当然藏起来了，您需要使用

	git branch -a
	
命令才能查看到全部的分支哦。

如图：

![2.pic.jpg](http://oss.fangxinqian.cn/340177135a1349f2a49b6f80e6e12d26.jpg)

如果现在要切换到develop分支，然后开始干活的话，那么只需要checkout一下就好：

	git checkout develop
	
如图：

![3.pic.jpg](http://oss.fangxinqian.cn/bc65958c87c146d98a4a39a5f37aeeff.jpg)

切换成功后，我们再来检查一下分支，就会发现当前分支已经切换到develop下了。

![4.pic.jpg](http://oss.fangxinqian.cn/28d332eb497a40adade967efd30beeaa.jpg)

一般而言，只要项目还在开发过程中，我们就应该至少保证有两个分支在场，这样可以确保在开发过程中，可以保证至少master的代码被别人拉下去运行是正常的。

### 创建新的分支并提交

在本地创建分支：test

	git checkout -b test
	
在test分支修改代码后提交到远程仓库中：

	git push origin test
	
	
