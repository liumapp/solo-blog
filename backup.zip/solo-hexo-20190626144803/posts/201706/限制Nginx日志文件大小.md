title: 限制Nginx日志文件大小
date: '2017-06-01 15:33:19'
updated: '2018-04-10 14:07:47'
tags: [Linux, nginx]
permalink: /articles/2017/06/01/1496286037699.html
---
# 限制Nginx日志文件大小

> 对于一个访问量还算可以的系统而言，Nginx每天记录日志的量都会是一个庞大的数据。假以时日，日志文件的Size会无限制的膨胀，最终导致服务器磁盘空间被占满，这篇博文记述了一个解决问题的方法：限制日志文件只记录最近七天的数据。

### 日志文件

首先我们进入nginx的log所在的目录，输入命令查看一下各个文件占用的大小。

	[root@iZ23cpyx08rZ logs]# ls -lht

	total 387M

	-rw-r--r-- 1 root root 126M Jun 1 10:08 access.log

	-rw-r--r-- 1 root root 261M Jun 1 10:06 error.log

	-rw-r--r-- 1 root root 5 Nov 12 2016 nginx.pid
	
可以看到，日志文件占用的空间是387M，请注意，这是一天的量。（清空目录，然后第二天来检查）

### 具体实现

首先项目的源码请见： **[nginxLogControl](https://github.com/liumapp/nginxLogControl)**

* 首先我们要知道，Nginx不像Apache可以自动的进行日志管理，所以我们只能手动写脚本对日志文件进行切割。

* 我们这里通过crontab+shell脚本来实现，脚本的部署和使用请见Github上的Readme

实现思路：

* 第一个步骤，将当天生成的access和error拷贝到一个新的有时间命名的文件中，比如access-20170601.log。

* 第二个步骤，将log目录下7天没有修改过的.log结尾的文件删除。以此来实现只保留最近7天的日志文件。

### 结果

![1.pic.jpg](http://oss.fangxinqian.cn/15002a6e1bcd408b958e5bfb66cfa0b8.jpg)

### 技术细节

#### find

	find . -amin -10 # 查找在系统中最后10分钟访问的文件
	find . -atime -2 # 查找在系统中最后48小时访问的文件
	find . -empty # 查找在系统中为空的文件或者文件夹
	find . -group cat # 查找在系统中属于 groupcat的文件
	find . -mmin -5 # 查找在系统中最后5分钟里修改过的文件
	find . -mtime -1 #查找在1天以内修改过的文件
	find . -mtime +7 #查找在7天以外修改过的文件
	find . -nouser #查找在系统中属于作废用户的文件
	find . -user fred #查找在系统中属于FRED这个用户的文件
	find . -type -f # 查找文件类型为普通文件的文件
	

#### crontab

a.cron服务是Linux的内置服务，但它不会开机自动启动。可以用以下命令启动和停止服务：

	  /sbin/service crond start

	  /sbin/service crond stop

	  /sbin/service crond restart

	  /sbin/service crond reload

	  ubuntu下为：
	  /etc/init.d/cron start
	  ...
	  
b.查看、编辑和删除——以root身份写入计划任务：crontab -u root -e
cron把命令行保存在crontab（cron table）文件里，这个文件通常在 /etc 目录下。每个系统用户都可以有自己的crontab（在 /var/spool/cron/ 下）。要查看当前用户的crontab，输入 crontab -l；要编辑crontab，输入 crontab -e；要删除crontab，输入 crontab -r。如当前是root身份，要查看/编辑/删除/某用户的crontab，只需在相应的命令后加上 -u USERNAME（如 crontab -e -u USERNAME）即可。crontab文件的默认编辑器是vi，可以输入 export VISUAL=’editor’ 更改默认编辑器。

	cron服务每分钟不仅要读一次 /var/spool/cron 目录内的所有文件，还需要读一次 /etc/crontab 文件。配置这个文件也能让cron执行任务。使用crontab命令是对用户级任务的配置，而编辑 /etc/crontab 文件是对系统级任务的配置。
	
c.语法说明

	字段      说明
	1		  分钟（0-59）
	2 		  小时（2-24）
	3         日期（1-31）
	4         月份（1-12；或英文简写）
	5         周几（0-6,0为周日；或英文单词缩写）
	6         用户名（执行命令时以此用户的身份）————当执行crontab -u root -e 语句后写入命令时，系统已经知道用户身份故不需要再写入用户名，即此字段的值可以省略；
	7         要执行的命令
	
d.举例

	12 3 * * * root tar czf /usr/local/backups/daily/etc.tar.gz /etc >> /dev/null 2>&1


这条语句将在每天的凌晨3点12分（03:12）运行 tar czf /usr/local/backups/daily/etc.tar.gz /etc 命令。>> /dev/null 2>&1 表示把所有标准输出发送到 /dev/null（linux的回收站），把标准错误输出（2）发送到和标准输出（r1）同样的地方（即 /dev/null）。运行这行命令将不会产生任何输出。

这条语句可以变得稍微复杂一点：

	30 15 13 6 1 * root tar czf /usr/local/backups/daily/etc.tar.gz /etc >> /dev/null 2>&1
	
它将在6月13日周一的15:30运行 tar czf /usr/local/backups/daily/etc.tar.gz /etc 命令。

以下语句可以达到同样的效果：

	30 15 13 Jun Mon * root tar czf /usr/local/backups/daily/etc.tar.gz /etc >> /dev/null 2>&1

如果你想以用户joey的身份每小时的第15分钟运行某个程序，可以使用：

	15 * * * * joey /usr/bin/somecommand >> /dev/null 2>&1

其中的星号（*）是通配符，表示cron将忽略这个字段。

如果你想每两小时就运行某个程序，可以在小时字段里使用 */2。它将会在2点，4点，6点……22点，24点运行。具体语句如下：

	0 */2 * * * joey /usr/bin/somecommand >> /dev/null 2>&1

cron语句中还可以使用逗号（,）来指定多个时间。例如你想在每小时的15分和30分运行某个程序，可以在分钟字段使用 15,30：

	15,30 * * * * joey /usr/bin/somecommand >> /dev/null 2>&1

如果你想在每月的第一周（即1号到7号）每天的指定时间运行某个程序，可以在日期字段使用 1-7：

	15,30 */2 1-7 * * joey /usr/bin/somecommand >> /dev/null 2>&1

这条语句将在每月的第1-7日每两小时的15分和30分（02:15，02:30……22: 15，22:30等）运行 /usr/bin/somecommand 命令。

如果你想在每天的16:18执行一个脚本集合，可以把所有要执行的脚本放到一个目录中（如 /home/username/cron），可以使用：

	18 16 * * * root run-parts /home/username/cron >> /dev/null 2>&1

如果你想保存某个程序的输出结果， 可以把 >> /dev/null 2>&1 替换为 >> /home/user/somecommand.log 2>&1 。


#### xargs

xargs是一Unix和类Unix操作系统的常用命令。它的作用是将参数列表转换成小块分段传递给其他命令，以避免参数列表过长的问题。