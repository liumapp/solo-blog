title: 用scp建立Mac跟CentOS之间的基情
date: '2017-11-27 14:35:18'
updated: '2017-11-27 14:35:18'
tags: [Linux, CentOS, Mac]
permalink: /articles/2017/11/27/1511762257133.html
---
> 正如标题所言，Mac一般为我们本地的开发环境，CentOS一般为生产服务端的环境，两者之间的文件上传和下载有很多种方式，最常见的就是FileZila，但它偶尔的罢工以及对Ftp的依赖，还是让我不得不转用scp来完成这项工作。

## Mac to CentOS

假设把Mac上的一个project.jar文件，上传到sign.liumapp.com所对应的服务器的/usr/local/project/project.jar这个位置：

基本步骤:

* 确保服务器端的/usr/local/project目录是存在的

* 输入命令

		 scp project.jar root@sign.liumapp.com:/usr/local/project/project.jar
	  
	  
* 输入sign.liumapp.com的root密码，也可以使用其他用户名，然后输入其所对应的帐号密码，但是要确保该用户对要操作的目录有写权限。

* 等待上传成功即可。


## CentOS to Mac

假设要把sign.liumapp.com所对应的服务器的/usr/local/project/project.jar这个包下载到本地，并保存为一个tmp.jar文件。

基本步骤:

* 直接输入命令：

		scp root@sign.liumapp.com:/usr/local/project/project.jar ./tmp.jar
	
* 输入密码

* 等待下载成功即可。