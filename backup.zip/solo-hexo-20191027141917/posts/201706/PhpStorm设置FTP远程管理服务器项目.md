title: PhpStorm设置FTP远程管理服务器项目
date: '2017-06-07 10:49:05'
updated: '2017-09-06 11:38:50'
tags: [PhpStorm, Ftp]
permalink: /articles/2017/06/07/1496803446567.html
---
> 对于whmcs系统而言，它的授权码验证是绑定了IP的，所以服务器的whmcs，我们没有办法在本地上部署，而在开发过程中，需要不断的调试，所以这里记录了使用PhpStorm本地开发、通过ftp上传到服务器的流程。

### 流程

* 创建项目，首先假定本地的项目路径为:/usr/local/var/www/whmcs，服务器的项目路径为：/alidata/www/default/whmcs，对应IP为：http://118.190.133.67/whmcs/

* 在本地PhpStorm的右上角，选择Tools->Deployment->configuration

* 配置ftp参数信息，这里略过。

* 选择Mapping，配置你的本地项目路径和线上路径进行匹配，点击保存。

* 在本地项目修改过一个文件之后，按快捷键crtl+u 可以快速上传到线上。

* 如果上传失败，很有可能是因为服务器上的对应文件夹没有写的权限。