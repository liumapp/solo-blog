title: docker-compose:在容器中添加中文字体
date: '2018-06-05 06:38:55'
updated: '2018-06-05 06:38:55'
tags: [Docker]
permalink: /articles/2018/06/05/1528179707247.html
---
> 利用docker-compose的volumes及build来配置容器内的中文字体。

## 前言

先上案例代码: [liumapp/add-mandarin-fonts-in-docker](https://github.com/liumapp/add-mandarin-fonts-in-docker)

Docker容器内运行的项目，涉及到中文字体的输出时如果没有其他配置，一般都是以乱码结尾。

总结其原因，其实就跟Linux下没有中文字体一样。

在Docker下部署中文字体，除了写Dockerfile之外，也可以利用docker exec命令进入容器内部安装字体，但...

这些都太麻烦了呀.....

网络上很多复制粘贴的帖子也都是这样的套路...

其实利用docker-compose简单进行两项配置就可以了，完全不用再做其他多余的事情。

## docker-compose配置

先上docker-compose.yml的内容

	version: '2'

	services:
	  mandarin:
		container_name: mandarin
		restart: always
		image: liumapp/add-mandarin-fonts-in-docker:v1.0.0
		build:
		  context: .
		  args:
			- LANG=C.UTF-8
		ports:
		  - 8080:8080
		volumes:
		  - ./fonts:/usr/share/fonts
		  - ./pdf:/pdf
		  - ./doc:/doc

比较特殊的地方就两个:build跟volumes

### build

	build:
	  context: .
	  args:
		- LANG=C.UTF-8
		
设置容器内编码为UTF-8，使之支持中文字体。

### volumes

	volumes:
	  - ./fonts:/usr/share/fonts
	  - ./pdf:/pdf
	  - ./doc:/doc

将宿主机，或者说项目下的fonts目录下的中文字体全部与容器内的/usr/share/fonts建立关联，使绝大多数的中文字体都能够被找到。

另外补充一下，案例项目下的fonts目录有大约300多M，下面的字体文件是来自于windows7下字体库的所有.ttf和.ttc结尾的字体文件，这样做的理由，是因为仅仅让Docker支持中文字体是远远不够的，我们很多的需求，比如文档转换、图片转换都是需要用到很多不同的字体，所以方便起见，直接拷贝windows7下所有的相关字体是最直截了当的方式。

### fontconfig

可能有人会注意到，一般在Linux下面配置中文字体都是需要用到fontconfig这样的工具，然而，在以Java:8为baseImage的项目下，fontconfig是自动配置好了的，所以我们不需要额外关心这个家伙。

不过Java:8以外的我就没有去尝试了，估计就要多做几步了吧～




		
		



