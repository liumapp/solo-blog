title: 'Maven编译失败：use -source 7/8 or higher to do something '
date: '2018-07-28 12:43:32'
updated: '2018-07-28 12:43:32'
tags: [Maven, Java]
permalink: /articles/2018/07/28/1532781600150.html
---
> 今天碰到的Maven编译问题还不少，不过解决起来都不算难，修改一个配置即可，在这里做一下记录

## 错误信息

在Maven编译的过程中，我们偶尔会碰到这些莫名奇妙的问题：

	use -source 7 or higher to enable multi-catch statement
	
	use -source 8 or higher to enable lambda expressions
	
	use -source 8 or higher to enable method references
	
	....
	
异常信息读起来不难，要求我们用更高版本的JDK去执行编译命令，可是我们已经使用：

	<properties>
	  <java.version>1.8</java.version>
	</properties>
	
来指定JDK版本了呀，那为什么还是会出错？

## 解决办法

项目所用的JDK版本，跟我们用Maven编译的时候的JDK版本不是用同一个参数来设置的，所以对于maven-compiler-plugin

我们需要在它的configuration下增加两个配置项：

	<source>1.8</source>
	<target>1.8</target>
	
完整配置如下：

	<plugin>
	  <groupId>org.apache.maven.plugins</groupId>
	  <artifactId>maven-compiler-plugin</artifactId>
	  <version>3.2</version>
	  <configuration>
		<source>1.8</source>
		<target>1.8</target>
	  </configuration>
	</plugin>



	