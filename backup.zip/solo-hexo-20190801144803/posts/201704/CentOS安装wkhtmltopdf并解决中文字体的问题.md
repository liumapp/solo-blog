title: CentOS安装wkhtmltopdf并解决中文字体的问题
date: '2017-04-10 17:17:26'
updated: '2017-04-10 17:17:26'
tags: [wkhtmltopdf, Linux, CentOS, 中文字体]
permalink: /articles/2017/04/10/1491811668985.html
---
> 最近项目上涉及到一个将html转化为pdf的需求，这里选择了wkhtmltopdf来实现，可是在具体实施过程中，发现这里面还涉及到一个“linux服务器上默认没有中文字体，导致wkhtmltopdf渲染的pdf文件不能显示中文的问题”，所以写一篇博客，帮助还有同样需求的小伙伴们快速解决问题。

### 安装wkhtmltopdf

为方便，以下代码都是作为root用户在Centos命令行下操作：

	cd ~

	wget http://download.gna.org/wkhtmltopdf/0.12/0.12.3/wkhtmltox-0.12.3_linux-generic-amd64.tar.xz

	xz -d wkhtmltox-0.12.3_linux-generic-amd64.tar.xz

	tar -xvf wkhtmltox-0.12.3_linux-generic-amd64.tar

	cd wkhtmltox

	cd bin

	//测试

	./wkhtmltopdf "http://www.taobao.com" 1.pdf 

如果打开的1.pdf成功渲染出来，那说明wkhtmltopdf安装成功，不过在这里，一般能够看到1.pdf里面的中文字体并没有被成功渲染出来，那么接下来说明字体问题的解决。

### 服务器安装中文字体


#### 正式开工之前要准备的工具

**1.fontconfig**

	yum install fontconfig
  
成功后会有这样的消息出来：

	 Dependencies Resolved

	==============================================================================================================================================================

	 Package Arch  Version  Repository Size

	==============================================================================================================================================================

	Updating:

	 fontconfig  x86_64  2.10.95-10.el7 base  229 k

	Transaction Summary

	==============================================================================================================================================================

	Upgrade 1 Package

	Total download size: 229 k

	Is this ok [y/d/N]: y                                                                                               

	Downloading packages:

	Delta RPMs disabled because /usr/bin/applydeltarpm not installed.

	fontconfig-2.10.95-10.el7.x86_64.rpm  | 229 kB 00:00:02     

	Running transaction check

	Running transaction test

	Transaction test succeeded

	Running transaction

	 Updating  : fontconfig-2.10.95-10.el7.x86_64  1/2 

	 Cleanup : fontconfig-2.10.95-7.el7.x86_64 2/2 

	 Verifying : fontconfig-2.10.95-10.el7.x86_64  1/2 

	 Verifying : fontconfig-2.10.95-7.el7.x86_64 2/2 

	Updated:

	 fontconfig.x86_64 0:2.10.95-10.el7                                                                                                                          

	Complete!
	
	
	
**2.ttmkfdir**

	yum install ttmkfdir
	
安装成功后会有这样的提示：


	  ==============================================================================================================================================================

	   Package  Arch Version Repository  Size

	  ==============================================================================================================================================================

	  Installing:

	   ttmkfdir x86_64 3.0.9-42.el7  base  48 k

	  Transaction Summary

	  ==============================================================================================================================================================

	  Install 1 Package

	  Total download size: 48 k

	  Installed size: 103 k

	  Is this ok [y/d/N]: y

	  Downloading packages:

	  ttmkfdir-3.0.9-42.el7.x86_64.rpm  | 48 kB 00:00:00     

	  Running transaction check

	  Running transaction test

	  Transaction test succeeded

	  Running transaction

	   Installing : ttmkfdir-3.0.9-42.el7.x86_64  1/1 

	   Verifying : ttmkfdir-3.0.9-42.el7.x86_64  1/1 

	  Installed:

	   ttmkfdir.x86_64 0:3.0.9-42.el7                                                                                                                              

	  Complete!
	  
	  
#### 正式动工

依次执行下列步骤：

把中文字体文件上传到/usr/share/fonts/chinese目录中

	Microsoft YaHei.ttf SimSun.ttf
	
执行命令

	ttmkfdir -e /usr/share/X11/fonts/encodings/encodings.dir
	
修改配置文件/etc/fonts/fonts.conf:

把 /usr/share/fonts/chinese目录添加进去:


	<!— Font directory list —>

		  <dir>/usr/share/fonts</dir>
		  <dir>/usr/share/X11/fonts/Type1</dir> <dir>/usr/share/X11/fonts/TTF</dir> <dir>/usr/local/share/fonts</dir>
		  <dir prefix="xdg">fonts</dir>
		  <!— the following element will be removed in the future —>
		  <dir>~/.fonts</dir>
		  <dir>/usr/share/fonts/chinese</dir>
		  
		  
清空缓存

	fc-cache
	
测试是否成功 


	fc-list

如果看到了中文就说明成果了，我的服务器上测试结果如下：

```

/usr/share/fonts/default/Type1/c059016l.pfb: Century Schoolbook L:style=Bold

/usr/share/fonts/chinese/SimSun.ttf: STFangsong:style=Regular,標準體,Ordinær,Normal,Normaali,Regolare,レギュラー,일반체,Regulier,Обычный,常规体

/usr/share/fonts/default/Type1/c059033l.pfb: Century Schoolbook L:style=Italic

/usr/share/fonts/default/Type1/p052024l.pfb: URW Palladio L:style=Bold Italic

/usr/share/fonts/default/Type1/d050000l.pfb: Dingbats:style=Regular

/usr/share/fonts/default/Type1/s050000l.pfb: Standard Symbols L:style=Regular

/usr/share/fonts/liberation/LiberationMono-Bold.ttf: Liberation Mono:style=Bold

/usr/share/fonts/default/Type1/n021003l.pfb: Nimbus Roman No9 L:style=Regular

/usr/share/fonts/default/Type1/a010013l.pfb: URW Gothic L:style=Book

/usr/share/fonts/default/Type1/n019003l.pfb: Nimbus Sans L:style=Regular

/usr/share/fonts/default/Type1/a010033l.pfb: URW Gothic L:style=Book Oblique

/usr/share/fonts/default/Type1/a010015l.pfb: URW Gothic L:style=Demi

/usr/share/fonts/default/Type1/n022003l.pfb: Nimbus Mono L:style=Regular

/usr/share/fonts/default/Type1/n022024l.pfb: Nimbus Mono L:style=Bold Oblique

/usr/share/fonts/default/ghostscript/putbi.pfa: Utopia:style=Bold Italic

/usr/share/fonts/default/Type1/b018012l.pfb: URW Bookman L:style=Light

/usr/share/fonts/liberation/LiberationMono-Italic.ttf: Liberation Mono:style=Italic

/usr/share/fonts/default/ghostscript/putri.pfa: Utopia:style=Italic

/usr/share/fonts/default/Type1/n021024l.pfb: Nimbus Roman No9 L:style=Medium Italic

/usr/share/fonts/default/Type1/a010035l.pfb: URW Gothic L:style=Demi Oblique

/usr/share/fonts/default/Type1/p052023l.pfb: URW Palladio L:style=Italic

/usr/share/fonts/default/Type1/c059013l.pfb: Century Schoolbook L:style=Roman

/usr/share/fonts/default/Type1/n021004l.pfb: Nimbus Roman No9 L:style=Medium

/usr/share/fonts/default/Type1/b018035l.pfb: URW Bookman L:style=Demi Bold Italic

/usr/share/fonts/default/Type1/n022023l.pfb: Nimbus Mono L:style=Regular Oblique

/usr/share/fonts/default/Type1/p052004l.pfb: URW Palladio L:style=Bold

/usr/share/fonts/default/Type1/n022004l.pfb: Nimbus Mono L:style=Bold

/usr/share/fonts/default/Type1/b018032l.pfb: URW Bookman L:style=Light Italic

/usr/share/fonts/default/Type1/n019023l.pfb: Nimbus Sans L:style=Regular Italic

/usr/share/fonts/default/Type1/b018015l.pfb: URW Bookman L:style=Demi Bold

/usr/share/fonts/default/ghostscript/putb.pfa: Utopia:style=Bold

/usr/share/fonts/liberation/LiberationMono-Regular.ttf: Liberation Mono:style=Regular

/usr/share/fonts/default/Type1/n021023l.pfb: Nimbus Roman No9 L:style=Regular Italic

/usr/share/fonts/default/Type1/n019024l.pfb: Nimbus Sans L:style=Bold Italic

/usr/share/fonts/default/Type1/z003034l.pfb: URW Chancery L:style=Medium Italic

/usr/share/fonts/chinese/Microsoft YaHei.ttf: STHeiti:style=Regular,標準體,Ordinær,Normal,Normaali,Regolare,レギュラー,일반체,Regulier,Обычный,常规体

/usr/share/fonts/default/Type1/n019004l.pfb: Nimbus Sans L:style=Bold

/usr/share/fonts/default/ghostscript/putr.pfa: Utopia:style=Regular

/usr/share/fonts/liberation/LiberationMono-BoldItalic.ttf: Liberation Mono:style=Bold Italic

/usr/share/fonts/default/Type1/n019044l.pfb: Nimbus Sans L:style=Bold Condensed

/usr/share/fonts/default/Type1/p052003l.pfb: URW Palladio L:style=Roman

/usr/share/fonts/default/Type1/c059036l.pfb: Century Schoolbook L:style=Bold Italic

/usr/share/fonts/default/Type1/n019063l.pfb: Nimbus Sans L:style=Regular Condensed Italic

/usr/share/fonts/default/Type1/n019064l.pfb: Nimbus Sans L:style=Bold Condensed Italic

/usr/share/fonts/default/Type1/n019043l.pfb: Nimbus Sans L:style=Regular Condensed

```

> 到此，可以愉快的使用wkhtmltopdf去玩html转pdf，不过呢，如果要使用php集成wkhtmltopdf的话，请看我的下篇博文。




