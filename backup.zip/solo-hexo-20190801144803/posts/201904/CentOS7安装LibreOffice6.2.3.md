title: CentOS7安装LibreOffice6.2.3
date: '2019-04-25 15:55:26'
updated: '2019-04-26 09:46:35'
tags: [CentOS, 文档, LibreOffice, PDF]
permalink: /articles/2019/04/25/1556178926172.html
---
> 在CentOS7上安装LibreOffice6.2.3、配置中文字体、实现对office系列文档转PDF操作的排坑记录

## 操作步骤

* 获取LibreOffice6.2.3以及中文字体的rpm下载包

	* 在官网进行下载：[https://www.libreoffice.org/download/download/](https://www.libreoffice.org/download/download/)

	* 下载名为LibreOffice_6.2.3_Linux_x86-64_rpm.tar.gz的压缩包

	* 下载名为LibreOffice_6.2.3_Linux_x86-64_rpm_langpack_zh-CN.tar.gz的压缩包

* 在服务器上解压LibreOffice_6.2.3_Linux_x86-64_rpm.tar.gz与LibreOffice_6.2.3_Linux_x86-64_rpm_langpack_zh-CN.tar.gz

	解压安装LibreOffice_6.2.3

	* tar -xvf LibreOffice_6.2.3_Linux_x86-64_rpm.tar.gz

	* 得到一个名为LibreOffice_6.2.3.2_Linux_x86-64_rpm的文件夹

	* 进入RPM包目录：```cd ./LibreOffice_6.2.3.2_Linux_x86-64_rpm/RPMS```

	* 使用```yum localinstall```批量安装rpms包： ``` yum localinstall *.rpm ```

	解压安装中文字体支持包

	* tar -xvf LibreOffice_6.2.3_Linux_x86-64_rpm_langpack_zh-CN.tar.gz

	* 得到一个名为LibreOffice_6.2.3.2_Linux_x86-64_rpm_langpack_zh-CN的文件夹

	* 进入RPM包目录： ```  cd ./LibreOffice_6.2.3.2_Linux_x86-64_rpm_langpack_zh-CN/RPMS/ ```

	* 使用```yum localinstall```批量安装rpms包： ``` yum localinstall *.rpm ```

	但经过实际测试，仅仅安装官方的中文字体包还是不够，很多时候我们要转换的中文doc文件，用到的字体文件都是windows系统下面的中文字体，所以保险起见，我们最好把windows系统下面的中文字体安装到CentOS上

	操作步骤大家可以参考我的这篇文章： [CentOS7服务器安装中文字体](http://www.liumapp.com/articles/2017/04/10/1491811668985.html)

* 安装成功后，使用命令 ``` which libreoffice6.2 ```查看可执行文件位置，不出意外应该结果应该是 ``` /usr/bin/libreoffice6.2 ```

	或者使用命令 ``` ll /usr/bin/libreoffice6.2 ``` 查看具体安装位置，不出意外结果应该是 ```  /usr/bin/libreoffice6.2 -> /opt/libreoffice6.2/program/soffice ```

* 测试libreoffice6.2是否运行正常

	* 上传一个test.doc文档到服务器上，假设文件目录为 /usr/src/test.doc

	* 执行命令开始将test.doc转换为test.pdf  

		```
		libreoffice6.2 --headless --invisible --convert-to pdf /usr/src/test.doc --outdir /usr/src
		```

	* 不出意外的应该会报以下错误：

		``` 
		/opt/libreoffice6.2/program/soffice.bin: error while loading shared libraries: libcairo.so.2: cannot open shared object file: No such file or directory
		 ```

		原因是libcairo.so.2这个库找不到，我们下载安装就可以了

		安装命令如下

		请依次执行

		 ```
		 yum install cairo -y
		 yum install cups-libs -y
		 yum install libSM -y
		 ```
	*  再次执行命令
	
		```
		libreoffice6.2 --headless --invisible --convert-to pdf /usr/src/test.doc --outdir /usr/src
		```

		转换成功，结束