title: ITEXT——Rectangle坐标的概念
date: '2017-09-28 09:40:01'
updated: '2017-09-28 09:40:38'
tags: [Java, Itext]
permalink: /articles/2017/09/28/1506559767771.html
---
> 利用Itext在PDF中设置一个矩形框并绘制上去，不可避免的需要使用Rectangle这个类以及Itext中的xy坐标轴。

首先我们先来看代码：


	Document  document = new  Document();
	PdfWriter  pdfWriter = PdfWriter.getInstance(document , new  FileOutputStream(tmp_pdf));
	document.open();
	document.add(new  Paragraph("hello world"));
	PdfFormField  pdfFormField1 = PdfFormField.createSignature(pdfWriter);
	PdfFormField  pdfFormField2 = PdfFormField.createSignature(pdfWriter);
	PdfFormField  pdfFormField3 = PdfFormField.createSignature(pdfWriter);
	PdfFormField  pdfFormField4 = PdfFormField.createSignature(pdfWriter);

	PdfAppearance  pdfAppearance = PdfAppearance.createAppearance(pdfWriter , 72 , 48);

	pdfFormField1.setWidget(new  Rectangle(72 , 732 , 144 , 780) , PdfAnnotation.HIGHLIGHT_INVERT);
	pdfFormField1.setFlags(PdfAnnotation.FLAGS_PRINT);
	pdfFormField1.setPage();
	pdfFormField1.setMKBorderColor(BaseColor.BLACK);
	pdfFormField1.setMKBackgroundColor(BaseColor.WHITE);
	pdfAppearance.rectangle(0.5f , 0.5f , 71.5f , 47.5f);
	pdfAppearance.stroke();
	pdfFormField1.setAppearance(PdfAnnotation.APPEARANCE_NORMAL , pdfAppearance);
	pdfWriter.addAnnotation(pdfFormField1);

	pdfFormField2.setWidget(new  Rectangle(72 , 532 , 144 , 580) , PdfAnnotation.HIGHLIGHT_INVERT);
	pdfFormField2.setFlags(PdfAnnotation.FLAGS_PRINT);
	pdfFormField2.setPage();
	pdfFormField2.setMKBorderColor(BaseColor.BLACK);
	pdfFormField2.setMKBackgroundColor(BaseColor.WHITE);
	pdfAppearance.rectangle(0.5f , 0.5f , 71.5f , 47.5f);
	pdfAppearance.stroke();
	pdfFormField2.setAppearance(PdfAnnotation.APPEARANCE_NORMAL , pdfAppearance);
	pdfWriter.addAnnotation(pdfFormField2);

	pdfFormField3.setWidget(new  Rectangle(72 , 332 , 144 , 380) , PdfAnnotation.HIGHLIGHT_INVERT);
	pdfFormField3.setFlags(PdfAnnotation.FLAGS_PRINT);
	pdfFormField3.setPage();
	pdfFormField3.setMKBorderColor(BaseColor.BLACK);
	pdfFormField3.setMKBackgroundColor(BaseColor.WHITE);
	pdfAppearance.rectangle(0.5f , 0.5f , 71.5f , 47.5f);
	pdfAppearance.stroke();
	pdfFormField3.setAppearance(PdfAnnotation.APPEARANCE_NORMAL , pdfAppearance);
	pdfWriter.addAnnotation(pdfFormField3);

	pdfFormField4.setWidget(new  Rectangle(72 , 132 , 144 , 180) , PdfAnnotation.HIGHLIGHT_INVERT);
	pdfFormField4.setFlags(PdfAnnotation.FLAGS_PRINT);
	pdfFormField4.setPage();
	pdfFormField4.setMKBorderColor(BaseColor.BLACK);
	pdfFormField4.setMKBackgroundColor(BaseColor.WHITE);
	pdfAppearance.rectangle(0.5f , 0.5f , 71.5f , 47.5f);
	pdfAppearance.stroke();
	pdfFormField4.setAppearance(PdfAnnotation.APPEARANCE_NORMAL , pdfAppearance);
	pdfWriter.addAnnotation(pdfFormField4);

	document.close();
	
然后来一张效果图：

  ![1.pic.jpg](http://oss.fangxinqian.cn/de4218c5b7044b319a488fa41fff2575.jpg)
  
这张效果图由上往下，依次是pdfFormField1、pdfFormField2、pdfFormField3、pdfFormField4绘制的矩形框。

### 坐标轴

在讲Rectangle的四个坐标参数之前，先理解一下IText中对于PDF设置的xy坐标的概念。

首先，Itext按照page页数来对一个PDF文本做一个拆分，指定了第几页，那就在那一页上做操作。当我们setPage()方法传递的是一个空值时，就表示操作第一页。

然后坐标轴的原点（0，0）位于该页面的左下角。X轴就是左下角到右下角的那条直线，Y轴就是左下角到左上角的那条直线。

### Rectangle

在用Rectangle绘制一个矩形的时候，我们需要往它的构造函数里传递四个参数，前面两个参数代表第一个点的xy坐标，后面两个参数代表第二个点的xy坐标值，Itext将以这两个点作为对角点来创建一个矩形。

### 用途

咋一看，绘制这么一个矩形似乎并没有什么卵用，但实际上，我们用的比较多的一个地方：PDF数字签名就跟它密切相关。PDF数字签名的具体实现我将在之后的博文里面进行更新。