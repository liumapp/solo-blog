title: 分享一个亲测可用的VPN工具
date: '2017-07-21 08:40:44'
updated: '2017-07-25 09:15:33'
tags: [VPN]
permalink: /articles/2017/07/21/1500597644139.html
---
> 听说看世界的眼睛被戳瞎了？没事，补补还能用

[lantern](https://github.com/getlantern/lantern)