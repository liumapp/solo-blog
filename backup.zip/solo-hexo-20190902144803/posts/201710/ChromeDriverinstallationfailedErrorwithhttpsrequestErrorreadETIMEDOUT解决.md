title: 'ChromeDriver installation failed Error with http(s) request: Error: read ETIMEDOUT解决'
date: '2017-10-27 10:04:35'
updated: '2018-04-18 10:40:18'
tags: [nodeJs, javascript]
permalink: /articles/2017/10/27/1509069874940.html
---
> 在执行 npm install命令，偶尔会报出chromedriver无法下载的错误，通过查询，发现在Github下vue-router的issue上有对这个问题的解决办法，具体链接[issue](https://github.com/vuejs/vue-router/issues/261#issuecomment-218618180)，这篇博文总结了一下解决办法。

## 首先上错误信息：
	
	Downloading https://chromedriver.storage.googleapis.com/2.33/chromedriver_mac64.zip

	Saving to /usr/local/tomcat/project/hello-vue/node_modules/chromedriver/chromedriver/chromedriver_mac64.zip

	ChromeDriver installation failed Error with http(s) request: Error: read ETIMEDOUT

	npm  WARN karma-sinon-chai@1.3.2 requires a peer of sinon@^2.1.0 but none was installed.

	npm  ERR! Darwin 15.6.0

	npm  ERR!  argv "/usr/local/Cellar/node/5.8.0/bin/node" "/usr/local/bin/npm" "install"

	npm  ERR!  node v7.8.0

	npm  ERR!  npm  v4.2.0

	npm  ERR!  code ELIFECYCLE

	npm  ERR!  errno 1

	npm  ERR! chromedriver@2.33.2 install: `node install.js`

	npm  ERR! Exit status 1

	npm  ERR! 

	npm  ERR! Failed at the chromedriver@2.33.2 install script 'node install.js'.

	npm  ERR! Make sure you have the latest version of node.js and npm installed.

	npm  ERR! If you do, this is most likely a problem with the chromedriver package,

	npm  ERR! not with npm itself.

	npm  ERR! Tell the author that this fails on your system:

	npm  ERR!  node install.js

	npm  ERR! You can get information on how to open an issue for this project with:

	npm  ERR!  npm bugs chromedriver

	npm  ERR! Or if that isn't available, you can get their info via:

	npm  ERR!  npm owner ls chromedriver

	npm  ERR! There is likely additional logging output above.

	npm  ERR! Please include the following file with any support request:

	npm  ERR!  /var/root/.npm/_logs/2017-10-27T01_56_37_026Z-debug.log
	
## 解决办法：

执行以下命令即可。

	npm install chromedriver --chromedriver_cdnurl=http://cdn.npm.taobao.org/dist/chromedriver