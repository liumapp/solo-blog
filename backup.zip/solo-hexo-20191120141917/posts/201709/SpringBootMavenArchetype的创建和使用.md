title: SpringBootMavenArchetype的创建和使用
date: '2017-09-28 17:27:40'
updated: '2017-09-28 17:32:23'
tags: [Java, Maven]
permalink: /articles/2017/09/28/1506589728566.html
---
> 我们在开发大型项目的时候，往往会将一个功能模块再细分为多个不同的小模块。每一个模块之间通过Maven进行管理，他们的目录结构基本上大同小异，那么在构建这些项目目录结构的时候，如果一个一个手写那么实在太麻烦了，这里我推荐大家使用Maven的archetype这个概念来解决这个问题。

首先上项目源码：[Github——SpringBootMavenArchetype](https://github.com/liumapp/SpringBootMavenArchetype)

### 如何使用

* 拷贝archetype项目源码到本地

* 在项目根目录下执行：

		mvn archetype:create-from-project
		
		
* 如果编译成功，那么将会生成一个target/generated-sources/archetype文件夹，我们进入这个archetype里面，再执行：

		mvn install
		
* 这一步编译成功后，我们就已经安装archetype成功了。

* 接下来在要生成项目的目录下执行：

        mvn archetype:generate
		
    能够出来这个目录：


	![archetype01.jpg](http://oss.fangxinqian.cn/50529342686c4abdbc31722bacaead13.jpg)


	然后选择要使用的archetype，及输入：com.liumapp.SpringBootMavenArchetype:SpringBootMavenArchetype-archetype

* 然后根据maven给的提示，输入自己项目的groupid、artifactid、version等信息。

* 结束。

### 如何创建自己的Archetype

自己写好代码，然后再利用

	mvn archetype:create-from-project
	
这个命令安装这个archetype即可。