title: 关于node-sass及node-gyp安装失败坑的解决办法
date: '2018-01-03 09:47:59'
updated: '2018-04-18 10:31:40'
tags: [nodeJs]
permalink: /articles/2018/01/03/1514943853653.html
---
> 先声明一下，这个问题不会经常出现，是否会发生取决于当时的网络情况。

先上错误信息：

	libtool: unrecognized option `-static'
	libtool: Try `libtool --help' for more information.
	make: *** [Release/sass.a] Error 1
	gyp ERR! build error 
	gyp ERR! stack Error: `make` failed with exit code: 2
	gyp ERR! stack     at ChildProcess.onExit (/usr/local/tomcat/project/spring-cloud-codegen-ui/node_modules/node-gyp/lib/build.js:258:23)
	gyp ERR! stack     at emitTwo (events.js:106:13)
	gyp ERR! stack     at ChildProcess.emit (events.js:194:7)
	gyp ERR! stack     at Process.ChildProcess._handle.onexit (internal/child_process.js:215:12)
	gyp ERR! System Darwin 15.6.0
	gyp ERR! command "/usr/local/Cellar/node/5.8.0/bin/node" "/usr/local/tomcat/project/spring-cloud-codegen-ui/node_modules/node-gyp/bin/node-gyp.js" "rebuild" "--verbose" "--libsass_ext=" "--libsass_cflags=" "--libsass_ldflags=" "--libsass_library="
	gyp ERR! cwd /usr/local/tomcat/project/spring-cloud-codegen-ui/node_modules/node-sass
	gyp ERR! node -v v7.8.0
	gyp ERR! node-gyp -v v3.6.2
	gyp ERR! not ok 
	Build failed with error code: 1
	npm ERR! Darwin 15.6.0
	npm ERR! argv "/usr/local/Cellar/node/5.8.0/bin/node" "/usr/local/bin/npm" "install"
	npm ERR! node v7.8.0
	npm ERR! npm  v4.2.0
	npm ERR! code ELIFECYCLE
	npm ERR! errno 1

	npm ERR! node-sass@4.7.2 postinstall: `node scripts/build.js`
	npm ERR! Exit status 1
	npm ERR! 
	npm ERR! Failed at the node-sass@4.7.2 postinstall script 'node scripts/build.js'.
	npm ERR! Make sure you have the latest version of node.js and npm installed.
	npm ERR! If you do, this is most likely a problem with the node-sass package,
	npm ERR! not with npm itself.
	npm ERR! Tell the author that this fails on your system:
	npm ERR!     node scripts/build.js
	npm ERR! You can get information on how to open an issue for this project with:
	npm ERR!     npm bugs node-sass
	npm ERR! Or if that isn't available, you can get their info via:
	npm ERR!     npm owner ls node-sass
	npm ERR! There is likely additional logging output above.

	npm ERR! Please include the following file with any support request:
	npm ERR!     /var/root/.npm/_logs/2018-01-03T01_21_29_137Z-debug.log

再上解决办法：

node-sass以及node-gyp在安装的时候，是会自动去找国外的源进行下载，而问题就是这个源并不是非常的稳定，请注意，这个稳定，并不全是由于国内墙的存在造成的，因为就算你开了VPN，这个问题还是会发生（亲身经历）。

所以最好的解决办法就是老老实实用淘宝镜像cnpm：


	npm install -g cnpm --registry=https://registry.npm.taobao.org

