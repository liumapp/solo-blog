title: 处理MySQL常见问题之："[ERR] 2006 - MySQL server has gone away"
date: '2019-03-20 09:17:37'
updated: '2019-03-20 09:42:57'
tags: [Mysql]
permalink: /articles/2019/03/20/1553044657099.html
---
> 实际开发过程中，我们经常会需要将线上数据库的数据备份到本地，但是由于这个数据量过大，所以在本地执行sql的过程中，往往会碰到[ERR] 2006 - MySQL server has gone away这个问题，这篇文章记录一下这个问题的出现原因和解决办法

## MySQL服务连接超时断开了连接

这是最常见的原因，解决办法也很简单，需要我们确保mysql的wait_timeout的值和interactive_timeout的值足够大

具体修改sql语句（在mysql命令行或者相关工具中运行）：

首先检查wait_timeout的值

````sql
show global variables like 'wait_timeout'; 
````

如果查询到的结果是28800的话（单位是秒），那么就是默认值，也就是8个小时，那么先不改它，够大了

然后检查interactive_timeout的值

````sql
show global variables like 'interactive_timeout'; 
````

如果没做修改的话，应该也是28800，先不改

那么毫无疑问，我本地出现的MySQL Server has gone away并不是因为连接被断开造成的

## Sql脚本中insert了一条数据量过大的语句

这个问题造成的第二个原因，可能是因为执行的sql中，有一条插入的数据量过大，超过了mysql的 max_allowed_packet的值

那么首先我们检查一下本地的max_allowed_packet测值

````sql
show global variables like 'max_allowed_packet'; 
````

得到的结果是4194304，也就是4M的样子

嗯，我们改成200M

````sql
set global max_allowed_packet=200000000;
````

再尝试导入，问题完美解决
